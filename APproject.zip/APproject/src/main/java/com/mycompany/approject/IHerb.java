/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */


import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * JavaFX App
 */
public class IHerb extends Application {

    @Override
    public void start(Stage primaryStage) {
        BorderPane iHerbPane = new BorderPane();
        iHerbPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // -------------------------------------- top --------------------------------------
        StackPane topIherberoot = new StackPane();

        Rectangle recttUpiHerb = new Rectangle();
        recttUpiHerb.setX(500);
        recttUpiHerb.setY(80);
        recttUpiHerb.setWidth(356);
        recttUpiHerb.setHeight(90);
        recttUpiHerb.setFill(blueRect);
        
        ////back//
        Image backiHerb = new Image("file:C:\\Users\\pc\\Downloads\\backarrow2.png");
        ImageView backvImgiHerb = new ImageView(backiHerb);//
        backvImgiHerb.setFitHeight(25);
        backvImgiHerb.setFitWidth(25);
        StackPane.setMargin(backvImgiHerb, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backvImgiHerb, Pos.CENTER_LEFT);
       

        Text iherbText = new Text("iHerb");
        iherbText.setStyle("-fx-font: normal bold 14px 'serif'");
        iherbText.setFill(Color.WHITE);

        StackPane.setAlignment(iherbText, Pos.CENTER_LEFT);
        StackPane.setMargin(iherbText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(recttUpiHerb, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldiherb = new TextField();
        searchFieldiherb.setFocusTraversable(false);
        searchFieldiherb.setPromptText("Search here ...");
        searchFieldiherb.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldiherb.setPrefWidth(200);
        searchFieldiherb.setPrefHeight(25);
        
        Rectangle searchFieldShapei = new Rectangle();
        searchFieldShapei.setWidth(200);
        searchFieldShapei.setHeight(25);
        searchFieldShapei.setArcWidth(25);
        searchFieldShapei.setArcHeight(30);
        searchFieldiherb.setShape(searchFieldShapei);

        Image searchimgei = new Image("file:C:\\Users\\pc\\Downloads\\search.png");
        ImageView searchViewimgi = new ImageView(searchimgei);
        searchViewimgi.setFitHeight(19);
        searchViewimgi.setFitWidth(22);

        StackPane.setMargin(searchViewimgi, new Insets(0, 0, 0, 170));
        StackPane searchiHerbContainer = new StackPane();
        searchiHerbContainer.getChildren().addAll(searchFieldiherb, searchViewimgi);

        HBox searchBoxiHerb = new HBox(searchiHerbContainer);

        StackPane.setMargin(searchBoxiHerb, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeeImagei = new Image("file:C:\\Users\\pc\\Downloads\\notices.png");
        ImageView noticeViewwi = new ImageView(noticeeImagei);
        noticeViewwi.setFitHeight(20);
        noticeViewwi.setFitWidth(15);

        Button noticeeButtoni = new Button();
        noticeeButtoni.setGraphic(new StackPane(noticeViewwi));
        noticeeButtoni.setPrefSize(30, 30);
        noticeeButtoni.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeeButtoni, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeeButtoni, Pos.CENTER_RIGHT);

        ////list //////
        Image listt1i = new Image("file:C:\\Users\\pc\\Downloads\\list1.png");
        ImageView listt1Imgi = new ImageView(listt1i);//
        listt1Imgi.setFitHeight(18);
        listt1Imgi.setFitWidth(23);

        StackPane.setMargin(listt1Imgi, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(listt1Imgi, Pos.CENTER_RIGHT);

        topIherberoot.getChildren().addAll(recttUpiHerb, iherbText, searchBoxiHerb,
                 noticeeButtoni, listt1Imgi ,backvImgiHerb);
        iHerbPane.setTop(topIherberoot);

        //---------- center -----------//
        VBox centerBoxiHerb = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxiHerb.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendiingiHerb = new StackPane();

        Rectangle rectProduct1iherb = new Rectangle(200, 70);
        rectProduct1iherb.setFill(PinkRectD);
        rectProduct1iherb.setArcWidth(10);
        rectProduct1iherb.setArcHeight(10);
 

        Label spendiingLb = new Label("Total Spending");
        spendiingLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendiingLb.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpendiingiHerb.setPadding(new Insets(20, 55, 0, 60));
        centerSpendiingiHerb.getChildren().addAll(rectProduct1iherb, spendiingLb);

        //items recnagles 
        //first 2-------------------------------------------------------------------
        HBox itemsBoxiherb =new HBox(40);

        itemsBoxiherb.setPadding(new Insets(30,0,0,40));

        StackPane rectitemsiherb1 = new StackPane();
        Rectangle rectProductiherb1 = new Rectangle(110,155);
        rectProductiherb1.setFill(PinkRectL);
        rectProductiherb1.setArcWidth(10);
        rectProductiherb1.setArcHeight(10);

        Rectangle SmallrectProductiherb1 = new Rectangle(110, 30);
        SmallrectProductiherb1.setFill(PinkRectD);
        SmallrectProductiherb1.setArcWidth(10);
        SmallrectProductiherb1.setArcHeight(10);
        SmallrectProductiherb1.setTranslateY(62);

        Image iherb1 = new Image("file:C:\\Users\\pc\\Downloads\\vaselinee.png");
        ImageView iherbImg1 = new ImageView(iherb1);//
        iherbImg1.setFitHeight(80);
        iherbImg1.setFitWidth(80);
        iherbImg1.setTranslateY(-31);

        Label iherb1Lb = new Label("Vaseline Lip \n   11.67SR");
        iherb1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb1Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb1Lb.setTranslateY(45);

        Image listtimg1i = new Image("file:C:\\Users\\pc\\Downloads\\list.png");
        ImageView listbtn1view1iherb = new ImageView(listtimg1i);//
        listbtn1view1iherb.setFitHeight(68);
        listbtn1view1iherb.setFitWidth(68);

        Button listButtoniherb1 = new Button();
        listButtoniherb1.setGraphic(new StackPane(listbtn1view1iherb));
        listButtoniherb1.setPrefSize(35, 35);
        listButtoniherb1.setTranslateY(65);
        listButtoniherb1.setTranslateX(20);
        listButtoniherb1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlisttimg1 = new Image("file:C:\\Users\\pc\\Downloads\\wishlist.png");
        ImageView wishlistView1iHerb = new ImageView(wishlisttimg1);
        wishlistView1iHerb.setFitHeight(50);
        wishlistView1iHerb.setFitWidth(50);
        
        Button wishlistButtoniHerb1 = new Button();
        wishlistButtoniHerb1.setGraphic(new StackPane(wishlistView1iHerb));
        wishlistButtoniHerb1.setPrefSize(35, 35);
        wishlistButtoniHerb1.setTranslateY(61);
        wishlistButtoniHerb1.setTranslateX(-20);
        wishlistButtoniHerb1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsiherb1.getChildren().addAll(rectProductiherb1, SmallrectProductiherb1,
                 iherbImg1, iherb1Lb, listButtoniherb1 , wishlistButtoniHerb1);

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        ////////////////////////////////////////////////////////////
        
        
        StackPane rectitemsiherb2 = new StackPane();
        Rectangle rectProductiherb2 = new Rectangle(110, 155);
        rectProductiherb2.setFill(PinkRectL);
        rectProductiherb2.setArcWidth(10);
        rectProductiherb2.setArcHeight(10);

        Rectangle SmallrectProductiherb2 = new Rectangle(110, 30);
        SmallrectProductiherb2.setFill(PinkRectD);
        SmallrectProductiherb2.setArcWidth(10);
        SmallrectProductiherb2.setArcHeight(10);
        SmallrectProductiherb2.setTranslateY(62);

        Image iherb2 = new Image("file:C:\\Users\\pc\\Downloads\\Antiperspirant.png");
        ImageView iherbImg2 = new ImageView(iherb2);//
        iherbImg2.setFitHeight(90);
        iherbImg2.setFitWidth(100);
        iherbImg2.setTranslateY(-28);

        Label iherb2Lb = new Label("Antiperspirant\n    16.39SR");
        iherb2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb2Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb2Lb.setTranslateY(45);
        
        ImageView listbtn1view2iHerb = new ImageView(listtimg1i);//
        listbtn1view2iHerb.setFitHeight(68);
        listbtn1view2iHerb.setFitWidth(68);
        
        ImageView wishlistView2iHerb = new ImageView(wishlisttimg1);
        wishlistView2iHerb.setFitHeight(50);
        wishlistView2iHerb.setFitWidth(50);
        
        Button listButtoniHerb2 = new Button();
        listButtoniHerb2.setGraphic(new StackPane(listbtn1view2iHerb));
        listButtoniHerb2.setPrefSize(35, 35);
        listButtoniHerb2.setTranslateY(65);
        listButtoniHerb2.setTranslateX(20);
        listButtoniHerb2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb2 = new Button();
        wishlistButtoniHerb2.setGraphic(new StackPane(wishlistView2iHerb));
        wishlistButtoniHerb2.setPrefSize(35, 35);
        wishlistButtoniHerb2.setTranslateY(61);
        wishlistButtoniHerb2.setTranslateX(-20);
        wishlistButtoniHerb2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsiherb2.getChildren().addAll(rectProductiherb2, SmallrectProductiherb2,
                 iherbImg2, iherb2Lb ,  wishlistButtoniHerb2 ,listButtoniHerb2);

        itemsBoxiherb.getChildren().addAll(rectitemsiherb1, rectitemsiherb2);

        
        
        
      
        
        
        
        // second 2 -------------------------------------------------------------------
        
        HBox itemsBoxiherb2 = new HBox(40);

        itemsBoxiherb2.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsiherb3 = new StackPane();
        Rectangle rectProductiherb3 = new Rectangle(110, 155);
        rectProductiherb3.setFill(PinkRectL);
        rectProductiherb3.setArcWidth(10);
        rectProductiherb3.setArcHeight(10);

        Rectangle SmallrectProductiHerb3 = new Rectangle(110, 30);
        SmallrectProductiHerb3.setFill(PinkRectD);
        SmallrectProductiHerb3.setArcWidth(10);
        SmallrectProductiHerb3.setArcHeight(10);
        SmallrectProductiHerb3.setTranslateY(62);

        Image iherb3 = new Image("file:C:\\Users\\pc\\Downloads\\omega3pillss.png");
        ImageView iherbImg3 = new ImageView(iherb3);//
        iherbImg3.setFitHeight(87);
        iherbImg3.setFitWidth(75);
        iherbImg3.setTranslateY(-38);

        Label iherb3Lb = new Label("Omega3 pills \n   49.51SR");
        iherb3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb3Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb3Lb.setTranslateY(34);
        
        ImageView listbtn1viewiherb3 = new ImageView(listtimg1i);//
        listbtn1viewiherb3.setFitHeight(68);
        listbtn1viewiherb3.setFitWidth(68);
        
        ImageView wishlistViewiherb3 = new ImageView(wishlisttimg1);
        wishlistViewiherb3.setFitHeight(50);
        wishlistViewiherb3.setFitWidth(50);
        
        Button listButtoniherb3 = new Button();
        listButtoniherb3.setGraphic(new StackPane(listbtn1viewiherb3));
        listButtoniherb3.setPrefSize(35, 35);
        listButtoniherb3.setTranslateY(65);
        listButtoniherb3.setTranslateX(20);
        listButtoniherb3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniherb3 = new Button();
        wishlistButtoniherb3.setGraphic(new StackPane(wishlistViewiherb3));
        wishlistButtoniherb3.setPrefSize(35, 35);
        wishlistButtoniherb3.setTranslateY(61);
        wishlistButtoniherb3.setTranslateX(-20);
        wishlistButtoniherb3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsiherb3.getChildren().addAll(rectProductiherb3, SmallrectProductiHerb3,
                 iherbImg3, iherb3Lb , wishlistButtoniherb3 , listButtoniherb3);
        
        
        
        //////////////////////////////////////////////////
        
        StackPane rectitemsiherb4 = new StackPane();
        Rectangle rectProductIherbb4 = new Rectangle(110, 155);
        rectProductIherbb4.setFill(PinkRectL);
        rectProductIherbb4.setArcWidth(10);
        rectProductIherbb4.setArcHeight(10);

        Rectangle SmallrectProductiherb4 = new Rectangle(110, 30);
        SmallrectProductiherb4.setFill(PinkRectD);
        SmallrectProductiherb4.setArcWidth(10);
        SmallrectProductiherb4.setArcHeight(10);
        SmallrectProductiherb4.setTranslateY(62);

        Image iherb4 = new Image("file:C:\\Users\\pc\\Downloads\\lipbalmss.png");
        ImageView iherbImg4 = new ImageView(iherb4);//
        iherbImg4.setFitHeight(105);
        iherbImg4.setFitWidth(75);
        iherbImg4.setTranslateY(-35);

        Label iherb4Lb = new Label("lip balms \n17.42SR");
        iherb4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb4Lb.setTranslateY(20);
        
        ImageView listbtn1viewiHerb4 = new ImageView(listtimg1i);//
        listbtn1viewiHerb4.setFitHeight(68);
        listbtn1viewiHerb4.setFitWidth(68);
        
        ImageView wishlistViewiHerb4 = new ImageView(wishlisttimg1);
        wishlistViewiHerb4.setFitHeight(50);
        wishlistViewiHerb4.setFitWidth(50);
        
        Button listButtoniHerb4 = new Button();
        listButtoniHerb4.setGraphic(new StackPane(listbtn1viewiHerb4));
        listButtoniHerb4.setPrefSize(35, 35);
        listButtoniHerb4.setTranslateY(65);
        listButtoniHerb4.setTranslateX(20);
        listButtoniHerb4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb4 = new Button();
        wishlistButtoniHerb4.setGraphic(new StackPane(wishlistViewiHerb4));
        wishlistButtoniHerb4.setPrefSize(35, 35);
        wishlistButtoniHerb4.setTranslateY(61);
        wishlistButtoniHerb4.setTranslateX(-20);
        wishlistButtoniHerb4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb4.getChildren().addAll(rectProductIherbb4, SmallrectProductiherb4,
                 iherbImg4, iherb4Lb, wishlistButtoniHerb4, listButtoniHerb4);

        itemsBoxiherb2.getChildren().addAll(rectitemsiherb3, rectitemsiherb4);

        // third 2 /////////////////
        HBox itemsBoxiherb3 = new HBox(40);

        itemsBoxiherb3.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsiherb5 = new StackPane();
        Rectangle rectProductiherb5 = new Rectangle(110, 155);
        rectProductiherb5.setFill(PinkRectL);
        rectProductiherb5.setArcWidth(10);
        rectProductiherb5.setArcHeight(10);

        Rectangle SmallrectProductiherb5 = new Rectangle(110, 30);
        SmallrectProductiherb5.setFill(PinkRectD);
        SmallrectProductiherb5.setArcWidth(10);
        SmallrectProductiherb5.setArcHeight(10);
        SmallrectProductiherb5.setTranslateY(62);

        Image iherb5 = new Image("file:C:\\Users\\pc\\Downloads\\Sunscreenn.png");
        ImageView iherbImg5 = new ImageView(iherb5);//
        iherbImg5.setFitHeight(90);
        iherbImg5.setFitWidth(90);
        iherbImg5.setTranslateY(-36);

        Label iherb5Lb = new Label("Sunscreen \n 96.43SR");
        iherb5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb5Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb5Lb.setTranslateY(34);
        
        
        ImageView listbtn1viewiHerb5 = new ImageView(listtimg1i);//
        listbtn1viewiHerb5.setFitHeight(68);
        listbtn1viewiHerb5.setFitWidth(68);
        
        ImageView wishlistViewiHerb5 = new ImageView(wishlisttimg1);
        wishlistViewiHerb5.setFitHeight(50);
        wishlistViewiHerb5.setFitWidth(50);
        
        Button listButtoniHerb5 = new Button();
        listButtoniHerb5.setGraphic(new StackPane(listbtn1viewiHerb5));
        listButtoniHerb5.setPrefSize(35, 35);
        listButtoniHerb5.setTranslateY(65);
        listButtoniHerb5.setTranslateX(20);
        listButtoniHerb5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb5 = new Button();
        wishlistButtoniHerb5.setGraphic(new StackPane(wishlistViewiHerb5));
        wishlistButtoniHerb5.setPrefSize(35, 35);
        wishlistButtoniHerb5.setTranslateY(61);
        wishlistButtoniHerb5.setTranslateX(-20);
        wishlistButtoniHerb5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb5.getChildren().addAll(rectProductiherb5, SmallrectProductiherb5,
                 iherbImg5, iherb5Lb, wishlistButtoniHerb5, listButtoniHerb5);
        
        //////////////////////////////////////////////
        
        StackPane rectitemsiherb6 = new StackPane();
        Rectangle rectProductiherb6 = new Rectangle(110, 155);
        rectProductiherb6.setFill(PinkRectL);
        rectProductiherb6.setArcWidth(10);
        rectProductiherb6.setArcHeight(10);

        Rectangle SmallrectProductiherb6 = new Rectangle(110, 30);
        SmallrectProductiherb6.setFill(PinkRectD);
        SmallrectProductiherb6.setArcWidth(10);
        SmallrectProductiherb6.setArcHeight(10);
        SmallrectProductiherb6.setTranslateY(62);

        Image iherb6 = new Image("file:C:\\Users\\pc\\Downloads\\somebymiProducts.png");
        ImageView iherbImg6 = new ImageView(iherb6);//
        iherbImg6.setFitHeight(110);
        iherbImg6.setFitWidth(80);
        iherbImg6.setTranslateY(-35);

        Label iherb6Lb = new Label("SOME BY MI \n   100.75SR");
        iherb6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb6Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb6Lb.setTranslateY(35);
        
        ImageView listbtn1viewiherb6 = new ImageView(listtimg1i);//
        listbtn1viewiherb6.setFitHeight(68);
        listbtn1viewiherb6.setFitWidth(68);
        
        ImageView wishlistViewiherb6 = new ImageView(wishlisttimg1);
        wishlistViewiherb6.setFitHeight(50);
        wishlistViewiherb6.setFitWidth(50);
        
        Button listButtoniherb6 = new Button();
        listButtoniherb6.setGraphic(new StackPane(listbtn1viewiherb6));
        listButtoniherb6.setPrefSize(35, 35);
        listButtoniherb6.setTranslateY(65);
        listButtoniherb6.setTranslateX(20);
        listButtoniherb6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniherb6 = new Button();
        wishlistButtoniherb6.setGraphic(new StackPane(wishlistViewiherb6));
        wishlistButtoniherb6.setPrefSize(35, 35);
        wishlistButtoniherb6.setTranslateY(61);
        wishlistButtoniherb6.setTranslateX(-20);
        wishlistButtoniherb6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb6.getChildren().addAll(rectProductiherb6, SmallrectProductiherb6,
                 iherbImg6, iherb6Lb , wishlistButtoniherb6 , listButtoniherb6 );

        itemsBoxiherb3.getChildren().addAll(rectitemsiherb5, rectitemsiherb6);

        // fourth 2 -------------------------------------------------------------------
        
        HBox itemsBoxiherb4 = new HBox(40);

        itemsBoxiherb4.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsiherb7 = new StackPane();
        Rectangle rectProductiherb7 = new Rectangle(110, 155);
        rectProductiherb7.setFill(PinkRectL);
        rectProductiherb7.setArcWidth(10);
        rectProductiherb7.setArcHeight(10);

        Rectangle SmallrectProductiherb7 = new Rectangle(110, 30);
        SmallrectProductiherb7.setFill(PinkRectD);
        SmallrectProductiherb7.setArcWidth(10);
        SmallrectProductiherb7.setArcHeight(10);
        SmallrectProductiherb7.setTranslateY(62);

        Image iherb7 = new Image("file:C:\\Users\\pc\\Downloads\\peanutButterr.png");
        ImageView iherbImg7 = new ImageView(iherb7);//
        iherbImg7.setFitHeight(90);
        iherbImg7.setFitWidth(85);
        iherbImg7.setTranslateY(-30);

        Label iherb7Lb = new Label("Peanut Butter \n   28.26SR");
        iherb7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb7Lb.setPadding(new Insets(0, 0, 25, 0));
        iherb7Lb.setTranslateY(40);
        
        ImageView listbtn1viewiherb7 = new ImageView(listtimg1i);//
        listbtn1viewiherb7.setFitHeight(68);
        listbtn1viewiherb7.setFitWidth(68);
        
        ImageView wishlistViewiherb7 = new ImageView(wishlisttimg1);
        wishlistViewiherb7.setFitHeight(50);
        wishlistViewiherb7.setFitWidth(50);
        
        Button listButtoniherb7 = new Button();
        listButtoniherb7.setGraphic(new StackPane(listbtn1viewiherb7));
        listButtoniherb7.setPrefSize(35, 35);
        listButtoniherb7.setTranslateY(65);
        listButtoniherb7.setTranslateX(20);
        listButtoniherb7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniherb7 = new Button();
        wishlistButtoniherb7.setGraphic(new StackPane(wishlistViewiherb7));
        wishlistButtoniherb7.setPrefSize(35, 35);
        wishlistButtoniherb7.setTranslateY(61);
        wishlistButtoniherb7.setTranslateX(-20);
        wishlistButtoniherb7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb7.getChildren().addAll(rectProductiherb7, SmallrectProductiherb7,
                 iherbImg7, iherb7Lb, wishlistButtoniherb7 , listButtoniherb7);
        
        ///////////////////////////////////////////////
        
        StackPane rectitemsiherb8 = new StackPane();
        Rectangle rectProductiherb8 = new Rectangle(110, 155);
        rectProductiherb8.setFill(PinkRectL);
        rectProductiherb8.setArcWidth(10);
        rectProductiherb8.setArcHeight(10);

        Rectangle SmallrectProductiherb8 = new Rectangle(110, 30);
        SmallrectProductiherb8.setFill(PinkRectD);
        SmallrectProductiherb8.setArcWidth(10);
        SmallrectProductiherb8.setArcHeight(10);
        SmallrectProductiherb8.setTranslateY(62);

        Image iherb8 = new Image("file:C:\\Users\\pc\\Downloads\\honeyTeaa.png");
        ImageView iherbImg8 = new ImageView(iherb8);//
        iherbImg8.setFitHeight(105);
        iherbImg8.setFitWidth(94);
        iherbImg8.setTranslateY(-34);

        Label iherb8Lb = new Label("Honey Tea \n  19.10SR");
        iherb8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb8Lb.setPadding(new Insets(0, 0, 25, 0));
        iherb8Lb.setTranslateY(38);
        
        ImageView listbtn1viewiHerb8 = new ImageView(listtimg1i);//
        listbtn1viewiHerb8.setFitHeight(68);
        listbtn1viewiHerb8.setFitWidth(68);
        
        ImageView wishlistViewiHerb8 = new ImageView(wishlisttimg1);
        wishlistViewiHerb8.setFitHeight(50);
        wishlistViewiHerb8.setFitWidth(50);
        
        Button listButtoniHerb8 = new Button();
        listButtoniHerb8.setGraphic(new StackPane(listbtn1viewiHerb8));
        listButtoniHerb8.setPrefSize(35, 35);
        listButtoniHerb8.setTranslateY(65);
        listButtoniHerb8.setTranslateX(20);
        listButtoniHerb8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb8 = new Button();
        wishlistButtoniHerb8.setGraphic(new StackPane(wishlistViewiHerb8));
        wishlistButtoniHerb8.setPrefSize(35, 35);
        wishlistButtoniHerb8.setTranslateY(61);
        wishlistButtoniHerb8.setTranslateX(-20);
        wishlistButtoniHerb8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb8.getChildren().addAll(rectProductiherb8 , SmallrectProductiherb8
                , iherbImg8, iherb8Lb , wishlistButtoniHerb8 , listButtoniHerb8);

        itemsBoxiherb4.getChildren().addAll(rectitemsiherb7, rectitemsiherb8 );

        // fifth 2/////////////////////////////
        HBox itemsBoxiherb5 = new HBox(40);

        itemsBoxiherb5.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsiherb9 = new StackPane();
        Rectangle rectProductiherb9 = new Rectangle(110, 155);
        rectProductiherb9.setFill(PinkRectL);
        rectProductiherb9.setArcWidth(10);
        rectProductiherb9.setArcHeight(10);

        Rectangle SmallrectProductiherb9 = new Rectangle(110, 30);
        SmallrectProductiherb9.setFill(PinkRectD);
        SmallrectProductiherb9.setArcWidth(10);
        SmallrectProductiherb9.setArcHeight(10);
        SmallrectProductiherb9.setTranslateY(62);

        Image iherb9 = new Image("file:C:\\Users\\pc\\Downloads\\browniee.png");
        ImageView iherbImg9 = new ImageView(iherb9);//
        iherbImg9.setFitHeight(88);
        iherbImg9.setFitWidth(70);
        iherbImg9.setTranslateY(-37);

        Label iherb9Lb = new Label("  Brownie Brittle   \n        21.97SR");
        iherb9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb9Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb9Lb.setTranslateY(40);
        
        ImageView listbtn1viewiHerb9 = new ImageView(listtimg1i);//
        listbtn1viewiHerb9.setFitHeight(68);
        listbtn1viewiHerb9.setFitWidth(68);
        
        ImageView wishlistViewiHerb9 = new ImageView(wishlisttimg1);
        wishlistViewiHerb9.setFitHeight(50);
        wishlistViewiHerb9.setFitWidth(50);
        
        Button listButtoniHerb9 = new Button();
        listButtoniHerb9.setGraphic(new StackPane(listbtn1viewiHerb9));
        listButtoniHerb9.setPrefSize(35, 35);
        listButtoniHerb9.setTranslateY(65);
        listButtoniHerb9.setTranslateX(20);
        listButtoniHerb9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb9 = new Button();
        wishlistButtoniHerb9.setGraphic(new StackPane(wishlistViewiHerb9));
        wishlistButtoniHerb9.setPrefSize(35, 35);
        wishlistButtoniHerb9.setTranslateY(61);
        wishlistButtoniHerb9.setTranslateX(-20);
        wishlistButtoniHerb9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb9.getChildren().addAll(rectProductiherb9, SmallrectProductiherb9,
                 iherbImg9, iherb9Lb , wishlistButtoniHerb9 , listButtoniHerb9);
        
/////////////////////////////////////////////////////////

        StackPane rectitemsiherb10 = new StackPane();
        Rectangle rectProductiherb10 = new Rectangle(110, 155);
        rectProductiherb10.setFill(PinkRectL);
        rectProductiherb10.setArcWidth(10);
        rectProductiherb10.setArcHeight(10);

        Rectangle SmallrectProductihedrb10 = new Rectangle(110, 30);
        SmallrectProductihedrb10.setFill(PinkRectD);
        SmallrectProductihedrb10.setArcWidth(10);
        SmallrectProductihedrb10.setArcHeight(10);
        SmallrectProductihedrb10.setTranslateY(62);

        Image iherb10 = new Image("file:C:\\Users\\pc\\Downloads\\calciumpills.png");
        ImageView iherbImg10 = new ImageView(iherb10);//
        iherbImg10.setFitHeight(80);
        iherbImg10.setFitWidth(70);
        iherbImg10.setTranslateY(-35);

        Label iherb10Lb = new Label("Calcium pills \n   20.43SR");
        iherb10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        iherb10Lb.setPadding(new Insets(0, 0, 30, 0));
        iherb10Lb.setTranslateY(38);
        
        ImageView listbtn1viewiHerb10 = new ImageView(listtimg1i);//
        listbtn1viewiHerb10.setFitHeight(68);
        listbtn1viewiHerb10.setFitWidth(68);
        
        ImageView wishlistViewiHerb10 = new ImageView(wishlisttimg1);
        wishlistViewiHerb10.setFitHeight(50);
        wishlistViewiHerb10.setFitWidth(50);
        
        Button listButtoniHerb10 = new Button();
        listButtoniHerb10.setGraphic(new StackPane(listbtn1viewiHerb10));
        listButtoniHerb10.setPrefSize(35, 35);
        listButtoniHerb10.setTranslateY(65);
        listButtoniHerb10.setTranslateX(20);
        listButtoniHerb10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButtoniHerb10 = new Button();
        wishlistButtoniHerb10.setGraphic(new StackPane(wishlistViewiHerb10));
        wishlistButtoniHerb10.setPrefSize(35, 35);
        wishlistButtoniHerb10.setTranslateY(61);
        wishlistButtoniHerb10.setTranslateX(-20);
        wishlistButtoniHerb10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsiherb10.getChildren().addAll(rectProductiherb10, SmallrectProductihedrb10
                , iherbImg10, iherb10Lb , wishlistButtoniHerb10 , listButtoniHerb10);

        itemsBoxiherb5.getChildren().addAll(rectitemsiherb9, rectitemsiherb10);

        centerBoxiHerb.getChildren().addAll(centerSpendiingiHerb, itemsBoxiherb, itemsBoxiherb2,
                 itemsBoxiherb3, itemsBoxiherb4, itemsBoxiherb5);
        
        
        ScrollPane scrollPaneiHerb = new ScrollPane(centerBoxiHerb);
        scrollPaneiHerb.setFitToWidth(true);
        scrollPaneiHerb.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        //---------------------------- bottom --------------------
        StackPane bottomiHerbroot = new StackPane();

        Rectangle rectangleBiHerb = new Rectangle();
        rectangleBiHerb.setWidth(360);
        rectangleBiHerb.setHeight(60);
        rectangleBiHerb.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBiHerb, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomeiHerb = new Image("file:C:\\Users\\pc\\Downloads\\home.png");

        ImageView homeViewiHerb = new ImageView(imageHomeiHerb);
        homeViewiHerb.setFitHeight(50);
        homeViewiHerb.setFitWidth(60);

        Button homeButtoniHerb = new Button();
        homeButtoniHerb.setGraphic(new StackPane(homeViewiHerb));
        homeButtoniHerb.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtoniHerb, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtoniHerb, new Insets(10, 0, 0, 30));

        Text textHomeiHerb = new Text("Home");
        textHomeiHerb.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomeiHerb.setFill(Color.WHITE);

        StackPane.setAlignment(textHomeiHerb, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomeiHerb, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImageiHerb = new Image("file:C:\\Users\\pc\\Downloads\\wishlist.png");
        ImageView wishlistViewiHerbb = new ImageView(wishlistImageiHerb);
        wishlistViewiHerbb.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewiHerbb.setFitWidth(70);

        Button wishlistButtoniHerb = new Button();
        wishlistButtoniHerb.setGraphic(new StackPane(wishlistViewiHerbb));
        wishlistButtoniHerb.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtoniHerb, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtoniHerb, new Insets(10, 0, 0, 91));

        Text wishlistTextiHerbb = new Text("Wishlist");
        wishlistTextiHerbb.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextiHerbb.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextiHerbb, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextiHerbb, new Insets(50, 0, 0, 120));



        ////-------------- List button ----------------////

        Image listImageiHerb = new Image("file:C:\\Users\\pc\\Downloads\\list.png");
        ImageView listViewiHerb = new ImageView(listImageiHerb);
        listViewiHerb.setFitHeight(70); //setting the fit height and width of the image view
        listViewiHerb.setFitWidth(80);

        Button listButtoniHerbb = new Button();
        listButtoniHerbb.setGraphic(new StackPane(listViewiHerb));
        listButtoniHerbb.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtoniHerbb, Pos.CENTER);
        StackPane.setMargin(listButtoniHerbb, new Insets(15, 0, 0, 60));

        Text listTextiHerbb = new Text("List");
        listTextiHerbb.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextiHerbb.setFill(Color.WHITE);

        StackPane.setAlignment(listTextiHerbb, Pos.CENTER);
        StackPane.setMargin(listTextiHerbb, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImageiHerbb = new Image("file:C:\\Users\\pc\\Downloads\\profile.png");
        ImageView profileViewiHerbb = new ImageView(profileImageiHerbb);
        profileViewiHerbb.setFitHeight(70); //setting the fit height and width of the image view
        profileViewiHerbb.setFitWidth(100);

        Button profileButtoniHerbb = new Button();
        profileButtoniHerbb.setGraphic(new StackPane(profileViewiHerbb));
        profileButtoniHerbb.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtoniHerbb, Pos.CENTER);
        StackPane.setMargin(profileButtoniHerbb, new Insets(0, 0, 0, 210));

        Text profileTextiHerbb = new Text("Profile");
        profileTextiHerbb.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextiHerbb.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextiHerbb, Pos.CENTER);
        StackPane.setMargin(profileTextiHerbb, new Insets(50, 0, 0, 200));



        bottomiHerbroot.getChildren().addAll(rectangleBiHerb, homeButtoniHerb, textHomeiHerb
                , wishlistButtoniHerb , wishlistTextiHerbb , listButtoniHerbb ,listTextiHerbb , profileButtoniHerbb , profileTextiHerbb );

           
        iHerbPane.setTop(topIherberoot);       
        iHerbPane.setCenter(scrollPaneiHerb);
        iHerbPane.setBottom(bottomiHerbroot);
        
        
         //iherb scene
        Scene sceneiHerbb = new Scene(iHerbPane, 350, 600);
        primaryStage.setScene(sceneiHerbb); // Place the scene in the stage
        primaryStage.show(); //


        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        ProfileScene profileScene = new ProfileScene();
        backvImgiHerb.setOnMousePressed(e->{
            homePageScene.start(primaryStage );
        });

        homeButtoniHerb.setOnMousePressed(e->{
            homePageScene.start(primaryStage );

        });

        wishlistButtoniHerb.setOnMousePressed(e->{
            wishlistScene.start(primaryStage );

        });


//        listButtoniHerbb.setOnMousePressed(e->{
////            listScene.start(primaryStage );
//
//        });
        
         listButtoniHerbb.setOnAction(e->{  //iherb
        
            
//            Session session = HibernateUtil.getSessionFactory().openSession();
//            Transaction tx = session.beginTransaction();
//            
//            Wishlist wishlist1 = new Wishlist();
//            
//             
//            //insert new item
//            session = HibernateUtil.getSessionFactory().openSession();
//            
//            tx = session.beginTransaction();
//            
//            
//            int sId2 = (Integer) session.save(wishlist1);
//            tx.commit();
//
//            session.close();
                  
          });

//        profileButtoniHerbb.setOnMousePressed(e->{    // profile button
//                    profileScene.start(new Stage() );

//              });


    }


}
