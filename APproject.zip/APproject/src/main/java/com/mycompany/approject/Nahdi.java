/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class Nahdi extends Application {

   
    
    @Override
    public void start(Stage primaryStage) {
          BorderPane nahdiPane = new BorderPane();
        nahdiPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topNahdiroot = new StackPane();

        Rectangle rectangleT = new Rectangle();
        rectangleT.setX(500);
        rectangleT.setY(80);
        rectangleT.setWidth(356);
        rectangleT.setHeight(90);
        rectangleT.setFill(blueRect);
        
        ////back//
        Image back = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);
       

        Text NahdiText = new Text("AlNahdi");
        NahdiText.setStyle("-fx-font: normal bold 14px 'serif'");
        NahdiText.setFill(Color.WHITE);

        StackPane.setAlignment(NahdiText, Pos.CENTER_LEFT);
        StackPane.setMargin(NahdiText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleT, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchField = new TextField();
        searchField.setFocusTraversable(false);
        searchField.setPromptText("Search here ...");
        searchField.setStyle("-fx-font: normal 10px 'serif'");
        searchField.setPrefWidth(200);
        searchField.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchField.setShape(searchFieldShape);

        Image searchImage = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/search.png");
        ImageView searchView = new ImageView(searchImage);
        searchView.setFitHeight(19);
        searchView.setFitWidth(22);

        StackPane.setMargin(searchView, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainer = new StackPane();
        searchFieldContainer.getChildren().addAll(searchField, searchView);

        HBox searchBox = new HBox(searchFieldContainer);

        StackPane.setMargin(searchBox, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image notfImage = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/notf.png");
        ImageView notfView = new ImageView(notfImage);
        notfView.setFitHeight(20);
        notfView.setFitWidth(15);

        Button noticeButton = new Button();
        noticeButton.setGraphic(new StackPane(notfView));
        noticeButton.setPrefSize(30, 30);
        noticeButton.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButton, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButton, Pos.CENTER_RIGHT);

        ////list //////
        Image list1 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list1.png");
        ImageView list1Img = new ImageView(list1);//
        list1Img.setFitHeight(18);
        list1Img.setFitWidth(23);

        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topNahdiroot.getChildren().addAll(rectangleT, NahdiText, searchBox,
                 noticeButton, list1Img ,backImg);
        nahdiPane.setTop(topNahdiroot);

        //---------- center -----------//
        VBox centerBox = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBox.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpending = new StackPane();

        Rectangle rectProduct1 = new Rectangle(200, 70);
        rectProduct1.setFill(PinkRectD);
        rectProduct1.setArcWidth(10);
        rectProduct1.setArcHeight(10);
 

        Label spendingLb = new Label("Total Spending");
        spendingLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLb.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpending.setPadding(new Insets(20, 55, 0, 60));
        centerSpending.getChildren().addAll(rectProduct1, spendingLb);

        //items recnagles 
        //first 2
        HBox itemsBoxNahdi1 = new HBox(38);

        itemsBoxNahdi1.setPadding(new Insets(30, 0, 0, 35));

        StackPane rectitemsNahdi1 = new StackPane();
        Rectangle rectProductNahdi1 = new Rectangle(110, 155);
        rectProductNahdi1.setFill(PinkRectL);
        rectProductNahdi1.setArcWidth(10);
        rectProductNahdi1.setArcHeight(10);

        Rectangle SmallrectProductNahdi1 = new Rectangle(110, 30);
        SmallrectProductNahdi1.setFill(PinkRectD);
        SmallrectProductNahdi1.setArcWidth(10);
        SmallrectProductNahdi1.setArcHeight(10);
        SmallrectProductNahdi1.setTranslateY(62);

        Image nahdi1 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi1.png");
        ImageView nahdiImg1 = new ImageView(nahdi1);//
        nahdiImg1.setFitHeight(90);
        nahdiImg1.setFitWidth(80);
        nahdiImg1.setTranslateY(-31);

        Label nahdi1Lb = new Label("Soluble Painkiller\n13.35SR");
        nahdi1Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi1Lb.setPadding(new Insets(90, 10, 30, 0));

        Image listimg1 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list.png");
        ImageView listbtn1view1 = new ImageView(listimg1);//
        listbtn1view1.setFitHeight(68);
        listbtn1view1.setFitWidth(68);

        Button listButton1 = new Button();
        listButton1.setGraphic(new StackPane(listbtn1view1));
        listButton1.setPrefSize(35, 35);
        listButton1.setTranslateY(65);
        listButton1.setTranslateX(20);
        listButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlistimg1 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/wishlist.png");
        ImageView wishlistView1 = new ImageView(wishlistimg1);
        wishlistView1.setFitHeight(50);
        wishlistView1.setFitWidth(50);
        
        Button wishlistButton1 = new Button();
        wishlistButton1.setGraphic(new StackPane(wishlistView1));
        wishlistButton1.setPrefSize(35, 35);
        wishlistButton1.setTranslateY(61);
        wishlistButton1.setTranslateX(-20);
        wishlistButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNahdi1.getChildren().addAll(rectProductNahdi1, SmallrectProductNahdi1,
                 nahdiImg1, nahdi1Lb, listButton1 , wishlistButton1);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsNahdi2 = new StackPane();
        Rectangle rectProductNahdi2 = new Rectangle(110, 155);
        rectProductNahdi2.setFill(PinkRectL);
        rectProductNahdi2.setArcWidth(10);
        rectProductNahdi2.setArcHeight(10);

        Rectangle SmallrectProductNahdi2 = new Rectangle(110, 30);
        SmallrectProductNahdi2.setFill(PinkRectD);
        SmallrectProductNahdi2.setArcWidth(10);
        SmallrectProductNahdi2.setArcHeight(10);
        SmallrectProductNahdi2.setTranslateY(62);

        Image nahdi2 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi2.png");
        ImageView nahdiImg2 = new ImageView(nahdi2);//
        nahdiImg2.setFitHeight(100);
        nahdiImg2.setFitWidth(100);
        nahdiImg2.setTranslateY(-28);

        Label nahdi2Lb = new Label("Lip Balm\n25.80SR");
        nahdi2Lb.setStyle("-fx-font: normal  11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi2Lb.setPadding(new Insets(0, 50, 30, 0));
        nahdi2Lb.setTranslateY(45);
        
        ImageView listbtn1view2 = new ImageView(listimg1);//
        listbtn1view2.setFitHeight(68);
        listbtn1view2.setFitWidth(68);
        
        ImageView wishlistView2 = new ImageView(wishlistimg1);
        wishlistView2.setFitHeight(50);
        wishlistView2.setFitWidth(50);
        
        Button listButton2 = new Button();
        listButton2.setGraphic(new StackPane(listbtn1view2));
        listButton2.setPrefSize(35, 35);
        listButton2.setTranslateY(65);
        listButton2.setTranslateX(20);
        listButton2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton2 = new Button();
        wishlistButton2.setGraphic(new StackPane(wishlistView2));
        wishlistButton2.setPrefSize(35, 35);
        wishlistButton2.setTranslateY(61);
        wishlistButton2.setTranslateX(-20);
        wishlistButton2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNahdi2.getChildren().addAll(rectProductNahdi2, SmallrectProductNahdi2,
                 nahdiImg2, nahdi2Lb ,  wishlistButton2 ,listButton2);

        itemsBoxNahdi1.getChildren().addAll(rectitemsNahdi1, rectitemsNahdi2);

        // second 2
        HBox itemsBoxNahdi2 = new HBox(25);

        itemsBoxNahdi2.setPadding(new Insets(30, 0, 0, 23));

        StackPane rectitemsNahdi3 = new StackPane();
        Rectangle rectProductNahdi3 = new Rectangle(110, 155);
        rectProductNahdi3.setFill(PinkRectL);
        rectProductNahdi3.setArcWidth(10);
        rectProductNahdi3.setArcHeight(10);

        Rectangle SmallrectProductNahdi3 = new Rectangle(110, 30);
        SmallrectProductNahdi3.setFill(PinkRectD);
        SmallrectProductNahdi3.setArcWidth(10);
        SmallrectProductNahdi3.setArcHeight(10);
        SmallrectProductNahdi3.setTranslateY(62);

        Image nahdi3 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi3.png");
        ImageView nahdiImg3 = new ImageView(nahdi3);//
        nahdiImg3.setFitHeight(150);
        nahdiImg3.setFitWidth(135);
        nahdiImg3.setTranslateY(-38);

        Label nahdi3Lb = new Label("Eucerin Sunscreen  \n83.96SR");
        nahdi3Lb.setStyle("-fx-font: normal  10.5px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi3Lb.setPadding(new Insets(0, 0, 30, 0));
        nahdi3Lb.setTranslateY(45);
        
        ImageView listbtn1view3 = new ImageView(listimg1);//
        listbtn1view3.setFitHeight(68);
        listbtn1view3.setFitWidth(68);
        
        ImageView wishlistView3 = new ImageView(wishlistimg1);
        wishlistView3.setFitHeight(50);
        wishlistView3.setFitWidth(50);
        
        Button listButton3 = new Button();
        listButton3.setGraphic(new StackPane(listbtn1view3));
        listButton3.setPrefSize(35, 35);
        listButton3.setTranslateY(65);
        listButton3.setTranslateX(20);
        listButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton3 = new Button();
        wishlistButton3.setGraphic(new StackPane(wishlistView3));
        wishlistButton3.setPrefSize(35, 35);
        wishlistButton3.setTranslateY(61);
        wishlistButton3.setTranslateX(-20);
        wishlistButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNahdi3.getChildren().addAll(rectProductNahdi3, SmallrectProductNahdi3,
                 nahdiImg3, nahdi3Lb , wishlistButton3 , listButton3);
        
        //////////////////////////////////////////////////
        StackPane rectitemsNahdi4 = new StackPane();
        Rectangle rectProductNahdi4 = new Rectangle(110, 155);
        rectProductNahdi4.setFill(PinkRectL);
        rectProductNahdi4.setArcWidth(10);
        rectProductNahdi4.setArcHeight(10);

        Rectangle SmallrectProductNahdi4 = new Rectangle(110, 30);
        SmallrectProductNahdi4.setFill(PinkRectD);
        SmallrectProductNahdi4.setArcWidth(10);
        SmallrectProductNahdi4.setArcHeight(10);
        SmallrectProductNahdi4.setTranslateY(62);

        Image nahdi4 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi4.png");
        ImageView nahdiImg4 = new ImageView(nahdi4);//
        nahdiImg4.setFitHeight(85);
        nahdiImg4.setFitWidth(70);
        nahdiImg4.setTranslateY(-30);

        Label nahdi4Lb = new Label("Cerelac Wheat&\nHoney 30.60SR");
        nahdi4Lb.setStyle("-fx-font: normal  11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi4Lb.setPadding(new Insets(66, 10, 9, 0));
        
        
        ImageView listbtn1view4 = new ImageView(listimg1);//
        listbtn1view4.setFitHeight(68);
        listbtn1view4.setFitWidth(68);
        
        ImageView wishlistView4 = new ImageView(wishlistimg1);
        wishlistView4.setFitHeight(50);
        wishlistView4.setFitWidth(50);
        
        Button listButton4 = new Button();
        listButton4.setGraphic(new StackPane(listbtn1view4));
        listButton4.setPrefSize(35, 35);
        listButton4.setTranslateY(65);
        listButton4.setTranslateX(20);
        listButton4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton4 = new Button();
        wishlistButton4.setGraphic(new StackPane(wishlistView4));
        wishlistButton4.setPrefSize(35, 35);
        wishlistButton4.setTranslateY(61);
        wishlistButton4.setTranslateX(-20);
        wishlistButton4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi4.getChildren().addAll(rectProductNahdi4, SmallrectProductNahdi4,
                 nahdiImg4, nahdi4Lb, wishlistButton4, listButton4);

        itemsBoxNahdi2.getChildren().addAll(rectitemsNahdi3, rectitemsNahdi4);

        // third 2 /////////////////
        HBox itemsBoxNahdi3 = new HBox(38);

        itemsBoxNahdi3.setPadding(new Insets(30, 0, 0, 35));

        StackPane rectitemsNahdi5 = new StackPane();
        Rectangle rectProductNahdi5 = new Rectangle(110, 155);
        rectProductNahdi5.setFill(PinkRectL);
        rectProductNahdi5.setArcWidth(10);
        rectProductNahdi5.setArcHeight(10);

        Rectangle SmallrectProductNahdi5 = new Rectangle(110, 30);
        SmallrectProductNahdi5.setFill(PinkRectD);
        SmallrectProductNahdi5.setArcWidth(10);
        SmallrectProductNahdi5.setArcHeight(10);
        SmallrectProductNahdi5.setTranslateY(62);

        Image nahdi5 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi5.png");
        ImageView nahdi5Img5 = new ImageView(nahdi5);//
        nahdi5Img5.setFitHeight(100);
        nahdi5Img5.setFitWidth(90);
        nahdi5Img5.setTranslateY(-30);

        Label nahdi5Lb = new Label("Face Cleanser \n 120.16SR");
        nahdi5Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi5Lb.setPadding(new Insets(0, 25, 13, 0));
        nahdi5Lb.setTranslateY(34);
        
        
        ImageView listbtn1view5 = new ImageView(listimg1);//
        listbtn1view5.setFitHeight(68);
        listbtn1view5.setFitWidth(68);
        
        ImageView wishlistView5 = new ImageView(wishlistimg1);
        wishlistView5.setFitHeight(50);
        wishlistView5.setFitWidth(50);
        
        Button listButton5 = new Button();
        listButton5.setGraphic(new StackPane(listbtn1view5));
        listButton5.setPrefSize(35, 35);
        listButton5.setTranslateY(65);
        listButton5.setTranslateX(20);
        listButton5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton5 = new Button();
        wishlistButton5.setGraphic(new StackPane(wishlistView5));
        wishlistButton5.setPrefSize(35, 35);
        wishlistButton5.setTranslateY(61);
        wishlistButton5.setTranslateX(-20);
        wishlistButton5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi5.getChildren().addAll(rectProductNahdi5, SmallrectProductNahdi5,
                 nahdi5Img5, nahdi5Lb, wishlistButton5, listButton5);
        //////////////////////////////////////////////
        StackPane rectitemsNahdi6 = new StackPane();
        Rectangle rectProductNahdi6 = new Rectangle(110, 155);
        rectProductNahdi6.setFill(PinkRectL);
        rectProductNahdi6.setArcWidth(10);
        rectProductNahdi6.setArcHeight(10);

        Rectangle SmallrectProductNahdi6 = new Rectangle(110, 30);
        SmallrectProductNahdi6.setFill(PinkRectD);
        SmallrectProductNahdi6.setArcWidth(10);
        SmallrectProductNahdi6.setArcHeight(10);
        SmallrectProductNahdi6.setTranslateY(62);

        Image nahdi6 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi6.png");
        ImageView nahdiImg6 = new ImageView(nahdi6);//
        nahdiImg6.setFitHeight(90);
        nahdiImg6.setFitWidth(80);
        nahdiImg6.setTranslateY(-30);

        Label nahdi6Lb = new Label("QV Moisturizer \n 80.00SR");
        nahdi6Lb.setStyle("-fx-font: normal 10.5px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi6Lb.setPadding(new Insets(0, 15, 12, 0));
        nahdi6Lb.setTranslateY(35);
        
        ImageView listbtn1view6 = new ImageView(listimg1);//
        listbtn1view6.setFitHeight(68);
        listbtn1view6.setFitWidth(68);
        
        ImageView wishlistView6 = new ImageView(wishlistimg1);
        wishlistView6.setFitHeight(50);
        wishlistView6.setFitWidth(50);
        
        Button listButton6 = new Button();
        listButton6.setGraphic(new StackPane(listbtn1view6));
        listButton6.setPrefSize(35, 35);
        listButton6.setTranslateY(65);
        listButton6.setTranslateX(20);
        listButton6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton6 = new Button();
        wishlistButton6.setGraphic(new StackPane(wishlistView6));
        wishlistButton6.setPrefSize(35, 35);
        wishlistButton6.setTranslateY(61);
        wishlistButton6.setTranslateX(-20);
        wishlistButton6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi6.getChildren().addAll(rectProductNahdi6, SmallrectProductNahdi6,
                 nahdiImg6, nahdi6Lb , wishlistButton6 , listButton6 );

        itemsBoxNahdi3.getChildren().addAll(rectitemsNahdi5, rectitemsNahdi6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBoxNahdi4 = new HBox(40);

        itemsBoxNahdi4.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNahdi7 = new StackPane();
        Rectangle rectProductNahdi7 = new Rectangle(110, 155);
        rectProductNahdi7.setFill(PinkRectL);
        rectProductNahdi7.setArcWidth(10);
        rectProductNahdi7.setArcHeight(10);

        Rectangle SmallrectProductNahdi7 = new Rectangle(110, 30);
        SmallrectProductNahdi7.setFill(PinkRectD);
        SmallrectProductNahdi7.setArcWidth(10);
        SmallrectProductNahdi7.setArcHeight(10);
        SmallrectProductNahdi7.setTranslateY(62);

        Image nahdi7 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi7.png");
        ImageView nahdiImg7 = new ImageView(nahdi7);//
        nahdiImg7.setFitHeight(90);
        nahdiImg7.setFitWidth(95);
        nahdiImg7.setTranslateY(-33);

        Label nahdi7Lb = new Label("Hair Repair Mask \n 180.96SR");
        nahdi7Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi7Lb.setPadding(new Insets(0, 10, 20, 0));
        nahdi7Lb.setTranslateY(40);
        
        ImageView listbtn1view7 = new ImageView(listimg1);//
        listbtn1view7.setFitHeight(68);
        listbtn1view7.setFitWidth(68);
        
        ImageView wishlistView7 = new ImageView(wishlistimg1);
        wishlistView7.setFitHeight(50);
        wishlistView7.setFitWidth(50);
        
        Button listButton7 = new Button();
        listButton7.setGraphic(new StackPane(listbtn1view7));
        listButton7.setPrefSize(35, 35);
        listButton7.setTranslateY(65);
        listButton7.setTranslateX(20);
        listButton7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton7 = new Button();
        wishlistButton7.setGraphic(new StackPane(wishlistView7));
        wishlistButton7.setPrefSize(35, 35);
        wishlistButton7.setTranslateY(61);
        wishlistButton7.setTranslateX(-20);
        wishlistButton7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi7.getChildren().addAll(rectProductNahdi7, SmallrectProductNahdi7,
                 nahdiImg7, nahdi7Lb, wishlistButton7 , listButton7);
        ///////////////////////////////////////////////
        StackPane rectitemsNahdi8 = new StackPane();
        Rectangle rectProductNahdi8 = new Rectangle(110, 155);
        rectProductNahdi8.setFill(PinkRectL);
        rectProductNahdi8.setArcWidth(10);
        rectProductNahdi8.setArcHeight(10);

        Rectangle SmallrectProductNahdi8 = new Rectangle(110, 30);
        SmallrectProductNahdi8.setFill(PinkRectD);
        SmallrectProductNahdi8.setArcWidth(10);
        SmallrectProductNahdi8.setArcHeight(10);
        SmallrectProductNahdi8.setTranslateY(62);

        Image nahdi8 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi8.png");
        ImageView nahdiImg8 = new ImageView(nahdi8);//
        nahdiImg8.setFitHeight(105);
        nahdiImg8.setFitWidth(95);
        nahdiImg8.setTranslateY(-28);

        Label nahdi8Lb = new Label("Melatonin   \n110.60SR");
        nahdi8Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi8Lb.setPadding(new Insets(0, 37, 16, 0));
        nahdi8Lb.setTranslateY(38);
        
        ImageView listbtn1view8 = new ImageView(listimg1);//
        listbtn1view8.setFitHeight(68);
        listbtn1view8.setFitWidth(68);
        
        ImageView wishlistView8 = new ImageView(wishlistimg1);
        wishlistView8.setFitHeight(50);
        wishlistView8.setFitWidth(50);
        
        Button listButton8 = new Button();
        listButton8.setGraphic(new StackPane(listbtn1view8));
        listButton8.setPrefSize(35, 35);
        listButton8.setTranslateY(65);
        listButton8.setTranslateX(20);
        listButton8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton8 = new Button();
        wishlistButton8.setGraphic(new StackPane(wishlistView8));
        wishlistButton8.setPrefSize(35, 35);
        wishlistButton8.setTranslateY(61);
        wishlistButton8.setTranslateX(-20);
        wishlistButton8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi8.getChildren().addAll(rectProductNahdi8 , SmallrectProductNahdi8
                , nahdiImg8, nahdi8Lb , wishlistButton8 , listButton8);

        itemsBoxNahdi4.getChildren().addAll(rectitemsNahdi7, rectitemsNahdi8 );

        // fifth 2/////////////////////////////
        HBox itemsBoxNahdi5 = new HBox(40);

        itemsBoxNahdi5.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNahdi9 = new StackPane();
        Rectangle rectProductNahdi9 = new Rectangle(110, 155);
        rectProductNahdi9.setFill(PinkRectL);
        rectProductNahdi9.setArcWidth(10);
        rectProductNahdi9.setArcHeight(10);

        Rectangle SmallrectProductNahdi9 = new Rectangle(110, 30);
        SmallrectProductNahdi9.setFill(PinkRectD);
        SmallrectProductNahdi9.setArcWidth(10);
        SmallrectProductNahdi9.setArcHeight(10);
        SmallrectProductNahdi9.setTranslateY(62);

        Image nahdi9 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi9.png");
        ImageView nahdiImg9 = new ImageView(nahdi9);//
        nahdiImg9.setFitHeight(90);
        nahdiImg9.setFitWidth(80);
        nahdiImg9.setTranslateY(-30);

        Label nahdi9Lb = new Label("Baby Bottle \n60.68SR");
        nahdi9Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi9Lb.setPadding(new Insets(0, 28, 20, 0));
        nahdi9Lb.setTranslateY(40);
        
        ImageView listbtn1view9 = new ImageView(listimg1);//
        listbtn1view9.setFitHeight(68);
        listbtn1view9.setFitWidth(68);
        
        ImageView wishlistView9 = new ImageView(wishlistimg1);
        wishlistView9.setFitHeight(50);
        wishlistView9.setFitWidth(50);
        
        Button listButton9 = new Button();
        listButton9.setGraphic(new StackPane(listbtn1view9));
        listButton9.setPrefSize(35, 35);
        listButton9.setTranslateY(65);
        listButton9.setTranslateX(20);
        listButton9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton9 = new Button();
        wishlistButton9.setGraphic(new StackPane(wishlistView9));
        wishlistButton9.setPrefSize(35, 35);
        wishlistButton9.setTranslateY(61);
        wishlistButton9.setTranslateX(-20);
        wishlistButton9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi9.getChildren().addAll(rectProductNahdi9, SmallrectProductNahdi9,
                 nahdiImg9, nahdi9Lb , wishlistButton9 , listButton9);
/////////////////////////////////////////////////////////
        StackPane rectitemsNahdi10 = new StackPane();
        Rectangle rectProductNahdi10 = new Rectangle(110, 155);
        rectProductNahdi10.setFill(PinkRectL);
        rectProductNahdi10.setArcWidth(10);
        rectProductNahdi10.setArcHeight(10);

        Rectangle SmallrectProductNahdi10 = new Rectangle(110, 30);
        SmallrectProductNahdi10.setFill(PinkRectD);
        SmallrectProductNahdi10.setArcWidth(10);
        SmallrectProductNahdi10.setArcHeight(10);
        SmallrectProductNahdi10.setTranslateY(62);

        Image nahdi10 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/nahdi10.png");
        ImageView nahdiImg10 = new ImageView(nahdi10);
        nahdiImg10.setFitHeight(105);
        nahdiImg10.setFitWidth(95);
        nahdiImg10.setTranslateY(-30);

        Label nahdi10Lb = new Label("Multivitamin \nGummies  100.80SR");
        nahdi10Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        nahdi10Lb.setPadding(new Insets(0, 5, 17, 0));
        nahdi10Lb.setTranslateY(38);
        
        ImageView listbtn1view10 = new ImageView(listimg1);//
        listbtn1view10.setFitHeight(68);
        listbtn1view10.setFitWidth(68);
        
        ImageView wishlistView10 = new ImageView(wishlistimg1);
        wishlistView10.setFitHeight(50);
        wishlistView10.setFitWidth(50);
        
        Button listButton10 = new Button();
        listButton10.setGraphic(new StackPane(listbtn1view10));
        listButton10.setPrefSize(35, 35);
        listButton10.setTranslateY(65);
        listButton10.setTranslateX(20);
        listButton10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton10 = new Button();
        wishlistButton10.setGraphic(new StackPane(wishlistView10));
        wishlistButton10.setPrefSize(35, 35);
        wishlistButton10.setTranslateY(61);
        wishlistButton10.setTranslateX(-20);
        wishlistButton10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNahdi10.getChildren().addAll(rectProductNahdi10, SmallrectProductNahdi10
                , nahdiImg10, nahdi10Lb , wishlistButton10 , listButton10);

        itemsBoxNahdi5.getChildren().addAll(rectitemsNahdi9, rectitemsNahdi10);

        centerBox.getChildren().addAll(centerSpending, itemsBoxNahdi1, itemsBoxNahdi2,
                 itemsBoxNahdi3, itemsBoxNahdi4, itemsBoxNahdi5);
        
        
        ScrollPane scrollPane = new ScrollPane(centerBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        // bottom 
        StackPane bottomNahdiroot = new StackPane();

        Rectangle rectangleB = new Rectangle();
        rectangleB.setWidth(360);
        rectangleB.setHeight(60);
        rectangleB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleB, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottomNahdiroot.getChildren().addAll(rectangleB, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

           
        nahdiPane.setTop(topNahdiroot);       
        nahdiPane.setCenter(scrollPane);
        nahdiPane.setBottom(bottomNahdiroot);

        Scene scene = new Scene(nahdiPane, 350, 600);
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); //


        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        ProfileScene profileScene = new ProfileScene();

        backImg.setOnMousePressed(e->{
            homePageScene.start(primaryStage);
        });

        homeButton.setOnMousePressed(e->{
            homePageScene.start(primaryStage);

        });

        wishlistButton.setOnMousePressed(e->{
            wishlistScene.start(primaryStage );

        });


        listButton.setOnMousePressed(e->{
            listScene.start(primaryStage );

        });

//        profileButton.setOnMousePressed(e->{    // profile button
//                    profileScene.start(new Stage() );

//              });
    }
    
    
  
}
