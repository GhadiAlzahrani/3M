/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class NiceOne extends Application {

    @Override
    public void start(Stage primaryStage) {
        BorderPane niceonePane = new BorderPane();
        niceonePane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topNiceoneroot = new StackPane();

        Rectangle rectangleT = new Rectangle();
        rectangleT.setX(500);
        rectangleT.setY(80);
        rectangleT.setWidth(356);
        rectangleT.setHeight(90);
        rectangleT.setFill(blueRect);
        
        ////back//
        Image back = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);
       

        Text niceoneText = new Text("Niceone");
        niceoneText.setStyle("-fx-font: normal bold 14px 'serif'");
        niceoneText.setFill(Color.WHITE);

        StackPane.setAlignment(niceoneText, Pos.CENTER_LEFT);
        StackPane.setMargin(niceoneText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleT, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchField = new TextField();
        searchField.setFocusTraversable(false);
        searchField.setPromptText("Search here ...");
        searchField.setStyle("-fx-font: normal 10px 'serif'");
        searchField.setPrefWidth(200);
        searchField.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchField.setShape(searchFieldShape);

        Image searchImage = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\search.png");
        ImageView searchView = new ImageView(searchImage);
        searchView.setFitHeight(19);
        searchView.setFitWidth(22);

        StackPane.setMargin(searchView, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainer = new StackPane();
        searchFieldContainer.getChildren().addAll(searchField, searchView);

        HBox searchBox = new HBox(searchFieldContainer);

        StackPane.setMargin(searchBox, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\notices.png");
        ImageView noticeView = new ImageView(noticeImage);
        noticeView.setFitHeight(20);
        noticeView.setFitWidth(15);

        Button noticeButton = new Button();
        noticeButton.setGraphic(new StackPane(noticeView));
        noticeButton.setPrefSize(30, 30);
        noticeButton.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButton, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButton, Pos.CENTER_RIGHT);

        ////list //////
        Image list1 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list1.png");
        ImageView list1Img = new ImageView(list1);//
        list1Img.setFitHeight(18);
        list1Img.setFitWidth(23);

        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topNiceoneroot.getChildren().addAll(rectangleT, niceoneText, searchBox,
                 noticeButton, list1Img ,backImg);
        niceonePane.setTop(topNiceoneroot);

        //---------- center -----------//
        VBox centerBox = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBox.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpending = new StackPane();

        Rectangle rectProduct1 = new Rectangle(200, 70);
        rectProduct1.setFill(PinkRectD);
        rectProduct1.setArcWidth(10);
        rectProduct1.setArcHeight(10);
 

        Label spendingLb = new Label("Total Spending");
        spendingLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLb.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpending.setPadding(new Insets(20, 55, 0, 60));
        centerSpending.getChildren().addAll(rectProduct1, spendingLb);

        //items recnagles 
        //first 2
        HBox itemsBox = new HBox(40);

        itemsBox.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNiceone1 = new StackPane();
        Rectangle rectProductNiceone1 = new Rectangle(110, 155);
        rectProductNiceone1.setFill(PinkRectL);
        rectProductNiceone1.setArcWidth(10);
        rectProductNiceone1.setArcHeight(10);

        Rectangle SmallrectProductNiceone1 = new Rectangle(110, 30);
        SmallrectProductNiceone1.setFill(PinkRectD);
        SmallrectProductNiceone1.setArcWidth(10);
        SmallrectProductNiceone1.setArcHeight(10);
        SmallrectProductNiceone1.setTranslateY(62);

        Image niceone1 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone1.png");
        ImageView niceoneImg1 = new ImageView(niceone1);//
        niceoneImg1.setFitHeight(80);
        niceoneImg1.setFitWidth(80);
        niceoneImg1.setTranslateY(-31);

        Label niceone1Lb = new Label("bene tint \n100SR");
        niceone1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone1Lb.setPadding(new Insets(0, 50, 30, 0));
        niceone1Lb.setTranslateY(45);

        Image listimg1 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list.png");
        ImageView listbtn1view1 = new ImageView(listimg1);//
        listbtn1view1.setFitHeight(68);
        listbtn1view1.setFitWidth(68);

        Button listButton1 = new Button();
        listButton1.setGraphic(new StackPane(listbtn1view1));
        listButton1.setPrefSize(35, 35);
        listButton1.setTranslateY(65);
        listButton1.setTranslateX(20);
        listButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlistimg1 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\wishlist.png");
        ImageView wishlistView1 = new ImageView(wishlistimg1);
        wishlistView1.setFitHeight(50);
        wishlistView1.setFitWidth(50);
        
        Button wishlistButton1 = new Button();
        wishlistButton1.setGraphic(new StackPane(wishlistView1));
        wishlistButton1.setPrefSize(35, 35);
        wishlistButton1.setTranslateY(61);
        wishlistButton1.setTranslateX(-20);
        wishlistButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNiceone1.getChildren().addAll(rectProductNiceone1, SmallrectProductNiceone1,
                 niceoneImg1, niceone1Lb, listButton1 , wishlistButton1);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsNiceone2 = new StackPane();
        Rectangle rectProductNiceone2 = new Rectangle(110, 155);
        rectProductNiceone2.setFill(PinkRectL);
        rectProductNiceone2.setArcWidth(10);
        rectProductNiceone2.setArcHeight(10);

        Rectangle SmallrectProductNiceone2 = new Rectangle(110, 30);
        SmallrectProductNiceone2.setFill(PinkRectD);
        SmallrectProductNiceone2.setArcWidth(10);
        SmallrectProductNiceone2.setArcHeight(10);
        SmallrectProductNiceone2.setTranslateY(62);

        Image niceone2 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone2.png");
        ImageView niceoneImg2 = new ImageView(niceone2);//
        niceoneImg2.setFitHeight(90);
        niceoneImg2.setFitWidth(100);
        niceoneImg2.setTranslateY(-28);

        Label niceone2Lb = new Label("Roughness Relief Lotion\n113.85SR");
        niceone2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone2Lb.setPadding(new Insets(0, 0, 30, 0));
        niceone2Lb.setTranslateY(45);
        
        ImageView listbtn1view2 = new ImageView(listimg1);//
        listbtn1view2.setFitHeight(68);
        listbtn1view2.setFitWidth(68);
        
        ImageView wishlistView2 = new ImageView(wishlistimg1);
        wishlistView2.setFitHeight(50);
        wishlistView2.setFitWidth(50);
        
        Button listButton2 = new Button();
        listButton2.setGraphic(new StackPane(listbtn1view2));
        listButton2.setPrefSize(35, 35);
        listButton2.setTranslateY(65);
        listButton2.setTranslateX(20);
        listButton2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton2 = new Button();
        wishlistButton2.setGraphic(new StackPane(wishlistView2));
        wishlistButton2.setPrefSize(35, 35);
        wishlistButton2.setTranslateY(61);
        wishlistButton2.setTranslateX(-20);
        wishlistButton2.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNiceone2.getChildren().addAll(rectProductNiceone2, SmallrectProductNiceone2,
                 niceoneImg2, niceone2Lb ,  wishlistButton2 ,listButton2);

        itemsBox.getChildren().addAll(rectitemsNiceone1, rectitemsNiceone2);

        // second 2
        HBox itemsBox2 = new HBox(40);

        itemsBox2.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNiceone3 = new StackPane();
        Rectangle rectProductNiceone3 = new Rectangle(110, 155);
        rectProductNiceone3.setFill(PinkRectL);
        rectProductNiceone3.setArcWidth(10);
        rectProductNiceone3.setArcHeight(10);

        Rectangle SmallrectProductNiceone3 = new Rectangle(110, 30);
        SmallrectProductNiceone3.setFill(PinkRectD);
        SmallrectProductNiceone3.setArcWidth(10);
        SmallrectProductNiceone3.setArcHeight(10);
        SmallrectProductNiceone3.setTranslateY(62);

        Image niceone3 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone3.png");
        ImageView niceoneImg3 = new ImageView(niceone3);//
        niceoneImg3.setFitHeight(90);
        niceoneImg3.setFitWidth(75);
        niceoneImg3.setTranslateY(-38);

        Label niceone3Lb = new Label("Jamaica Black Castor \nOil Masque \n72.45SR");
        niceone3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone3Lb.setPadding(new Insets(0, 0, 30, 0));
        niceone3Lb.setTranslateY(34);
        
        ImageView listbtn1view3 = new ImageView(listimg1);//
        listbtn1view3.setFitHeight(68);
        listbtn1view3.setFitWidth(68);
        
        ImageView wishlistView3 = new ImageView(wishlistimg1);
        wishlistView3.setFitHeight(50);
        wishlistView3.setFitWidth(50);
        
        Button listButton3 = new Button();
        listButton3.setGraphic(new StackPane(listbtn1view3));
        listButton3.setPrefSize(35, 35);
        listButton3.setTranslateY(65);
        listButton3.setTranslateX(20);
        listButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton3 = new Button();
        wishlistButton3.setGraphic(new StackPane(wishlistView3));
        wishlistButton3.setPrefSize(35, 35);
        wishlistButton3.setTranslateY(61);
        wishlistButton3.setTranslateX(-20);
        wishlistButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNiceone3.getChildren().addAll(rectProductNiceone3, SmallrectProductNiceone3,
                 niceoneImg3, niceone3Lb , wishlistButton3 , listButton3);
        
        //////////////////////////////////////////////////
        StackPane rectitemsNiceone4 = new StackPane();
        Rectangle rectProductNiceone4 = new Rectangle(110, 155);
        rectProductNiceone4.setFill(PinkRectL);
        rectProductNiceone4.setArcWidth(10);
        rectProductNiceone4.setArcHeight(10);

        Rectangle SmallrectProductNiceone4 = new Rectangle(110, 30);
        SmallrectProductNiceone4.setFill(PinkRectD);
        SmallrectProductNiceone4.setArcWidth(10);
        SmallrectProductNiceone4.setArcHeight(10);
        SmallrectProductNiceone4.setTranslateY(62);

        Image niceone4 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone4.png");
        ImageView niceoneImg4 = new ImageView(niceone4);//
        niceoneImg4.setFitHeight(70);
        niceoneImg4.setFitWidth(60);
        niceoneImg4.setTranslateY(-35);

        Label niceone4Lb = new Label("Professional Mekeup \nthe BrowGlue \n45SR");
        niceone4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone4Lb.setTranslateY(20);
        
        ImageView listbtn1view4 = new ImageView(listimg1);//
        listbtn1view4.setFitHeight(68);
        listbtn1view4.setFitWidth(68);
        
        ImageView wishlistView4 = new ImageView(wishlistimg1);
        wishlistView4.setFitHeight(50);
        wishlistView4.setFitWidth(50);
        
        Button listButton4 = new Button();
        listButton4.setGraphic(new StackPane(listbtn1view4));
        listButton4.setPrefSize(35, 35);
        listButton4.setTranslateY(65);
        listButton4.setTranslateX(20);
        listButton4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton4 = new Button();
        wishlistButton4.setGraphic(new StackPane(wishlistView4));
        wishlistButton4.setPrefSize(35, 35);
        wishlistButton4.setTranslateY(61);
        wishlistButton4.setTranslateX(-20);
        wishlistButton4.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone4.getChildren().addAll(rectProductNiceone4, SmallrectProductNiceone4,
                 niceoneImg4, niceone4Lb, wishlistButton4, listButton4);

        itemsBox2.getChildren().addAll(rectitemsNiceone3, rectitemsNiceone4);

        // third 2 /////////////////
        HBox itemsBox3 = new HBox(40);

        itemsBox3.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNiceone5 = new StackPane();
        Rectangle rectProductNiceone5 = new Rectangle(110, 155);
        rectProductNiceone5.setFill(PinkRectL);
        rectProductNiceone5.setArcWidth(10);
        rectProductNiceone5.setArcHeight(10);

        Rectangle SmallrectProductNiceone5 = new Rectangle(110, 30);
        SmallrectProductNiceone5.setFill(PinkRectD);
        SmallrectProductNiceone5.setArcWidth(10);
        SmallrectProductNiceone5.setArcHeight(10);
        SmallrectProductNiceone5.setTranslateY(62);

        Image niceone5 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone5.png");
        ImageView niceoneImg5 = new ImageView(niceone5);//
        niceoneImg5.setFitHeight(70);
        niceoneImg5.setFitWidth(60);
        niceoneImg5.setTranslateY(-36);

        Label niceone5Lb = new Label("Delina Exclusif \nPerfume \n1,410SR");
        niceone5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone5Lb.setPadding(new Insets(0, 25, 25, 0));
        niceone5Lb.setTranslateY(34);
        
        
        ImageView listbtn1view5 = new ImageView(listimg1);//
        listbtn1view5.setFitHeight(68);
        listbtn1view5.setFitWidth(68);
        
        ImageView wishlistView5 = new ImageView(wishlistimg1);
        wishlistView5.setFitHeight(50);
        wishlistView5.setFitWidth(50);
        
        Button listButton5 = new Button();
        listButton5.setGraphic(new StackPane(listbtn1view5));
        listButton5.setPrefSize(35, 35);
        listButton5.setTranslateY(65);
        listButton5.setTranslateX(20);
        listButton5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton5 = new Button();
        wishlistButton5.setGraphic(new StackPane(wishlistView5));
        wishlistButton5.setPrefSize(35, 35);
        wishlistButton5.setTranslateY(61);
        wishlistButton5.setTranslateX(-20);
        wishlistButton5.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone5.getChildren().addAll(rectProductNiceone5, SmallrectProductNiceone5,
                 niceoneImg5, niceone5Lb, wishlistButton5, listButton5);
        //////////////////////////////////////////////
        StackPane rectitemsNiceone6 = new StackPane();
        Rectangle rectProductNiceone6 = new Rectangle(110, 155);
        rectProductNiceone6.setFill(PinkRectL);
        rectProductNiceone6.setArcWidth(10);
        rectProductNiceone6.setArcHeight(10);

        Rectangle SmallrectProductNiceone6 = new Rectangle(110, 30);
        SmallrectProductNiceone6.setFill(PinkRectD);
        SmallrectProductNiceone6.setArcWidth(10);
        SmallrectProductNiceone6.setArcHeight(10);
        SmallrectProductNiceone6.setTranslateY(62);

        Image niceone6 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone6.png");
        ImageView niceoneImg6 = new ImageView(niceone6);//
        niceoneImg6.setFitHeight(80);
        niceoneImg6.setFitWidth(40);
        niceoneImg6.setTranslateY(-35);

        Label niceone6Lb = new Label("Tresemme Heat \nProtection \n72SR");
        niceone6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone6Lb.setPadding(new Insets(0, 20, 25, 0));
        niceone6Lb.setTranslateY(35);
        
        ImageView listbtn1view6 = new ImageView(listimg1);//
        listbtn1view6.setFitHeight(68);
        listbtn1view6.setFitWidth(68);
        
        ImageView wishlistView6 = new ImageView(wishlistimg1);
        wishlistView6.setFitHeight(50);
        wishlistView6.setFitWidth(50);
        
        Button listButton6 = new Button();
        listButton6.setGraphic(new StackPane(listbtn1view6));
        listButton6.setPrefSize(35, 35);
        listButton6.setTranslateY(65);
        listButton6.setTranslateX(20);
        listButton6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton6 = new Button();
        wishlistButton6.setGraphic(new StackPane(wishlistView6));
        wishlistButton6.setPrefSize(35, 35);
        wishlistButton6.setTranslateY(61);
        wishlistButton6.setTranslateX(-20);
        wishlistButton6.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone6.getChildren().addAll(rectProductNiceone6, SmallrectProductNiceone6,
                 niceoneImg6, niceone6Lb , wishlistButton6 , listButton6 );

        itemsBox3.getChildren().addAll(rectitemsNiceone5, rectitemsNiceone6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4 = new HBox(40);

        itemsBox4.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNiceone7 = new StackPane();
        Rectangle rectProductNiceone7 = new Rectangle(110, 155);
        rectProductNiceone7.setFill(PinkRectL);
        rectProductNiceone7.setArcWidth(10);
        rectProductNiceone7.setArcHeight(10);

        Rectangle SmallrectProductNiceone7 = new Rectangle(110, 30);
        SmallrectProductNiceone7.setFill(PinkRectD);
        SmallrectProductNiceone7.setArcWidth(10);
        SmallrectProductNiceone7.setArcHeight(10);
        SmallrectProductNiceone7.setTranslateY(62);

        Image niceone7 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone7.png");
        ImageView niceoneImg7 = new ImageView(niceone7);//
        niceoneImg7.setFitHeight(90);
        niceoneImg7.setFitWidth(85);
        niceoneImg7.setTranslateY(-30);

        Label niceone7Lb = new Label("Hoola Matte Bronzer \n175SR");
        niceone7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone7Lb.setPadding(new Insets(0, 0, 25, 0));
        niceone7Lb.setTranslateY(40);
        
        ImageView listbtn1view7 = new ImageView(listimg1);//
        listbtn1view7.setFitHeight(68);
        listbtn1view7.setFitWidth(68);
        
        ImageView wishlistView7 = new ImageView(wishlistimg1);
        wishlistView7.setFitHeight(50);
        wishlistView7.setFitWidth(50);
        
        Button listButton7 = new Button();
        listButton7.setGraphic(new StackPane(listbtn1view7));
        listButton7.setPrefSize(35, 35);
        listButton7.setTranslateY(65);
        listButton7.setTranslateX(20);
        listButton7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton7 = new Button();
        wishlistButton7.setGraphic(new StackPane(wishlistView7));
        wishlistButton7.setPrefSize(35, 35);
        wishlistButton7.setTranslateY(61);
        wishlistButton7.setTranslateX(-20);
        wishlistButton7.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone7.getChildren().addAll(rectProductNiceone7, SmallrectProductNiceone7,
                 niceoneImg7, niceone7Lb, wishlistButton7 , listButton7);
        ///////////////////////////////////////////////
        StackPane rectitemsNiceone8 = new StackPane();
        Rectangle rectProductNiceone8 = new Rectangle(110, 155);
        rectProductNiceone8.setFill(PinkRectL);
        rectProductNiceone8.setArcWidth(10);
        rectProductNiceone8.setArcHeight(10);

        Rectangle SmallrectProductNiceone8 = new Rectangle(110, 30);
        SmallrectProductNiceone8.setFill(PinkRectD);
        SmallrectProductNiceone8.setArcWidth(10);
        SmallrectProductNiceone8.setArcHeight(10);
        SmallrectProductNiceone8.setTranslateY(62);

        Image niceone8 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone8.png");
        ImageView niceoneImg8 = new ImageView(niceone8);//
        niceoneImg8.setFitHeight(115);
        niceoneImg8.setFitWidth(95);
        niceoneImg8.setTranslateY(-34);

        Label niceone8Lb = new Label("AHA.BHA.PHA30 Days \nMiracle Starter  \n64SR");
        niceone8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone8Lb.setPadding(new Insets(0, 0, 25, 0));
        niceone8Lb.setTranslateY(38);
        
        ImageView listbtn1view8 = new ImageView(listimg1);//
        listbtn1view8.setFitHeight(68);
        listbtn1view8.setFitWidth(68);
        
        ImageView wishlistView8 = new ImageView(wishlistimg1);
        wishlistView8.setFitHeight(50);
        wishlistView8.setFitWidth(50);
        
        Button listButton8 = new Button();
        listButton8.setGraphic(new StackPane(listbtn1view8));
        listButton8.setPrefSize(35, 35);
        listButton8.setTranslateY(65);
        listButton8.setTranslateX(20);
        listButton8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton8 = new Button();
        wishlistButton8.setGraphic(new StackPane(wishlistView8));
        wishlistButton8.setPrefSize(35, 35);
        wishlistButton8.setTranslateY(61);
        wishlistButton8.setTranslateX(-20);
        wishlistButton8.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone8.getChildren().addAll(rectProductNiceone8 , SmallrectProductNiceone8
                , niceoneImg8, niceone8Lb , wishlistButton8 , listButton8);

        itemsBox4.getChildren().addAll(rectitemsNiceone7, rectitemsNiceone8 );

        // fifth 2/////////////////////////////
        HBox itemsBox5 = new HBox(40);

        itemsBox5.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNiceone9 = new StackPane();
        Rectangle rectProductNiceone9 = new Rectangle(110, 155);
        rectProductNiceone9.setFill(PinkRectL);
        rectProductNiceone9.setArcWidth(10);
        rectProductNiceone9.setArcHeight(10);

        Rectangle SmallrectProductNiceone9 = new Rectangle(110, 30);
        SmallrectProductNiceone9.setFill(PinkRectD);
        SmallrectProductNiceone9.setArcWidth(10);
        SmallrectProductNiceone9.setArcHeight(10);
        SmallrectProductNiceone9.setTranslateY(62);

        Image niceone9 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone9.png");
        ImageView niceoneImg9 = new ImageView(niceone9);//
        niceoneImg9.setFitHeight(88);
        niceoneImg9.setFitWidth(70);
        niceoneImg9.setTranslateY(-37);

        Label niceone9Lb = new Label("Jamaica Black Caster \nOil Shampoo \n195SR");
        niceone9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone9Lb.setPadding(new Insets(0, 5, 25, 0));
        niceone9Lb.setTranslateY(40);
        
        ImageView listbtn1view9 = new ImageView(listimg1);//
        listbtn1view9.setFitHeight(68);
        listbtn1view9.setFitWidth(68);
        
        ImageView wishlistView9 = new ImageView(wishlistimg1);
        wishlistView9.setFitHeight(50);
        wishlistView9.setFitWidth(50);
        
        Button listButton9 = new Button();
        listButton9.setGraphic(new StackPane(listbtn1view9));
        listButton9.setPrefSize(35, 35);
        listButton9.setTranslateY(65);
        listButton9.setTranslateX(20);
        listButton9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton9 = new Button();
        wishlistButton9.setGraphic(new StackPane(wishlistView9));
        wishlistButton9.setPrefSize(35, 35);
        wishlistButton9.setTranslateY(61);
        wishlistButton9.setTranslateX(-20);
        wishlistButton9.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone9.getChildren().addAll(rectProductNiceone9, SmallrectProductNiceone9,
                 niceoneImg9, niceone9Lb , wishlistButton9 , listButton9);
/////////////////////////////////////////////////////////
        StackPane rectitemsNiceone10 = new StackPane();
        Rectangle rectProductNiceone10 = new Rectangle(110, 155);
        rectProductNiceone10.setFill(PinkRectL);
        rectProductNiceone10.setArcWidth(10);
        rectProductNiceone10.setArcHeight(10);

        Rectangle SmallrectProductNiceone10 = new Rectangle(110, 30);
        SmallrectProductNiceone10.setFill(PinkRectD);
        SmallrectProductNiceone10.setArcWidth(10);
        SmallrectProductNiceone10.setArcHeight(10);
        SmallrectProductNiceone10.setTranslateY(62);

        Image niceone10 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\niceone10.png");
        ImageView niceoneImg10 = new ImageView(niceone10);//
        niceoneImg10.setFitHeight(80);
        niceoneImg10.setFitWidth(70);
        niceoneImg10.setTranslateY(-35);

        Label niceone10Lb = new Label("Acne Creamy Wash \n4% Benzoyl \n76SR");
        niceone10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        niceone10Lb.setPadding(new Insets(0, 0, 25, 0));
        niceone10Lb.setTranslateY(38);
        
        ImageView listbtn1view10 = new ImageView(listimg1);//
        listbtn1view10.setFitHeight(68);
        listbtn1view10.setFitWidth(68);
        
        ImageView wishlistView10 = new ImageView(wishlistimg1);
        wishlistView10.setFitHeight(50);
        wishlistView10.setFitWidth(50);
        
        Button listButton10 = new Button();
        listButton10.setGraphic(new StackPane(listbtn1view10));
        listButton10.setPrefSize(35, 35);
        listButton10.setTranslateY(65);
        listButton10.setTranslateX(20);
        listButton10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton10 = new Button();
        wishlistButton10.setGraphic(new StackPane(wishlistView10));
        wishlistButton10.setPrefSize(35, 35);
        wishlistButton10.setTranslateY(61);
        wishlistButton10.setTranslateX(-20);
        wishlistButton10.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNiceone10.getChildren().addAll(rectProductNiceone10, SmallrectProductNiceone10
                , niceoneImg10, niceone10Lb , wishlistButton10 , listButton10);

        itemsBox5.getChildren().addAll(rectitemsNiceone9, rectitemsNiceone10);

        centerBox.getChildren().addAll(centerSpending, itemsBox, itemsBox2,
                 itemsBox3, itemsBox4, itemsBox5);
        
        
        ScrollPane scrollPane = new ScrollPane(centerBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        // bottom 
        StackPane bottomNiceoneroot = new StackPane();

        Rectangle rectangleB = new Rectangle();
        rectangleB.setWidth(360);
        rectangleB.setHeight(60);
        rectangleB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleB, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottomNiceoneroot.getChildren().addAll(rectangleB, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

           
        niceonePane.setTop(topNiceoneroot);       
        niceonePane.setCenter(scrollPane);
        niceonePane.setBottom(bottomNiceoneroot);

        Scene scene = new Scene(niceonePane, 350, 600);
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); //

        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        ProfileScene profileScene = new ProfileScene();

//-------------------------------- ACTION ----------------------------------------------//


        backImg.setOnMouseClicked(e -> {
            homePageScene.start(primaryStage);
        });


        homeButton.setOnAction(e -> {
            homePageScene.start(primaryStage);
        });

        wishlistButton.setOnAction(e -> {
            wishlistScene.start(primaryStage);
        });

        listButton.setOnAction(e -> {
            listScene.start(primaryStage);
        });

//        profileButton.setOnAction(e -> {
//            profileScene.start(new Stage());
//        });
    }



}

