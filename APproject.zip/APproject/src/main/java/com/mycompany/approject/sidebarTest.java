/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */



import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class sidebarTest extends Application {
    
    BudgetScene budgetScene;

    @Override
    public void start(Stage primaryStage) {
        BorderPane sidebarPane = new BorderPane();
        sidebarPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topsidebarroot = new StackPane();

        Rectangle rectangleTsidebar = new Rectangle();
        rectangleTsidebar.setX(500);
        rectangleTsidebar.setY(80);
        rectangleTsidebar.setWidth(356);
        rectangleTsidebar.setHeight(90);
        rectangleTsidebar.setFill(blueRect);

        ////back//
        Image back657 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\backarrow2.png");
        ImageView sidebarBackImg = new ImageView(back657);//
        sidebarBackImg.setFitHeight(25);
        sidebarBackImg.setFitWidth(25);
        StackPane.setMargin(sidebarBackImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(sidebarBackImg, Pos.CENTER_LEFT);


        Text sidebarText = new Text("Sidebar");
        sidebarText.setStyle("-fx-font: normal bold 14px 'serif'");
        sidebarText.setFill(Color.WHITE);

        StackPane.setAlignment(sidebarText, Pos.CENTER_LEFT);
        StackPane.setMargin(sidebarText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTsidebar, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldsidebar = new TextField();
        searchFieldsidebar.setFocusTraversable(false);
        searchFieldsidebar.setPromptText("Search here ...");
        searchFieldsidebar.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldsidebar.setPrefWidth(200);
        searchFieldsidebar.setPrefHeight(25);
        Rectangle searchFieldShapesidebar = new Rectangle();
        searchFieldShapesidebar.setWidth(200);
        searchFieldShapesidebar.setHeight(25);
        searchFieldShapesidebar.setArcWidth(25);
        searchFieldShapesidebar.setArcHeight(30);
        searchFieldsidebar.setShape(searchFieldShapesidebar);

        Image searchImagesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\search.png");
        ImageView searchViewsidebar = new ImageView(searchImagesidebar);
        searchViewsidebar.setFitHeight(19);
        searchViewsidebar.setFitWidth(22);

        StackPane.setMargin(searchViewsidebar, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainersidebar = new StackPane();
        searchFieldContainersidebar.getChildren().addAll(searchFieldsidebar, searchViewsidebar);

        HBox searchBoxsidebar = new HBox(searchFieldContainersidebar);

        StackPane.setMargin(searchBoxsidebar, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImagesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\notices.png");
        ImageView noticeViewsidebar = new ImageView(noticeImagesidebar);
        noticeViewsidebar.setFitHeight(20);
        noticeViewsidebar.setFitWidth(15);

        Button noticeButtonsidebar = new Button();
        noticeButtonsidebar.setGraphic(new StackPane(noticeViewsidebar));
        noticeButtonsidebar.setPrefSize(30, 30);
        noticeButtonsidebar.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonsidebar, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonsidebar, Pos.CENTER_RIGHT);

//        ////list //////
//        Image list1 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list1.png");
//        ImageView list1Img = new ImageView(list1);//
//        list1Img.setFitHeight(18);
//        list1Img.setFitWidth(23);
//
//        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
//        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topsidebarroot.getChildren().addAll(rectangleTsidebar, sidebarText, searchBoxsidebar,
                noticeButtonsidebar, sidebarBackImg);
        sidebarPane.setTop(topsidebarroot);

        ////////////////////////////////////////////////////




        // bottom
        StackPane bottomsidebarroot = new StackPane();

        Rectangle rectanglesidebar = new Rectangle();
        rectanglesidebar.setWidth(360);
        rectanglesidebar.setHeight(60);
        rectanglesidebar.setFill(Color.web("657da1"));

        StackPane.setMargin(rectanglesidebar, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\home.png");

        ImageView homeViewsidebar = new ImageView(imageHomesidebar);
        homeViewsidebar.setFitHeight(50);
        homeViewsidebar.setFitWidth(60);

        Button homeButtonsidebar = new Button();
        homeButtonsidebar.setGraphic(new StackPane(homeViewsidebar));
        homeButtonsidebar.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonsidebar, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonsidebar, new Insets(10, 0, 0, 30));

        Text textHomesidebar = new Text("Home");
        textHomesidebar.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomesidebar.setFill(Color.WHITE);

        StackPane.setAlignment(textHomesidebar, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomesidebar, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImagesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\wishlist.png");
        ImageView wishlistViewsidebar = new ImageView(wishlistImagesidebar);
        wishlistViewsidebar.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewsidebar.setFitWidth(70);

        Button wishlistButtonsidebar = new Button();
        wishlistButtonsidebar.setGraphic(new StackPane(wishlistViewsidebar));
        wishlistButtonsidebar.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonsidebar, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonsidebar, new Insets(10, 0, 0, 91));

        Text wishlistTextsidebar = new Text("Wishlist");
        wishlistTextsidebar.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextsidebar.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextsidebar, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextsidebar, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImagesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list.png");
        ImageView listViewsidebar = new ImageView(listImagesidebar);
        listViewsidebar.setFitHeight(70); //setting the fit height and width of the image view
        listViewsidebar.setFitWidth(80);

        Button listButtonsidebar = new Button();
        listButtonsidebar.setGraphic(new StackPane(listViewsidebar));
        listButtonsidebar.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonsidebar, Pos.CENTER);
        StackPane.setMargin(listButtonsidebar, new Insets(15, 0, 0, 60));

        Text listTextsidebar = new Text("List");
        listTextsidebar.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextsidebar.setFill(Color.WHITE);

        StackPane.setAlignment(listTextsidebar, Pos.CENTER);
        StackPane.setMargin(listTextsidebar, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImagesidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\profile.png");
        ImageView profileViewsidebar = new ImageView(profileImagesidebar);
        profileViewsidebar.setFitHeight(25); //setting the fit height and width of the image view
        profileViewsidebar.setFitWidth(31);

        Button profileButtonsidebar = new Button();
        profileButtonsidebar.setGraphic(new StackPane(profileViewsidebar));
        profileButtonsidebar.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonsidebar, Pos.CENTER);
        StackPane.setMargin(profileButtonsidebar, new Insets(19, 0, 0, 200));

        Text profileTextsidebar = new Text("Profile");
        profileTextsidebar.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextsidebar.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextsidebar, Pos.CENTER);
        StackPane.setMargin(profileTextsidebar, new Insets(50, 0, 0, 200));



        bottomsidebarroot.getChildren().addAll(rectanglesidebar, homeButtonsidebar, textHomesidebar
                , wishlistButtonsidebar, wishlistTextsidebar, listButtonsidebar, listTextsidebar, profileButtonsidebar, profileTextsidebar);

        bottomsidebarroot.setPadding(new Insets(0, 0, 0, 0));
        sidebarPane.setTop(topsidebarroot);
        sidebarPane.setBottom(bottomsidebarroot);

        VBox sidebar=new VBox(10);
        sidebar.setPrefWidth(190);
        sidebar.setPrefHeight(130);
        sidebar.setStyle("-fx-background-color: #A8BBC4;");
        sidebar.setTranslateY(-25);
        sidebar.setPadding(new Insets(40, 0, 0, 55));
        // Create buttons for the sidebar

        HBox buttonBox1sidebar = new HBox(10);
        ImageView dashboardViewsidebar = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\dashboard.png");
        dashboardViewsidebar.setFitHeight(15); //setting the fit height and width of the image view
        dashboardViewsidebar.setFitWidth(15);

        Text buttonTextsidebar = new Text("Dashboard"); //
        buttonTextsidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonTextsidebar.setFill(Color.WHITE);
        buttonBox1sidebar.getChildren().addAll(dashboardViewsidebar, buttonTextsidebar);
        buttonBox1sidebar.setAlignment(Pos.CENTER_LEFT);


        Button button1sidebar = new Button();
        button1sidebar.setGraphic(new StackPane(buttonBox1sidebar));
        button1sidebar.setPrefSize(5, 5);
        button1sidebar.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        button1sidebar.setFocusTraversable(false);
        button1sidebar.setTranslateY(30);

        HBox buttonBox2sidebar = new HBox(8);
        ImageView settingsView794 = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\settings.png");
        settingsView794.setFitHeight(15); //setting the fit height and width of the image view
        settingsView794.setFitWidth(15);

        Text buttonText2sidebar = new Text("Look&Feel"); //
        buttonText2sidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonText2sidebar.setFill(Color.WHITE);
        buttonBox2sidebar.getChildren().addAll(settingsView794, buttonText2sidebar);
        buttonBox2sidebar.setAlignment(Pos.CENTER_LEFT);

        Button button2sidebar = new Button();
        button2sidebar.setGraphic(new StackPane(buttonBox2sidebar));
        button2sidebar.setPrefSize(5, 5);
        button2sidebar.setStyle("-fx-background-color: transparent; ");
        button2sidebar.setFocusTraversable(false);
        button2sidebar.setTranslateY(30);

        HBox buttonBox3sidebar = new HBox(10);
        ImageView logoutViewsidebar = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\logout.png");
        logoutViewsidebar.setFitHeight(15); //setting the fit height and width of the image view
        logoutViewsidebar.setFitWidth(15);

        Text buttonText3sidebar = new Text("Log Out"); //
        buttonText3sidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonText3sidebar.setFill(Color.WHITE);
        buttonBox3sidebar.getChildren().addAll(logoutViewsidebar, buttonText3sidebar);
        buttonBox3sidebar.setAlignment(Pos.CENTER_LEFT);


        Button button3sidebar = new Button();
        button3sidebar.setGraphic(new StackPane(buttonBox3sidebar));
        button3sidebar.setPrefSize(5, 5);
        button3sidebar.setStyle("-fx-background-color: transparent; ");
        button3sidebar.setFocusTraversable(false);
        button3sidebar.setTranslateY(10);
        button3sidebar.setTranslateX(2);

        HBox buttonBox4sidebar = new HBox();
        ImageView homViewsidebar = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\home.png");
        homViewsidebar.setFitHeight(30); //setting the fit height and width of the image view
        homViewsidebar.setFitWidth(30);

        Text buttonText4sidebar = new Text("Home"); //
        buttonText4sidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonText4sidebar.setFill(Color.WHITE);
        buttonBox4sidebar.getChildren().addAll(homViewsidebar, buttonText4sidebar);
        buttonBox4sidebar.setAlignment(Pos.CENTER_LEFT);


        Button button4sidebar = new Button();
        button4sidebar.setGraphic(new StackPane(buttonBox4sidebar));
        button4sidebar.setPrefSize(5, 5);
        button4sidebar.setStyle("-fx-background-color: transparent; ");
        button4sidebar.setFocusTraversable(false);
        button4sidebar.setTranslateY(20);
        button4sidebar.setTranslateX(-7);

        HBox buttonBox5sidebar = new HBox(10);
        ImageView budgetViewsidebar = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\budget.png");
        budgetViewsidebar.setFitHeight(25); //setting the fit height and width of the image view
        budgetViewsidebar.setFitWidth(25);

        Text buttonText5sidebar = new Text("Budget");
        buttonText5sidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonText5sidebar.setFill(Color.WHITE);
        buttonBox5sidebar.getChildren().addAll(budgetViewsidebar, buttonText5sidebar);
        buttonBox5sidebar.setAlignment(Pos.CENTER_LEFT);

        Button button5sidebar = new Button();
        button5sidebar.setGraphic(new StackPane(buttonBox5sidebar));
        button5sidebar.setPrefSize(5, 5);
        button5sidebar.setStyle("-fx-background-color: transparent; ");
        button5sidebar.setFocusTraversable(false);
        button5sidebar.setTranslateY(30);
        button5sidebar.setTranslateX(-3);

        HBox buttonBox6sidebar = new HBox(10);
        ImageView profiViewsidebar = new ImageView("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\profile.png");
        profiViewsidebar.setFitHeight(20); //setting the fit height and width of the image view
        profiViewsidebar.setFitWidth(20);

        Text buttonText6sidebar = new Text("Profile"); //
        buttonText6sidebar.setStyle("-fx-font: normal 12px 'serif'");
        buttonText6sidebar.setFill(Color.WHITE);
        buttonBox6sidebar.getChildren().addAll(profiViewsidebar, buttonText6sidebar);
        buttonBox6sidebar.setAlignment(Pos.CENTER_LEFT);


        Button button6sidebar = new Button();
        button6sidebar.setGraphic(new StackPane(buttonBox6sidebar));
        button6sidebar.setPrefSize(5, 5);
        button6sidebar.setStyle("-fx-background-color: transparent; ");
        button6sidebar.setFocusTraversable(false);
        button6sidebar.setTranslateY(10);



        Image logoimgsidebar = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\logo.png");
        ImageView logoViewsidebar = new ImageView(logoimgsidebar);
        logoViewsidebar.setFitHeight(75); //setting the fit height and width of the image view
        logoViewsidebar.setFitWidth(75);
        logoViewsidebar.setTranslateX(5);

        // Add buttons to the sidebar
        sidebar.getChildren().addAll(logoViewsidebar, button5sidebar, button1sidebar, button2sidebar, button4sidebar, button6sidebar, button3sidebar);

        // Set up transition for the sidebar
//        TranslateTransition sidebarTransition = new TranslateTransition(Duration.millis(300), sidebar);
//        sidebarTransition.setFromX(-sidebar.getWidth()+100);
//        sidebarTransition.setToX(0);


        Button toggleButtonsidebar = new Button("");

        Image sideBarimg = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list1.png");
        ImageView sideBarView = new ImageView(sideBarimg);
        sideBarView.setFitHeight(15); //setting the fit height and width of the image view
        sideBarView.setFitWidth(15);

        toggleButtonsidebar.setGraphic(new StackPane(sideBarView));
        toggleButtonsidebar.setPrefSize(4, 4);
        toggleButtonsidebar.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        VBox toggleBox34 = new VBox(toggleButtonsidebar);
        toggleButtonsidebar.setTranslateY(-30);
        toggleButtonsidebar.setTranslateX(140);

        //toggleBox.setAlignment(Pos.CENTER_RIGHT);
        //toggleBox.setPadding(new Insets(0,0,20,0));
        toggleButtonsidebar.setFocusTraversable(false);
        // toggleButton.setOnAction(e -> toggleSidebar(sidebarTransition));

        BorderPane borderPanesidebar = new BorderPane();
        borderPanesidebar.setRight(sidebar);
        borderPanesidebar.setTop(toggleBox34);

        sidebarPane.setRight(borderPanesidebar);

        Scene sidebarScene = new Scene(sidebarPane, 350, 600);
        primaryStage.setScene(sidebarScene); // Place the scene in the stage
        primaryStage.show();


        HomePageScene homePageScenedashboard = new HomePageScene();
        DashboardScene dashboardScenedashboard = new DashboardScene();
     //   BudgetScene budgetScene = new BudgetScene();
        ProfileScene profileScenedashboard = new ProfileScene();
        ColorSettingsScene colorscenedashboard = new ColorSettingsScene();
        App app = new App();


///////-------------------------------- DASBOARD ACTIONS ---------------------------------------//////



//        button1sidebar.setOnAction(e -> {
//            dashboardScenedashboard.start(primaryStage);
//        });
//
//        buttonTextsidebar.setOnMouseClicked(e -> {
//            dashboardScenedashboard.start(primaryStage);
//        });


        button2sidebar.setOnAction(e -> {
            colorscenedashboard.start(primaryStage);
        });

        buttonText2sidebar.setOnMouseClicked(e -> {
            colorscenedashboard.start(primaryStage);
        });

        button3sidebar.setOnAction(e -> {
            app.start(primaryStage);
        });

        buttonText3sidebar.setOnMouseClicked(e -> {
            app.start(primaryStage);
        });

        button4sidebar.setOnAction(e -> {
            homePageScenedashboard.start(primaryStage);
        });

        buttonText4sidebar.setOnMouseClicked(e -> {
            homePageScenedashboard.start(primaryStage);
        });

//        button5sidebar.setOnAction(e -> {
//            budscenedashboard.start(primaryStage);
//        });
//
//        buttonText5sidebar.setOnMouseClicked(e -> {
//            budscenedashboard.start(primaryStage);
//        });
//
//        button6sidebar.setOnAction(e -> {
//            profileScenedashboard.start(primaryStage);
//        });

//        buttonText6sidebar.setOnMouseClicked(e -> {
//            profileScenedashboard.start(stage);
//        });


    }


}


