/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */


import java.util.List;
import javafx.application.Application;
import static javafx.application.Application.launch;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.*;

/**
 * JavaFX App
 */
public class Amazon extends Application {
    
    Session session;
    App app = new App();
    Item item ;
    int iduser;

    @Override
    public void start(Stage primaryStage) {
        BorderPane amazonPane = new BorderPane();
        amazonPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topamazonroot = new StackPane();

        Rectangle rectangleTamazon = new Rectangle();
        rectangleTamazon.setX(500);
        rectangleTamazon.setY(80);
        rectangleTamazon.setWidth(356);
        rectangleTamazon.setHeight(90);
        rectangleTamazon.setFill(blueRect);

        ////back//
        Image backamazon = new Image("file:C:\\Users\\fatim\\Downloads\\backarrow2.png");
        ImageView backImgamazon = new ImageView(backamazon);//
        backImgamazon.setFitHeight(25);
        backImgamazon.setFitWidth(25);
        StackPane.setMargin(backImgamazon, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImgamazon, Pos.CENTER_LEFT);


        Text amazonText = new Text("AMAZON");
        amazonText.setStyle("-fx-font: normal bold 14px 'serif'");
        amazonText.setFill(Color.WHITE);

        StackPane.setAlignment(amazonText, Pos.CENTER_LEFT);
        StackPane.setMargin(amazonText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTamazon, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldamazon = new TextField();
        searchFieldamazon.setFocusTraversable(false);
        searchFieldamazon.setPromptText("Search here ...");
        searchFieldamazon.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldamazon.setPrefWidth(200);
        searchFieldamazon.setPrefHeight(25);
        Rectangle searchFieldShapeamazon = new Rectangle();
        searchFieldShapeamazon.setWidth(200);
        searchFieldShapeamazon.setHeight(25);
        searchFieldShapeamazon.setArcWidth(25);
        searchFieldShapeamazon.setArcHeight(30);
        searchFieldamazon.setShape(searchFieldShapeamazon);

        Image searchImageamazon = new Image("file:C:\\Users\\fatim\\Downloads\\search.png");
        ImageView searchViewamazon = new ImageView(searchImageamazon);
        searchViewamazon.setFitHeight(19);
        searchViewamazon.setFitWidth(22);

        StackPane.setMargin(searchViewamazon, new Insets(0, 0, 0, 170));
        StackPane searchFieldContaineramazon = new StackPane();
        searchFieldContaineramazon.getChildren().addAll(searchFieldamazon, searchViewamazon);

        HBox searchBoxamazon = new HBox(searchFieldContaineramazon);

        StackPane.setMargin(searchBoxamazon, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImageamazon = new Image("file:C:\\Users\\fatim\\Downloads\\nott.png");
        ImageView noticeViewamazon = new ImageView(noticeImageamazon);
        noticeViewamazon.setFitHeight(20);
        noticeViewamazon.setFitWidth(15);

        Button noticeButtonamazon = new Button();
        noticeButtonamazon.setGraphic(new StackPane(noticeViewamazon));
        noticeButtonamazon.setPrefSize(30, 30);
        noticeButtonamazon.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonamazon, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonamazon, Pos.CENTER_RIGHT);

        ////list //////
        Image list1amazon = new Image("file:C:\\Users\\fatim\\Downloads\\list1.png");
        ImageView list1Imgamazon = new ImageView(list1amazon);//
        list1Imgamazon.setFitHeight(18);
        list1Imgamazon.setFitWidth(23);

        StackPane.setMargin(list1Imgamazon, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Imgamazon, Pos.CENTER_RIGHT);

        topamazonroot.getChildren().addAll(rectangleTamazon, amazonText, searchBoxamazon,
                noticeButtonamazon, list1Imgamazon, backImgamazon);
        amazonPane.setTop(topamazonroot);

        //---------- center -----------//
        VBox centerBoxamazon = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxamazon.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendingamazon = new StackPane();

        Rectangle rectProduct1amazon = new Rectangle(200, 70);
        rectProduct1amazon.setFill(PinkRectD);
        rectProduct1amazon.setArcWidth(10);
        rectProduct1amazon.setArcHeight(10);


        Label spendingLbamazon = new Label("Total Spending");
        spendingLbamazon.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLbamazon.setPadding(new Insets(0, 0, 25, 0));


        centerSpendingamazon.setPadding(new Insets(20, 55, 0, 60));
        centerSpendingamazon.getChildren().addAll(rectProduct1amazon, spendingLbamazon);

        //items recnagles
        //first 2
        HBox itemsBoxamazon = new HBox(40);

        itemsBoxamazon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsamazon1 = new StackPane();
        Rectangle rectProductamazon1 = new Rectangle(110, 155);
        rectProductamazon1.setFill(PinkRectL);
        rectProductamazon1.setArcWidth(10);
        rectProductamazon1.setArcHeight(10);
        rectitemsamazon1.setTranslateX(-10);

        Rectangle SmallrectProductamazon1 = new Rectangle(110, 30);
        SmallrectProductamazon1.setFill(PinkRectD);
        SmallrectProductamazon1.setArcWidth(10);
        SmallrectProductamazon1.setArcHeight(10);
        SmallrectProductamazon1.setTranslateY(62);
        //SmallrectProductNiceone1.setTranslateX(-10);

        Image amazon1 = new Image("file:C://Users/fatim/Downloads/sv.png");
        ImageView amazonImg1 = new ImageView(amazon1);//
        amazonImg1.setFitHeight(80);
        amazonImg1.setFitWidth(80);
        amazonImg1.setTranslateY(-31);
        // niceoneImg1.setTranslateX(-10);

        Label amazon1Lb = new Label("Smart Vacuum \n3599SR");
        amazon1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon1Lb.setPadding(new Insets(0, 50, 30, 0));
        amazon1Lb.setTranslateY(45);
        amazon1Lb.setTranslateX(20);
        // niceone1Lb.setTranslateX(-10);

        Image listimg1amazon = new Image("file:C://Users/fatim/Downloads/list.png");
        ImageView listbtn1view1amazon = new ImageView(listimg1amazon);//
        listbtn1view1amazon.setFitHeight(68);
        listbtn1view1amazon.setFitWidth(68);
        //  listbtn1view1.setTranslateX(-10);

        Button listButton1amazon = new Button();
        listButton1amazon.setGraphic(new StackPane(listbtn1view1amazon));
        listButton1amazon.setPrefSize(35, 35);
        listButton1amazon.setTranslateY(65);
        listButton1amazon.setTranslateX(20);
        listButton1amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Image wishlistimg1amazon = new Image("file:C://Users/fatim/Downloads/wishlist.png");
        ImageView wishlistView1amazon = new ImageView(wishlistimg1amazon);
        wishlistView1amazon.setFitHeight(50);
        wishlistView1amazon.setFitWidth(50);

        Button wishlistButton1amazon = new Button();
        wishlistButton1amazon.setGraphic(new StackPane(wishlistView1amazon));
        wishlistButton1amazon.setPrefSize(35, 35);
        wishlistButton1amazon.setTranslateY(61);
        wishlistButton1amazon.setTranslateX(-20);
        wishlistButton1amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsamazon1.getChildren().addAll(rectProductamazon1, SmallrectProductamazon1,
                amazonImg1, amazon1Lb, listButton1amazon, wishlistButton1amazon);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsamazon2 = new StackPane();
        Rectangle rectProductamazon2 = new Rectangle(110, 155);
        rectProductamazon2.setFill(PinkRectL);
        rectProductamazon2.setArcWidth(10);
        rectProductamazon2.setArcHeight(10);
        rectProductamazon2.setTranslateX(-10);

        Rectangle SmallrectProductamazon2 = new Rectangle(110, 30);
        SmallrectProductamazon2.setFill(PinkRectD);
        SmallrectProductamazon2.setArcWidth(10);
        SmallrectProductamazon2.setArcHeight(10);
        SmallrectProductamazon2.setTranslateY(62);
        SmallrectProductamazon2.setTranslateX(-10);

        Image amazon2 = new Image("file:C://Users/fatim/Downloads/pp.png");
        ImageView amazonImg2 = new ImageView(amazon2);//
        amazonImg2.setFitHeight(90);
        amazonImg2.setFitWidth(80);
        amazonImg2.setTranslateY(-28);
        amazonImg2.setTranslateX(-10);

        Label amazon2Lb = new Label("Protein Powder\n350SR");
        amazon2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon2Lb.setPadding(new Insets(0, 0, 30, 0));
        amazon2Lb.setTranslateY(45);
        amazon2Lb.setTranslateX(-10);

        ImageView listbtn1view2amazon = new ImageView(listimg1amazon);//
        listbtn1view2amazon.setFitHeight(68);
        listbtn1view2amazon.setFitWidth(68);
        listbtn1view2amazon.setTranslateX(-10);

        ImageView wishlistView2amazon = new ImageView(wishlistimg1amazon);
        wishlistView2amazon.setFitHeight(50);
        wishlistView2amazon.setFitWidth(50);
        wishlistView2amazon.setTranslateX(-10);

        Button listButton2amazon = new Button();
        listButton2amazon.setGraphic(new StackPane(listbtn1view2amazon));
        listButton2amazon.setPrefSize(35, 35);
        listButton2amazon.setTranslateY(65);
        listButton2amazon.setTranslateX(20);
        listButton2amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton2amazon = new Button();
        wishlistButton2amazon.setGraphic(new StackPane(wishlistView2amazon));
        wishlistButton2amazon.setPrefSize(35, 35);
        wishlistButton2amazon.setTranslateY(61);
        wishlistButton2amazon.setTranslateX(-20);
        wishlistButton2amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        // rectitemsNiceone2.setTranslateX(-30);
        rectitemsamazon2.getChildren().addAll(rectProductamazon2, SmallrectProductamazon2,
                amazonImg2, amazon2Lb, wishlistButton2amazon, listButton2amazon);

        itemsBoxamazon.getChildren().addAll(rectitemsamazon1, rectitemsamazon2);

        // second 2
        HBox itemsBox2amazon = new HBox(40);

        itemsBox2amazon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsamazon3 = new StackPane();
        Rectangle rectProductamazon3 = new Rectangle(110, 155);
        rectProductamazon3.setFill(PinkRectL);
        rectProductamazon3.setArcWidth(10);
        rectProductamazon3.setArcHeight(10);

        Rectangle SmallrectProductamazon3 = new Rectangle(110, 30);
        SmallrectProductamazon3.setFill(PinkRectD);
        SmallrectProductamazon3.setArcWidth(10);
        SmallrectProductamazon3.setArcHeight(10);
        SmallrectProductamazon3.setTranslateY(62);

        Image amazon3 = new Image("file:C://Users/fatim/Downloads/af.png");
        ImageView amazonImg3 = new ImageView(amazon3);//
        amazonImg3.setFitHeight(80);
        amazonImg3.setFitWidth(65);
        amazonImg3.setTranslateY(-38);

        Label amazon3Lb = new Label("Air Fryer \n639SR");
        amazon3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon3Lb.setPadding(new Insets(0, 0, 30, 0));
        amazon3Lb.setTranslateY(34);

        ImageView listbtn1view3amazon = new ImageView(listimg1amazon);//
        listbtn1view3amazon.setFitHeight(68);
        listbtn1view3amazon.setFitWidth(68);

        ImageView wishlistView3amazon = new ImageView(wishlistimg1amazon);
        wishlistView3amazon.setFitHeight(50);
        wishlistView3amazon.setFitWidth(50);

        Button listButton3amazon = new Button();
        listButton3amazon.setGraphic(new StackPane(listbtn1view3amazon));
        listButton3amazon.setPrefSize(35, 35);
        listButton3amazon.setTranslateY(65);
        listButton3amazon.setTranslateX(20);
        listButton3amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton3amazon = new Button();
        wishlistButton3amazon.setGraphic(new StackPane(wishlistView3amazon));
        wishlistButton3amazon.setPrefSize(35, 35);
        wishlistButton3amazon.setTranslateY(61);
        wishlistButton3amazon.setTranslateX(-20);
        wishlistButton3amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsamazon3.getChildren().addAll(rectProductamazon3, SmallrectProductamazon3,
                amazonImg3, amazon3Lb, wishlistButton3amazon, listButton3amazon);

        //////////////////////////////////////////////////
        StackPane rectitemsamazon4 = new StackPane();
        Rectangle rectProductamazon4 = new Rectangle(110, 155);
        rectProductamazon4.setFill(PinkRectL);
        rectProductamazon4.setArcWidth(10);
        rectProductamazon4.setArcHeight(10);

        Rectangle SmallrectProductamazon4 = new Rectangle(110, 30);
        SmallrectProductamazon4.setFill(PinkRectD);
        SmallrectProductamazon4.setArcWidth(10);
        SmallrectProductamazon4.setArcHeight(10);
        SmallrectProductamazon4.setTranslateY(62);

        Image amazon4 = new Image("file:C://Users/fatim/Downloads/chair.png");
        ImageView amazonImg4 = new ImageView(amazon4);//
        amazonImg4.setFitHeight(77);
        amazonImg4.setFitWidth(67);
        amazonImg4.setTranslateY(-35);

        Label amazon4Lb = new Label("Gaming Chair \n350SR");
        amazon4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon4Lb.setTranslateY(20);

        ImageView listbtn1view4amazon = new ImageView(listimg1amazon);//
        listbtn1view4amazon.setFitHeight(68);
        listbtn1view4amazon.setFitWidth(68);

        ImageView wishlistView4amazon = new ImageView(wishlistimg1amazon);
        wishlistView4amazon.setFitHeight(50);
        wishlistView4amazon.setFitWidth(50);

        Button listButton4amazon = new Button();
        listButton4amazon.setGraphic(new StackPane(listbtn1view4amazon));
        listButton4amazon.setPrefSize(35, 35);
        listButton4amazon.setTranslateY(65);
        listButton4amazon.setTranslateX(20);
        listButton4amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton4amazon = new Button();
        wishlistButton4amazon.setGraphic(new StackPane(wishlistView4amazon));
        wishlistButton4amazon.setPrefSize(35, 35);
        wishlistButton4amazon.setTranslateY(61);
        wishlistButton4amazon.setTranslateX(-20);
        wishlistButton4amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon4.getChildren().addAll(rectProductamazon4, SmallrectProductamazon4,
                amazonImg4, amazon4Lb, wishlistButton4amazon, listButton4amazon);

        itemsBox2amazon.getChildren().addAll(rectitemsamazon3, rectitemsamazon4);

        // third 2 /////////////////
        HBox itemsBox3amazon = new HBox(40);

        itemsBox3amazon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsamazon5 = new StackPane();
        Rectangle rectProductamazon5 = new Rectangle(110, 155);
        rectProductamazon5.setFill(PinkRectL);
        rectProductamazon5.setArcWidth(10);
        rectProductamazon5.setArcHeight(10);

        Rectangle SmallrectProductamazon5 = new Rectangle(110, 30);
        SmallrectProductamazon5.setFill(PinkRectD);
        SmallrectProductamazon5.setArcWidth(10);
        SmallrectProductamazon5.setArcHeight(10);
        SmallrectProductamazon5.setTranslateY(62);

        Image amazon5 = new Image("file:C://Users/fatim/Downloads/pump.png");
        ImageView amazonImg5 = new ImageView(amazon5);//
        amazonImg5.setFitHeight(75);
        amazonImg5.setFitWidth(65);
        amazonImg5.setTranslateY(-36);

        Label amazon5Lb = new Label("Air Pump \n47SR");
        amazon5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon5Lb.setPadding(new Insets(0, 25, 25, 0));
        amazon5Lb.setTranslateY(34);


        ImageView listbtn1view5amazon = new ImageView(listimg1amazon);//
        listbtn1view5amazon.setFitHeight(68);
        listbtn1view5amazon.setFitWidth(68);

        ImageView wishlistView5amazon = new ImageView(wishlistimg1amazon);
        wishlistView5amazon.setFitHeight(50);
        wishlistView5amazon.setFitWidth(50);

        Button listButton5amazon = new Button();
        listButton5amazon.setGraphic(new StackPane(listbtn1view5amazon));
        listButton5amazon.setPrefSize(35, 35);
        listButton5amazon.setTranslateY(65);
        listButton5amazon.setTranslateX(20);
        listButton5amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton5amazon = new Button();
        wishlistButton5amazon.setGraphic(new StackPane(wishlistView5amazon));
        wishlistButton5amazon.setPrefSize(35, 35);
        wishlistButton5amazon.setTranslateY(61);
        wishlistButton5amazon.setTranslateX(-20);
        wishlistButton5amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon5.getChildren().addAll(rectProductamazon5, SmallrectProductamazon5,
                amazonImg5, amazon5Lb, wishlistButton5amazon, listButton5amazon);
        //////////////////////////////////////////////
        StackPane rectitemsamazon6 = new StackPane();
        Rectangle rectProductamazon6 = new Rectangle(110, 155);
        rectProductamazon6.setFill(PinkRectL);
        rectProductamazon6.setArcWidth(10);
        rectProductamazon6.setArcHeight(10);

        Rectangle SmallrectProductamazon6 = new Rectangle(110, 30);
        SmallrectProductamazon6.setFill(PinkRectD);
        SmallrectProductamazon6.setArcWidth(10);
        SmallrectProductamazon6.setArcHeight(10);
        SmallrectProductamazon6.setTranslateY(62);

        Image amazon6 = new Image("file:C://Users/fatim/Downloads/charger.png");
        ImageView amazonImg6 = new ImageView(amazon6);//
        amazonImg6.setFitHeight(100);
        amazonImg6.setFitWidth(60);
        amazonImg6.setTranslateY(-35);

        Label amazon6Lb = new Label("Charger Plug \n159SR");
        amazon6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon6Lb.setPadding(new Insets(0, 20, 25, 0));
        amazon6Lb.setTranslateY(35);

        ImageView listbtn1view6amazon = new ImageView(listimg1amazon);//
        listbtn1view6amazon.setFitHeight(68);
        listbtn1view6amazon.setFitWidth(68);

        ImageView wishlistView6amazon = new ImageView(wishlistimg1amazon);
        wishlistView6amazon.setFitHeight(50);
        wishlistView6amazon.setFitWidth(50);

        Button listButton6amazon = new Button();
        listButton6amazon.setGraphic(new StackPane(listbtn1view6amazon));
        listButton6amazon.setPrefSize(35, 35);
        listButton6amazon.setTranslateY(65);
        listButton6amazon.setTranslateX(20);
        listButton6amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton6amazon = new Button();
        wishlistButton6amazon.setGraphic(new StackPane(wishlistView6amazon));
        wishlistButton6amazon.setPrefSize(35, 35);
        wishlistButton6amazon.setTranslateY(61);
        wishlistButton6amazon.setTranslateX(-20);
        wishlistButton6amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon6.getChildren().addAll(rectProductamazon6, SmallrectProductamazon6,
                amazonImg6, amazon6Lb, wishlistButton6amazon, listButton6amazon);

        itemsBox3amazon.getChildren().addAll(rectitemsamazon5, rectitemsamazon6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4amazon = new HBox(40);

        itemsBox4amazon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsamazon7 = new StackPane();
        Rectangle rectProductamazon7 = new Rectangle(110, 155);
        rectProductamazon7.setFill(PinkRectL);
        rectProductamazon7.setArcWidth(10);
        rectProductamazon7.setArcHeight(10);

        Rectangle SmallrectProductamazon7 = new Rectangle(110, 30);
        SmallrectProductamazon7.setFill(PinkRectD);
        SmallrectProductamazon7.setArcWidth(10);
        SmallrectProductamazon7.setArcHeight(10);
        SmallrectProductamazon7.setTranslateY(62);

        Image amazon7 = new Image("file:C://Users/fatim/Downloads/airpods.png");
        ImageView amazonImg7 = new ImageView(amazon7);//
        amazonImg7.setFitHeight(90);
        amazonImg7.setFitWidth(85);
        amazonImg7.setTranslateY(-30);

        Label amazon7Lb = new Label("AirPodsMax Case \n155SR");
        amazon7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon7Lb.setPadding(new Insets(0, 0, 25, 0));
        amazon7Lb.setTranslateY(40);

        ImageView listbtn1view7amazon = new ImageView(listimg1amazon);//
        listbtn1view7amazon.setFitHeight(68);
        listbtn1view7amazon.setFitWidth(68);

        ImageView wishlistView7amazon = new ImageView(wishlistimg1amazon);
        wishlistView7amazon.setFitHeight(50);
        wishlistView7amazon.setFitWidth(50);

        Button listButton7amazon = new Button();
        listButton7amazon.setGraphic(new StackPane(listbtn1view7amazon));
        listButton7amazon.setPrefSize(35, 35);
        listButton7amazon.setTranslateY(65);
        listButton7amazon.setTranslateX(20);
        listButton7amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton7amazon = new Button();
        wishlistButton7amazon.setGraphic(new StackPane(wishlistView7amazon));
        wishlistButton7amazon.setPrefSize(35, 35);
        wishlistButton7amazon.setTranslateY(61);
        wishlistButton7amazon.setTranslateX(-20);
        wishlistButton7amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon7.getChildren().addAll(rectProductamazon7, SmallrectProductamazon7,
                amazonImg7, amazon7Lb, wishlistButton7amazon, listButton7amazon);
        ///////////////////////////////////////////////
        StackPane rectitemsamazon8 = new StackPane();
        Rectangle rectProductamazon8 = new Rectangle(110, 155);
        rectProductamazon8.setFill(PinkRectL);
        rectProductamazon8.setArcWidth(10);
        rectProductamazon8.setArcHeight(10);

        Rectangle SmallrectProductamazon8 = new Rectangle(110, 30);
        SmallrectProductamazon8.setFill(PinkRectD);
        SmallrectProductamazon8.setArcWidth(10);
        SmallrectProductamazon8.setArcHeight(10);
        SmallrectProductamazon8.setTranslateY(62);

        Image amazon8 = new Image("file:C://Users/fatim/Downloads/tramp.png");
        ImageView amazonImg8 = new ImageView(amazon8);//
        amazonImg8.setFitHeight(105);
        amazonImg8.setFitWidth(85);
        amazonImg8.setTranslateY(-34);

        Label amazon8Lb = new Label("Kids Trampoline  \n448SR");
        amazon8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon8Lb.setPadding(new Insets(0, 0, 25, 0));
        amazon8Lb.setTranslateY(38);

        ImageView listbtn1view8amazon = new ImageView(listimg1amazon);//
        listbtn1view8amazon.setFitHeight(68);
        listbtn1view8amazon.setFitWidth(68);

        ImageView wishlistView8amazon = new ImageView(wishlistimg1amazon);
        wishlistView8amazon.setFitHeight(50);
        wishlistView8amazon.setFitWidth(50);

        Button listButton8amazon = new Button();
        listButton8amazon.setGraphic(new StackPane(listbtn1view8amazon));
        listButton8amazon.setPrefSize(35, 35);
        listButton8amazon.setTranslateY(65);
        listButton8amazon.setTranslateX(20);
        listButton8amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton8amazon = new Button();
        wishlistButton8amazon.setGraphic(new StackPane(wishlistView8amazon));
        wishlistButton8amazon.setPrefSize(35, 35);
        wishlistButton8amazon.setTranslateY(61);
        wishlistButton8amazon.setTranslateX(-20);
        wishlistButton8amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon8.getChildren().addAll(rectProductamazon8, SmallrectProductamazon8
                , amazonImg8, amazon8Lb, wishlistButton8amazon, listButton8amazon);

        itemsBox4amazon.getChildren().addAll(rectitemsamazon7, rectitemsamazon8);

        // fifth 2/////////////////////////////
        HBox itemsBox5amazon = new HBox(40);

        itemsBox5amazon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsamazon9 = new StackPane();
        Rectangle rectProductamazon9 = new Rectangle(110, 155);
        rectProductamazon9.setFill(PinkRectL);
        rectProductamazon9.setArcWidth(10);
        rectProductamazon9.setArcHeight(10);

        Rectangle SmallrectProductamazon9 = new Rectangle(110, 30);
        SmallrectProductamazon9.setFill(PinkRectD);
        SmallrectProductamazon9.setArcWidth(10);
        SmallrectProductamazon9.setArcHeight(10);
        SmallrectProductamazon9.setTranslateY(62);

        Image amazon9 = new Image("file:C://Users/fatim/Downloads/bed.png");
        ImageView amazonImg9 = new ImageView(amazon9);//
        amazonImg9.setFitHeight(81);
        amazonImg9.setFitWidth(70);
        amazonImg9.setTranslateY(-30);

        Label amazon9Lb = new Label("AirBed \n195SR");
        amazon9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon9Lb.setPadding(new Insets(0, 5, 25, 0));
        amazon9Lb.setTranslateY(40);

        ImageView listbtn1view9amazon = new ImageView(listimg1amazon);//
        listbtn1view9amazon.setFitHeight(68);
        listbtn1view9amazon.setFitWidth(68);

        ImageView wishlistView9amazon = new ImageView(wishlistimg1amazon);
        wishlistView9amazon.setFitHeight(50);
        wishlistView9amazon.setFitWidth(50);

        Button listButton9amazon = new Button();
        listButton9amazon.setGraphic(new StackPane(listbtn1view9amazon));
        listButton9amazon.setPrefSize(35, 35);
        listButton9amazon.setTranslateY(65);
        listButton9amazon.setTranslateX(20);
        listButton9amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton9amazon = new Button();
        wishlistButton9amazon.setGraphic(new StackPane(wishlistView9amazon));
        wishlistButton9amazon.setPrefSize(35, 35);
        wishlistButton9amazon.setTranslateY(61);
        wishlistButton9amazon.setTranslateX(-20);
        wishlistButton9amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon9.getChildren().addAll(rectProductamazon9, SmallrectProductamazon9,
                amazonImg9, amazon9Lb, wishlistButton9amazon, listButton9amazon);
/////////////////////////////////////////////////////////
        StackPane rectitemsamazon10 = new StackPane();
        Rectangle rectProductamazon10 = new Rectangle(110, 155);
        rectProductamazon10.setFill(PinkRectL);
        rectProductamazon10.setArcWidth(10);
        rectProductamazon10.setArcHeight(10);

        Rectangle SmallrectProductamazon10 = new Rectangle(110, 30);
        SmallrectProductamazon10.setFill(PinkRectD);
        SmallrectProductamazon10.setArcWidth(10);
        SmallrectProductamazon10.setArcHeight(10);
        SmallrectProductamazon10.setTranslateY(62);

        Image amazon10 = new Image("file:C://Users/fatim/Downloads/cam.png");
        ImageView amazonImg10 = new ImageView(amazon10);//
        amazonImg10.setFitHeight(75);
        amazonImg10.setFitWidth(70);
        amazonImg10.setTranslateY(-35);

        Label amazon10Lb = new Label("Camera \n283SR");
        amazon10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        amazon10Lb.setPadding(new Insets(0, 0, 25, 0));
        amazon10Lb.setTranslateY(38);

        ImageView listbtn1view10amazon = new ImageView(listimg1amazon);//
        listbtn1view10amazon.setFitHeight(68);
        listbtn1view10amazon.setFitWidth(68);

        ImageView wishlistView10amazon = new ImageView(wishlistimg1amazon);
        wishlistView10amazon.setFitHeight(50);
        wishlistView10amazon.setFitWidth(50);

        Button listButton10amazon = new Button();
        listButton10amazon.setGraphic(new StackPane(listbtn1view10amazon));
        listButton10amazon.setPrefSize(35, 35);
        listButton10amazon.setTranslateY(65);
        listButton10amazon.setTranslateX(20);
        listButton10amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton10amazon = new Button();
        wishlistButton10amazon.setGraphic(new StackPane(wishlistView10amazon));
        wishlistButton10amazon.setPrefSize(35, 35);
        wishlistButton10amazon.setTranslateY(61);
        wishlistButton10amazon.setTranslateX(-20);
        wishlistButton10amazon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsamazon10.getChildren().addAll(rectProductamazon10, SmallrectProductamazon10
                , amazonImg10, amazon10Lb, wishlistButton10amazon, listButton10amazon);

        itemsBox5amazon.getChildren().addAll(rectitemsamazon9, rectitemsamazon10);

        centerBoxamazon.getChildren().addAll(centerSpendingamazon, itemsBoxamazon, itemsBox2amazon,
                itemsBox3amazon, itemsBox4amazon, itemsBox5amazon);


        ScrollPane scrollPaneamazon = new ScrollPane(centerBoxamazon);
        scrollPaneamazon.setFitToWidth(true);
        scrollPaneamazon.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        // bottom
        StackPane bottomamazonroot = new StackPane();

        Rectangle rectangleBamazon = new Rectangle();
        rectangleBamazon.setWidth(360);
        rectangleBamazon.setHeight(60);
        rectangleBamazon.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBamazon, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomeamazon = new Image("file:C://Users/fatim/Downloads/home.png");

        ImageView homeViewamazon = new ImageView(imageHomeamazon);
        homeViewamazon.setFitHeight(50);
        homeViewamazon.setFitWidth(60);

        Button homeButtonamazon = new Button();
        homeButtonamazon.setGraphic(new StackPane(homeViewamazon));
        homeButtonamazon.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonamazon, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonamazon, new Insets(10, 0, 0, 30));

        Text textHomeamazon = new Text("Home");
        textHomeamazon.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomeamazon.setFill(Color.WHITE);

        StackPane.setAlignment(textHomeamazon, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomeamazon, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImageamazon = new Image("file:C://Users/fatim/Downloads/wishlist.png");
        ImageView wishlistViewamazon = new ImageView(wishlistImageamazon);
        wishlistViewamazon.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewamazon.setFitWidth(70);

        Button wishlistButtonamazon = new Button();
        wishlistButtonamazon.setGraphic(new StackPane(wishlistViewamazon));
        wishlistButtonamazon.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonamazon, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonamazon, new Insets(10, 0, 0, 91));

        Text wishlistTextamazon = new Text("Wishlist");
        wishlistTextamazon.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextamazon.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextamazon, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextamazon, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImageamazon = new Image("file:C://Users/fatim/Downloads/list.png");
        ImageView listViewamazon = new ImageView(listImageamazon);
        listViewamazon.setFitHeight(70); //setting the fit height and width of the image view
        listViewamazon.setFitWidth(80);

        Button listButtonamazon = new Button();
        listButtonamazon.setGraphic(new StackPane(listViewamazon));
        listButtonamazon.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonamazon, Pos.CENTER);
        StackPane.setMargin(listButtonamazon, new Insets(15, 0, 0, 60));

        Text listTextamazon = new Text("List");
        listTextamazon.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextamazon.setFill(Color.WHITE);

        StackPane.setAlignment(listTextamazon, Pos.CENTER);
        StackPane.setMargin(listTextamazon, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImageamazon = new Image("file:C://Users/fatim/Downloads/profile.png");
        ImageView profileViewamazon = new ImageView(profileImageamazon);
        profileViewamazon.setFitHeight(70); //setting the fit height and width of the image view
        profileViewamazon.setFitWidth(100);

        Button profileButtonamazon = new Button();
        profileButtonamazon.setGraphic(new StackPane(profileViewamazon));
        profileButtonamazon.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonamazon, Pos.CENTER);
        StackPane.setMargin(profileButtonamazon, new Insets(0, 0, 0, 210));

        Text profileTextamazon = new Text("Profile");
        profileTextamazon.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextamazon.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextamazon, Pos.CENTER);
        StackPane.setMargin(profileTextamazon, new Insets(50, 0, 0, 200));



        bottomamazonroot.getChildren().addAll(rectangleBamazon, homeButtonamazon, textHomeamazon
                , wishlistButtonamazon, wishlistTextamazon, listButtonamazon, listTextamazon, profileButtonamazon, profileTextamazon);


        amazonPane.setTop(topamazonroot);
        amazonPane.setCenter(scrollPaneamazon);
        amazonPane.setBottom(bottomamazonroot);

        Scene sceneamazon = new Scene(amazonPane, 350, 600);
        primaryStage.setScene(sceneamazon); // Place the scene in the stage
        primaryStage.show(); //


        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        ProfileScene profileScene = new ProfileScene();

        backImgamazon.setOnMousePressed(e->{
            homePageScene.start(primaryStage );
        });

        homeButtonamazon.setOnMousePressed(e->{
            homePageScene.start(primaryStage);

        });

        wishlistButtonamazon.setOnMousePressed(e->{
            wishlistScene.start(primaryStage);

        });


        listButtonamazon.setOnMousePressed(e->{
            listScene.start(primaryStage );

        });
        
        
        //         // retrieving all the table 
//              int id = 0;
//               session = HibernateUtil.getSessionFactory().openSession();
//               List<Cake> cList = null;
//               String str = "from Cake";
//               Query q = session.createQuery(str);
//               cList = q.list();
//               session.close();
//                   user = new User(nameTextField2.getText(), emailTextField2.getText(), passwordField2.getText(), datePiker.getValue().toString());
//                session = HibernateUtil.getSessionFactory().openSession();
//                Transaction tx = session.beginTransaction();
//                //insert
//                int user1 = (Integer) session.save(user);
//                System.out.println("inserted User ");
//                tx.commit();
//                session.close();
//                
//                    } } Item(int userID, String ListID, String shopName, String urlImage)

        session = HibernateUtil.getSessionFactory().openSession();
        List<User> uList5 = null;
        Query q5 = session.createQuery("from User");
        uList5 = q5.list();
        session.close();
        
        for (User u : uList5) {
            if (app.emailTextField2.getText().equalsIgnoreCase(u.getEmail()) || app.emailTextField.getText().equalsIgnoreCase(u.getEmail())) {
                iduser = u.getUserID();
            }
        }
                System.out.println("IDDD: "+ iduser);
        listButton1amazon.setOnAction(e->{
            
            HBox addItem = new HBox(20);
            addItem.setStyle("-fx-border-color: white;");
            ImageView imgAdd = new ImageView(amazon1);
            imgAdd.setFitHeight(80);
            imgAdd.setFitWidth(80);
            Label decreption = new Label(amazon1Lb.getText());
            addItem.getChildren().addAll(imgAdd, decreption);
            wishlistScene.centerBoxwishListt.getChildren().addAll(addItem);
            
            Label l = new Label("Amazon");
            Item item = new Item(iduser, l.getText(), 19.99, "Electronics", "Amazon", "file:C://Users/ghadi/Downloads/sv.png");
            item.setListID(app.wishlistid);
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            int itemId = (Integer) session.save(item);
            tx.commit();
            session.close();

            
        });
        
        /*
        // add to wishList and list --------------------------------          /// -- iHerb item 1 --///
          //wishlist          wishlistButtoniHerb1.setOnAction(e -> {
            HBox addItem = new HBox(20);            addItem.setStyle("-fx-border-color: white;");
                        ImageView imgAdd = new ImageView (iherb1);
            imgAdd.setFitHeight(80);            imgAdd.setFitWidth(80);
                       Label decreption = new Label(iherb1Lb.getText());
                        addItem.getChildren().addAll(imgAdd,decreption);
                        scenewishListt.centerBoxwishListt.getChildren().addAll(addItem);
            //scenewishListt.setCenterBoxwishListt(addItem);            
          // centerBoxwishListt.getChildren().addAll(addItem);           
        }        );
          //list          listButtoniherb1.setOnAction(e -> {
            HBox addItem = new HBox(20);            addItem.setStyle("-fx-border-color: white;");
                        ImageView imgAdd = new ImageView (iherb1);
            Label decreption = new Label(iherb1Lb.getText());            
           addItem.getChildren().addAll(imgAdd,decreption);            
            scenewishListt.centerBoxwishListt.getChildren().addAll(addItem);          // centerBoxwishListt.getChildren().addAll(addItem);
           imgAdd.setFitHeight(80);           imgAdd.setFitWidth(80);
        }        );
        */
        
        

primaryStage.show();

//        profileButtonamazon.setOnMousePressed(e->{    // profile button
//                    profileScene.start(new Stage() );

//              });
    }
    
    

   

}

