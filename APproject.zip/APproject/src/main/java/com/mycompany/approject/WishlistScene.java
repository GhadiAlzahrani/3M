/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */



import java.util.List;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.hibernate.*;


public class WishlistScene extends Application{

    Session session;
    VBox centerBoxwishListt = new VBox();
    @Override
    public void start(Stage stage) {

        ////----------------------------------------- WISHLIST SCENE ------------------------------------------------- ////
        // ------------------------------------------------- color -------------------------------------------------
        Color colorBG = Color.web("#c4d5de",1);//light blue for background
        Color blueRect = Color.web("#657da1",1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2",1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD",1);//Light pink

        BorderPane wishListtPane = new BorderPane();
        wishListtPane.setStyle("-fx-background-color: #c4d5de;");


        // -------------------------------------- top --------------------------------------
        StackPane topwishListtroot = new StackPane();

        Rectangle recttUpwishListt = new Rectangle();
        recttUpwishListt.setX(500);
        recttUpwishListt.setY(80);
        recttUpwishListt.setWidth(356);
        recttUpwishListt.setHeight(90);
        recttUpwishListt.setFill(blueRect);

        ////back//
        Image backwishListt = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\backarrow2.png");
        ImageView backwishListtImg = new ImageView(backwishListt);//
        backwishListtImg.setFitHeight(25);
        backwishListtImg.setFitWidth(25);
        StackPane.setMargin(backwishListtImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backwishListtImg, Pos.CENTER_LEFT);


        Text wishListtText = new Text("WishList");
        wishListtText.setStyle("-fx-font: normal bold 14px 'serif'");
        wishListtText.setFill(Color.WHITE);

        StackPane.setAlignment(wishListtText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishListtText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(recttUpwishListt, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldwishListt = new TextField();
        searchFieldwishListt.setFocusTraversable(false);
        searchFieldwishListt.setPromptText("Search here ...");
        searchFieldwishListt.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldwishListt.setPrefWidth(200);
        searchFieldwishListt.setPrefHeight(25);

        Rectangle searchFieldShapewl = new Rectangle();
        searchFieldShapewl.setWidth(200);
        searchFieldShapewl.setHeight(25);
        searchFieldShapewl.setArcWidth(25);
        searchFieldShapewl.setArcHeight(30);
        searchFieldwishListt.setShape(searchFieldShapewl);

        Image searchimgeewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\search.png");
        ImageView searchViewWLimg = new ImageView(searchimgeewl);
        searchViewWLimg.setFitHeight(19);
        searchViewWLimg.setFitWidth(22);

        StackPane.setMargin(searchViewWLimg, new Insets(0, 0, 0, 170));
        StackPane searchwishListtContainer = new StackPane();
        searchwishListtContainer.getChildren().addAll(searchFieldwishListt, searchViewWLimg);

        HBox searchBoxwishListt = new HBox(searchwishListtContainer);

        StackPane.setMargin(searchBoxwishListt, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeeImagewl = new Image("file:C:\\Users\\pc\\Downloads\\notices.png");
        ImageView noticeViewwl = new ImageView(noticeeImagewl);
        noticeViewwl.setFitHeight(20);
        noticeViewwl.setFitWidth(15);

        Button noticeeButtonwl = new Button();
        noticeeButtonwl.setGraphic(new StackPane(noticeViewwl));
        noticeeButtonwl.setPrefSize(30, 30);
        noticeeButtonwl.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeeButtonwl, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeeButtonwl, Pos.CENTER_RIGHT);

        ////list //////
        Image listt1wl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\list1.png");
        ImageView listt1Imgwl = new ImageView(listt1wl);//
        listt1Imgwl.setFitHeight(18);
        listt1Imgwl.setFitWidth(23);

        StackPane.setMargin(listt1Imgwl, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(listt1Imgwl, Pos.CENTER_RIGHT);

        topwishListtroot.getChildren().addAll(recttUpwishListt, wishListtText, searchBoxwishListt,
                noticeeButtonwl, listt1Imgwl ,backwishListtImg);
        wishListtPane.setTop(topwishListtroot);

        // -------------------------------------- center --------------------------------------
       
        centerBoxwishListt.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendiingwl = new StackPane();

        Rectangle rectProduct1wl = new Rectangle(200, 70);
        rectProduct1wl.setFill(PinkRectD);
        rectProduct1wl.setArcWidth(10);
        rectProduct1wl.setArcHeight(10);


        Label spendiingwlLb = new Label("Total Spending");
        spendiingwlLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendiingwlLb.setPadding(new Insets(0, 0, 25, 0));


        centerSpendiingwl.setPadding(new Insets(20, 55, 0, 60));
        centerSpendiingwl.getChildren().addAll(rectProduct1wl, spendiingwlLb);




        ScrollPane wishListscrollPane = new ScrollPane(centerBoxwishListt);
        wishListscrollPane.setFitToWidth(true);
        wishListscrollPane.setFitToHeight(true);

        // -------------------------------------- bottom --------------------------------------
        StackPane bottomwishListtroot = new StackPane();

        Rectangle rectanglewlB = new Rectangle();
        rectanglewlB.setWidth(360);
        rectanglewlB.setHeight(60);
        rectanglewlB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectanglewlB, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\home.png");

        ImageView homeViewwl = new ImageView(imageHomewl);
        homeViewwl.setFitHeight(50);
        homeViewwl.setFitWidth(60);

        Button homeButtonwl = new Button();
        homeButtonwl.setGraphic(new StackPane(homeViewwl));
        homeButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonwl, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonwl, new Insets(10, 0, 0, 30));

        Text textHomewl = new Text("Home");
        textHomewl.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomewl.setFill(Color.WHITE);

        StackPane.setAlignment(textHomewl, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomewl, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\wishlist.png");
        ImageView wishlistViewwl = new ImageView(wishlistImagewl);
        wishlistViewwl.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewwl.setFitWidth(70);

        Button wishlistButtonwl = new Button();
        wishlistButtonwl.setGraphic(new StackPane(wishlistViewwl));
        wishlistButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonwl, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonwl, new Insets(10, 0, 0, 91));

        Text wishlistTextwl = new Text("Wishlist");
        wishlistTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextwl, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextwl, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\list.png");
        ImageView listViewwl = new ImageView(listImagewl);
        listViewwl.setFitHeight(70); //setting the fit height and width of the image view
        listViewwl.setFitWidth(80);

        Button listButtonwl = new Button();
        listButtonwl.setGraphic(new StackPane(listViewwl));
        listButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonwl, Pos.CENTER);
        StackPane.setMargin(listButtonwl, new Insets(15, 0, 0, 60));

        Text listTextwl = new Text("List");
        listTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(listTextwl, Pos.CENTER);
        StackPane.setMargin(listTextwl, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\profile.png");
        ImageView profileViewwl = new ImageView(profileImagewl);
        profileViewwl.setFitHeight(70); //setting the fit height and width of the image view
        profileViewwl.setFitWidth(100);

        Button profileButtonwl = new Button();
        profileButtonwl.setGraphic(new StackPane(profileViewwl));
        profileButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonwl, Pos.CENTER);
        StackPane.setMargin(profileButtonwl, new Insets(0, 0, 0, 210));

        Text profileTextwl = new Text("Profile");
        profileTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextwl, Pos.CENTER);
        StackPane.setMargin(profileTextwl, new Insets(50, 0, 0, 200));



        bottomwishListtroot.getChildren().addAll(rectanglewlB, homeButtonwl, textHomewl
                , wishlistButtonwl , wishlistTextwl , listButtonwl ,listTextwl , profileButtonwl , profileTextwl );


        wishListtPane.setTop(topwishListtroot);
        wishListtPane.setCenter(wishListscrollPane);
        wishListtPane.setBottom(bottomwishListtroot);

        Scene scenewishListt = new Scene(wishListtPane, 350, 600);

        stage.setScene(scenewishListt); // Place the scene in the stage
        stage.show(); //

        HomePageScene homePageScene = new HomePageScene();     WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();     ProfileScene profileScene = new ProfileScene();
        //-------------------------------- ACTION ----------------------------------------------//

        backwishListtImg.setOnMouseClicked(e -> {             homePageScene.start(new Stage());
        });
        homeButtonwl.setOnAction(e -> {
            homePageScene.start(stage);         });
        wishlistButtonwl.setOnAction(e -> {
            wishlistScene.start(stage);         });
        listButtonwl.setOnAction(e -> {
            listScene.start(stage);     });
        App app = new App();
        session = HibernateUtil.getSessionFactory().openSession();
        List<User> uList5 = null;
        Query q5 = session.createQuery("from User");
        uList5 = q5.list();
        session.close();
        int idddd =0;
        int wishlistiddd = 0;
        for (User u : uList5) {
            if (app.emailTextField2.getText().equalsIgnoreCase(u.getEmail()) || app.emailTextField.getText().equalsIgnoreCase(u.getEmail())) {
                idddd = u.getUserID();
            }
        }
        session = HibernateUtil.getSessionFactory().openSession();
        List<Wishlist> wList = null;
        Query q99 = session.createQuery("from Wishlist");
        wList = q99.list();
        session.close();
        if (!wList.isEmpty()) {
            for (Wishlist w : wList) {
                if (idddd == w.getUserID()) {
                    wishlistiddd =w.getWishlistID();
                }
            }
        }

        session = HibernateUtil.getSessionFactory().openSession();
        List<Item> iList = null;
        Query q9 = session.createQuery("from Item");
        iList = q9.list();
        session.close();
        if (!iList.isEmpty()) {
            for (Item i : iList) {
                if (idddd == i.getUserID() && wishlistiddd == i.getListID()) {
                    HBox addItem = new HBox(20);
                    addItem.setStyle("-fx-border-color: white;");
                    ImageView imgAdd = new ImageView(i.getUrlImage());
                    imgAdd.setFitHeight(80);
                    imgAdd.setFitWidth(80);
                    Label decreption = new Label(i.getname() + "\n" + i.getShopName());
                    addItem.getChildren().addAll(imgAdd, decreption);
                    centerBoxwishListt.getChildren().addAll(addItem);
                }
            }
        }

        
//        profileButtonwl.setOnAction(e -> {
//            profileScene.start(new Stage());         });
//
//

//        session = HibernateUtil.getSessionFactory().openSession();
//        Transaction tx1 = session.beginTransaction();
//
//        List<Item> wList2 = null;
//        String str2 = "from item";
//        Query q2 = session.createQuery(str2);
//        wList2 = q2.list();
//        session.close();
//
//        if (!wList2.isEmpty()) {
//            
//        
//        for (Item c : wList2) {
//            ImageView imgwishlist = new ImageView(c.getUrlImage());
//            Label lbwishlist = new Label(c.getname());
//            HBox hboxtest = new HBox();
//            hboxtest.getChildren().addAll(imgwishlist, lbwishlist);
//            centerBoxwishListt.getChildren().add(hboxtest);
//
//        }}
    }


}
