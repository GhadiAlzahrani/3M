/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.Math.max;
import static java.lang.Math.min;
import static javafx.application.Application.launch;


/**
 * JavaFX App
 */
public class Noon extends Application {

    @Override
    public void start(Stage stage) {


     
        BorderPane noonPane = new BorderPane();
        noonPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topNOONroot = new StackPane();

        Rectangle rectangleTNOON = new Rectangle();
        rectangleTNOON.setX(500);
        rectangleTNOON.setY(80);
        rectangleTNOON.setWidth(356);
        rectangleTNOON.setHeight(90);
        rectangleTNOON.setFill(blueRect);
        
        ////back//
        Image back = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);
       

        Text NOONText = new Text("Noon");
        NOONText.setStyle("-fx-font: normal bold 14px 'serif'");
        NOONText.setFill(Color.WHITE);

        StackPane.setAlignment(NOONText, Pos.CENTER_LEFT);
        StackPane.setMargin(NOONText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTNOON, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldNOON = new TextField();
        searchFieldNOON.setFocusTraversable(false);
        searchFieldNOON.setPromptText("Search here ...");
        searchFieldNOON.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldNOON.setPrefWidth(200);
        searchFieldNOON.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchFieldNOON.setShape(searchFieldShape);

        Image searchImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\search.jpg");
        ImageView searchViewNOON = new ImageView(searchImage);
        searchViewNOON.setFitHeight(19);
        searchViewNOON.setFitWidth(22);

        StackPane.setMargin(searchViewNOON, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainerNOON = new StackPane();
        searchFieldContainerNOON.getChildren().addAll(searchFieldNOON, searchViewNOON);

        HBox searchBoxNOON = new HBox(searchFieldContainerNOON);

        StackPane.setMargin(searchBoxNOON, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\notices.png");
        ImageView noticeView = new ImageView(noticeImage);
        noticeView.setFitHeight(20);
        noticeView.setFitWidth(15);

        Button noticeButtonNOON = new Button();
        noticeButtonNOON.setGraphic(new StackPane(noticeView));
        noticeButtonNOON.setPrefSize(30, 30);
        noticeButtonNOON.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonNOON, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonNOON, Pos.CENTER_RIGHT);

        ////list //////
        Image list1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list1.png");
        ImageView list1Img = new ImageView(list1);//
        list1Img.setFitHeight(18);
        list1Img.setFitWidth(23);

        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topNOONroot.getChildren().addAll(rectangleTNOON, NOONText, searchBoxNOON,
                 noticeButtonNOON, list1Img ,backImg);
        noonPane.setTop(topNOONroot);

        //---------- center -----------//
        VBox centerBoxNOON = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxNOON.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendingNOON = new StackPane();

        Rectangle rectProduct1NOON = new Rectangle(200, 70);
        rectProduct1NOON.setFill(PinkRectD);
        rectProduct1NOON.setArcWidth(10);
        rectProduct1NOON.setArcHeight(10);
 

        Label spendingLbNOON = new Label("Total Spending\n\t");
        spendingLbNOON.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLbNOON.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpendingNOON.setPadding(new Insets(20, 55, 0, 60));
        centerSpendingNOON.getChildren().addAll(rectProduct1NOON, spendingLbNOON);

        //items recnagles 
        //first 2
        HBox itemsBoxNOON = new HBox(40);

        itemsBoxNOON.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNOON1 = new StackPane();
        Rectangle rectProductNOON1 = new Rectangle(110, 155);
        rectProductNOON1.setFill(PinkRectL);
        rectProductNOON1.setArcWidth(10);
        rectProductNOON1.setArcHeight(10);

        Rectangle SmallrectProductNOON1 = new Rectangle(110, 30);
        SmallrectProductNOON1.setFill(PinkRectD);
        SmallrectProductNOON1.setArcWidth(10);
        SmallrectProductNOON1.setArcHeight(10);
        SmallrectProductNOON1.setTranslateY(62);

        Image NOON1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\tv1.PNG");
        ImageView NOONImg1 = new ImageView(NOON1);//
        NOONImg1.setFitHeight(120);
        NOONImg1.setFitWidth(120);
        NOONImg1.setTranslateY(-31);

        Label NOON1Lb = new Label("smart TV \n5,999SR");
        NOON1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        NOON1Lb.setPadding(new Insets(0, 50, 30, 0));
        NOON1Lb.setTranslateY(45);

        Image listimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listbtn1view1 = new ImageView(listimg1);//
        listbtn1view1.setFitHeight(68);
        listbtn1view1.setFitWidth(68);

        Button listButton1NOON = new Button();
        listButton1NOON.setGraphic(new StackPane(listbtn1view1));
        listButton1NOON.setPrefSize(35, 35);
        listButton1NOON.setTranslateY(65);
        listButton1NOON.setTranslateX(20);
        listButton1NOON.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlistimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView1 = new ImageView(wishlistimg1);
        wishlistView1.setFitHeight(50);
        wishlistView1.setFitWidth(50);
        
        Button wishlistButton1 = new Button();
        wishlistButton1.setGraphic(new StackPane(wishlistView1));
        wishlistButton1.setPrefSize(35, 35);
        wishlistButton1.setTranslateY(61);
        wishlistButton1.setTranslateX(-20);
        wishlistButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNOON1.getChildren().addAll(rectProductNOON1, SmallrectProductNOON1,
                 NOONImg1, NOON1Lb, listButton1NOON , wishlistButton1);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsNOON2 = new StackPane();
        Rectangle rectProductNOON2 = new Rectangle(110, 155);
        rectProductNOON2.setFill(PinkRectL);
        rectProductNOON2.setArcWidth(10);
        rectProductNOON2.setArcHeight(10);

        Rectangle SmallrectProductNOON2 = new Rectangle(110, 30);
        SmallrectProductNOON2.setFill(PinkRectD);
        SmallrectProductNOON2.setArcWidth(10);
        SmallrectProductNOON2.setArcHeight(10);
        SmallrectProductNOON2.setTranslateY(62);

        Image NOON2 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Quran2.PNG");
        ImageView NOONImg2 = new ImageView(NOON2);//
        NOONImg2.setFitHeight(90);
        NOONImg2.setFitWidth(100);
        NOONImg2.setTranslateY(-28);

        Label ounass2Lb = new Label("Quran Speaker\n99.95SR");
        ounass2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass2Lb.setPadding(new Insets(0, 0, 30, 0));
        ounass2Lb.setTranslateY(45);
        
        ImageView listbtn1view2 = new ImageView(listimg1);//
        listbtn1view2.setFitHeight(68);
        listbtn1view2.setFitWidth(68);
        
        ImageView wishlistView2 = new ImageView(wishlistimg1);
        wishlistView2.setFitHeight(50);
        wishlistView2.setFitWidth(50);
        
        Button listButton2noon = new Button();
        listButton2noon.setGraphic(new StackPane(listbtn1view2));
        listButton2noon.setPrefSize(35, 35);
        listButton2noon.setTranslateY(65);
        listButton2noon.setTranslateX(20);
        listButton2noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton2noon = new Button();
        wishlistButton2noon.setGraphic(new StackPane(wishlistView2));
        wishlistButton2noon.setPrefSize(35, 35);
        wishlistButton2noon.setTranslateY(61);
        wishlistButton2noon.setTranslateX(-20);
        wishlistButton2noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsNOON2.getChildren().addAll(rectProductNOON2, SmallrectProductNOON2,
                 NOONImg2, ounass2Lb ,  wishlistButton2noon ,listButton2noon);

        itemsBoxNOON.getChildren().addAll(rectitemsNOON1, rectitemsNOON2);

        // second 2
        HBox itemsBox2noon = new HBox(40);

        itemsBox2noon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnoon3 = new StackPane();
        Rectangle rectProductNOON3 = new Rectangle(110, 155);
        rectProductNOON3.setFill(PinkRectL);
        rectProductNOON3.setArcWidth(10);
        rectProductNOON3.setArcHeight(10);

        Rectangle SmallrectProductNOON3 = new Rectangle(110, 30);
        SmallrectProductNOON3.setFill(PinkRectD);
        SmallrectProductNOON3.setArcWidth(10);
        SmallrectProductNOON3.setArcHeight(10);
        SmallrectProductNOON3.setTranslateY(62);

        Image NOON3 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\JBL3.PNG");
        ImageView NOONImg3 = new ImageView(NOON3);//
        NOONImg3.setFitHeight(90);
        NOONImg3.setFitWidth(75);
        NOONImg3.setTranslateY(-38);

        Label noon3Lb = new Label("JBL Speaker\n349SR");
        noon3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon3Lb.setPadding(new Insets(0, 0, 30, 0));
        noon3Lb.setTranslateY(34);
        
        ImageView listbtn1view3noon = new ImageView(listimg1);//
        listbtn1view3noon.setFitHeight(68);
        listbtn1view3noon.setFitWidth(68);
        
        ImageView wishlistView3noon = new ImageView(wishlistimg1);
        wishlistView3noon.setFitHeight(50);
        wishlistView3noon.setFitWidth(50);
        
        Button listButton3noon = new Button();
        listButton3noon.setGraphic(new StackPane(listbtn1view3noon));
        listButton3noon.setPrefSize(35, 35);
        listButton3noon.setTranslateY(65);
        listButton3noon.setTranslateX(20);
        listButton3noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton3noon = new Button();
        wishlistButton3noon.setGraphic(new StackPane(wishlistView3noon));
        wishlistButton3noon.setPrefSize(35, 35);
        wishlistButton3noon.setTranslateY(61);
        wishlistButton3noon.setTranslateX(-20);
        wishlistButton3noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsnoon3.getChildren().addAll(rectProductNOON3, SmallrectProductNOON3,
                 NOONImg3, noon3Lb , wishlistButton3noon , listButton3noon);
        
        //////////////////////////////////////////////////
        StackPane rectitemsNOON4 = new StackPane();
        Rectangle rectProductNOON4 = new Rectangle(110, 155);
        rectProductNOON4.setFill(PinkRectL);
        rectProductNOON4.setArcWidth(10);
        rectProductNOON4.setArcHeight(10);

        Rectangle SmallrectProductNOON4 = new Rectangle(110, 30);
        SmallrectProductNOON4.setFill(PinkRectD);
        SmallrectProductNOON4.setArcWidth(10);
        SmallrectProductNOON4.setArcHeight(10);
        SmallrectProductNOON4.setTranslateY(62);

        Image NOON4 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Airpods4.PNG");
        ImageView NOONImg4 = new ImageView(NOON4);//
        NOONImg4.setFitHeight(70);
        NOONImg4.setFitWidth(60);
        NOONImg4.setTranslateY(-35);

        Label NOON4Lb = new Label("AirPods Pro\n869SR");
        NOON4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        NOON4Lb.setTranslateY(20);
        
        ImageView listbtn1view4NOON = new ImageView(listimg1);//
        listbtn1view4NOON.setFitHeight(68);
        listbtn1view4NOON.setFitWidth(68);
        
        ImageView wishlistView4NOON = new ImageView(wishlistimg1);
        wishlistView4NOON.setFitHeight(50);
        wishlistView4NOON.setFitWidth(50);
        
        Button listButton4NOON = new Button();
        listButton4NOON.setGraphic(new StackPane(listbtn1view4NOON));
        listButton4NOON.setPrefSize(35, 35);
        listButton4NOON.setTranslateY(65);
        listButton4NOON.setTranslateX(20);
        listButton4NOON.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton4NOON = new Button();
        wishlistButton4NOON.setGraphic(new StackPane(wishlistView4NOON));
        wishlistButton4NOON.setPrefSize(35, 35);
        wishlistButton4NOON.setTranslateY(61);
        wishlistButton4NOON.setTranslateX(-20);
        wishlistButton4NOON.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNOON4.getChildren().addAll(rectProductNOON4, SmallrectProductNOON4,
                 NOONImg4, NOON4Lb, wishlistButton4NOON, listButton4NOON);

        itemsBox2noon.getChildren().addAll(rectitemsnoon3, rectitemsNOON4);

        // third 2 /////////////////
        HBox itemsBox3noon = new HBox(40);

        itemsBox3noon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNoon5 = new StackPane();
        Rectangle rectProductNoon5 = new Rectangle(110, 155);
        rectProductNoon5.setFill(PinkRectL);
        rectProductNoon5.setArcWidth(10);
        rectProductNoon5.setArcHeight(10);

        Rectangle SmallrectProductNoon5 = new Rectangle(110, 30);
        SmallrectProductNoon5.setFill(PinkRectD);
        SmallrectProductNoon5.setArcWidth(10);
        SmallrectProductNoon5.setArcHeight(10);
        SmallrectProductNoon5.setTranslateY(62);

        Image Noon5 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\AirTag5.PNG");
        ImageView noonImg5 = new ImageView(Noon5);//
        noonImg5.setFitHeight(80);
        noonImg5.setFitWidth(80);
        noonImg5.setTranslateY(-36);

        Label noon5Lb = new Label("AirTag\n399SR");
        noon5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon5Lb.setPadding(new Insets(0, 25, 25, 0));
        noon5Lb.setTranslateY(34);
        
        
        ImageView listbtn1view5noon = new ImageView(listimg1);//
        listbtn1view5noon.setFitHeight(68);
        listbtn1view5noon.setFitWidth(68);
        
        ImageView wishlistView5noon = new ImageView(wishlistimg1);
        wishlistView5noon.setFitHeight(50);
        wishlistView5noon.setFitWidth(50);
        
        Button listButton5noon = new Button();
        listButton5noon.setGraphic(new StackPane(listbtn1view5noon));
        listButton5noon.setPrefSize(35, 35);
        listButton5noon.setTranslateY(65);
        listButton5noon.setTranslateX(20);
        listButton5noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton5noon = new Button();
        wishlistButton5noon.setGraphic(new StackPane(wishlistView5noon));
        wishlistButton5noon.setPrefSize(35, 35);
        wishlistButton5noon.setTranslateY(61);
        wishlistButton5noon.setTranslateX(-20);
        wishlistButton5noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNoon5.getChildren().addAll(rectProductNoon5, SmallrectProductNoon5,
                 noonImg5, noon5Lb, wishlistButton5noon, listButton5noon);
        //////////////////////////////////////////////
        StackPane rectitemsnoon6 = new StackPane();
        Rectangle rectProductNoon6 = new Rectangle(110, 155);
        rectProductNoon6.setFill(PinkRectL);
        rectProductNoon6.setArcWidth(10);
        rectProductNoon6.setArcHeight(10);

        Rectangle SmallrectProductNoon6 = new Rectangle(110, 30);
        SmallrectProductNoon6.setFill(PinkRectD);
        SmallrectProductNoon6.setArcWidth(10);
        SmallrectProductNoon6.setArcHeight(10);
        SmallrectProductNoon6.setTranslateY(62);

        Image Noon6 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\keyboard6.PNG");
        ImageView noonImg6 = new ImageView(Noon6);//
        noonImg6.setFitHeight(100);
        noonImg6.setFitWidth(100);
        noonImg6.setTranslateY(-35);

        Label noon6Lb = new Label("Magic Keyboard\n1,449SR");
        noon6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon6Lb.setPadding(new Insets(0, 20, 25, 0));
        noon6Lb.setTranslateY(35);
        
        ImageView listbtn1view6noon = new ImageView(listimg1);//
        listbtn1view6noon.setFitHeight(68);
        listbtn1view6noon.setFitWidth(68);
        
        ImageView wishlistView6noon = new ImageView(wishlistimg1);
        wishlistView6noon.setFitHeight(50);
        wishlistView6noon.setFitWidth(50);
        
        Button listButton6noon = new Button();
        listButton6noon.setGraphic(new StackPane(listbtn1view6noon));
        listButton6noon.setPrefSize(35, 35);
        listButton6noon.setTranslateY(65);
        listButton6noon.setTranslateX(20);
        listButton6noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton6noon = new Button();
        wishlistButton6noon.setGraphic(new StackPane(wishlistView6noon));
        wishlistButton6noon.setPrefSize(35, 35);
        wishlistButton6noon.setTranslateY(61);
        wishlistButton6noon.setTranslateX(-20);
        wishlistButton6noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnoon6.getChildren().addAll(rectProductNoon6, SmallrectProductNoon6,
                 noonImg6, noon6Lb , wishlistButton6noon , listButton6noon );

        itemsBox3noon.getChildren().addAll(rectitemsNoon5, rectitemsnoon6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4noon = new HBox(40);

        itemsBox4noon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNoon7 = new StackPane();
        Rectangle rectProductnoon7 = new Rectangle(110, 155);
        rectProductnoon7.setFill(PinkRectL);
        rectProductnoon7.setArcWidth(10);
        rectProductnoon7.setArcHeight(10);

        Rectangle SmallrectProductNoon7 = new Rectangle(110, 30);
        SmallrectProductNoon7.setFill(PinkRectD);
        SmallrectProductNoon7.setArcWidth(10);
        SmallrectProductNoon7.setArcHeight(10);
        SmallrectProductNoon7.setTranslateY(62);

        Image Noon7 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\anker7.PNG");
        ImageView noonImg7 = new ImageView(Noon7);//
        noonImg7.setFitHeight(90);
        noonImg7.setFitWidth(85);
        noonImg7.setTranslateY(-30);

        Label noon7Lb = new Label("Power Bank\n167SR");
        noon7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon7Lb.setPadding(new Insets(0, 0, 25, 0));
        noon7Lb.setTranslateY(40);
        
        ImageView listbtn1view7noon = new ImageView(listimg1);//
        listbtn1view7noon.setFitHeight(68);
        listbtn1view7noon.setFitWidth(68);
        
        ImageView wishlistView7noon = new ImageView(wishlistimg1);
        wishlistView7noon.setFitHeight(50);
        wishlistView7noon.setFitWidth(50);
        
        Button listButton7noon = new Button();
        listButton7noon.setGraphic(new StackPane(listbtn1view7noon));
        listButton7noon.setPrefSize(35, 35);
        listButton7noon.setTranslateY(65);
        listButton7noon.setTranslateX(20);
        listButton7noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton7noon = new Button();
        wishlistButton7noon.setGraphic(new StackPane(wishlistView7noon));
        wishlistButton7noon.setPrefSize(35, 35);
        wishlistButton7noon.setTranslateY(61);
        wishlistButton7noon.setTranslateX(-20);
        wishlistButton7noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNoon7.getChildren().addAll(rectProductnoon7, SmallrectProductNoon7,
                 noonImg7, noon7Lb, wishlistButton7noon , listButton7noon);
        ///////////////////////////////////////////////
        StackPane rectitemsNoon8 = new StackPane();
        Rectangle rectProductNoon8 = new Rectangle(110, 155);
        rectProductNoon8.setFill(PinkRectL);
        rectProductNoon8.setArcWidth(10);
        rectProductNoon8.setArcHeight(10);

        Rectangle SmallrectProductNoon8 = new Rectangle(110, 30);
        SmallrectProductNoon8.setFill(PinkRectD);
        SmallrectProductNoon8.setArcWidth(10);
        SmallrectProductNoon8.setArcHeight(10);
        SmallrectProductNoon8.setTranslateY(62);

        Image noon8 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\iphone8.PNG");
        ImageView noonImg8 = new ImageView(noon8);//
        noonImg8.setFitHeight(90);
        noonImg8.setFitWidth(95);
        noonImg8.setTranslateY(-34);

        Label noon8Lb = new Label("iPhone 15\n5,249SR");
        noon8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon8Lb.setPadding(new Insets(0, 0, 25, 0));
        noon8Lb.setTranslateY(38);
        
        ImageView listbtn1view8noon = new ImageView(listimg1);//
        listbtn1view8noon.setFitHeight(68);
        listbtn1view8noon.setFitWidth(68);
        
        ImageView wishlistView8noon = new ImageView(wishlistimg1);
        wishlistView8noon.setFitHeight(50);
        wishlistView8noon.setFitWidth(50);
        
        Button listButton8noon = new Button();
        listButton8noon.setGraphic(new StackPane(listbtn1view8noon));
        listButton8noon.setPrefSize(35, 35);
        listButton8noon.setTranslateY(65);
        listButton8noon.setTranslateX(20);
        listButton8noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton8noon = new Button();
        wishlistButton8noon.setGraphic(new StackPane(wishlistView8noon));
        wishlistButton8noon.setPrefSize(35, 35);
        wishlistButton8noon.setTranslateY(61);
        wishlistButton8noon.setTranslateX(-20);
        wishlistButton8noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNoon8.getChildren().addAll(rectProductNoon8 , SmallrectProductNoon8
                , noonImg8, noon8Lb , wishlistButton8noon , listButton8noon);

        itemsBox4noon.getChildren().addAll(rectitemsNoon7, rectitemsNoon8 );

        // fifth 2/////////////////////////////
        HBox itemsBox5noon = new HBox(40);

        itemsBox5noon.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsNoon9 = new StackPane();
        Rectangle rectProductNoon9 = new Rectangle(110, 155);
        rectProductNoon9.setFill(PinkRectL);
        rectProductNoon9.setArcWidth(10);
        rectProductNoon9.setArcHeight(10);

        Rectangle SmallrectProductNoon9 = new Rectangle(110, 30);
        SmallrectProductNoon9.setFill(PinkRectD);
        SmallrectProductNoon9.setArcWidth(10);
        SmallrectProductNoon9.setArcHeight(10);
        SmallrectProductNoon9.setTranslateY(62);

        Image noon9 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\drip9.PNG");
        ImageView noonImg9 = new ImageView(noon9);//
        noonImg9.setFitHeight(88);
        noonImg9.setFitWidth(70);
        noonImg9.setTranslateY(-37);

        Label noon9Lb = new Label("Drip Coffee Maker\n256SR");
        noon9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        noon9Lb.setPadding(new Insets(0, 5, 25, 0));
        noon9Lb.setTranslateY(40);
        
        ImageView listbtn1view9noon = new ImageView(listimg1);//
        listbtn1view9noon.setFitHeight(68);
        listbtn1view9noon.setFitWidth(68);
        
        ImageView wishlistView9noon = new ImageView(wishlistimg1);
        wishlistView9noon.setFitHeight(50);
        wishlistView9noon.setFitWidth(50);
        
        Button listButton9noon = new Button();
        listButton9noon.setGraphic(new StackPane(listbtn1view9noon));
        listButton9noon.setPrefSize(35, 35);
        listButton9noon.setTranslateY(65);
        listButton9noon.setTranslateX(20);
        listButton9noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton9noon = new Button();
        wishlistButton9noon.setGraphic(new StackPane(wishlistView9noon));
        wishlistButton9noon.setPrefSize(35, 35);
        wishlistButton9noon.setTranslateY(61);
        wishlistButton9noon.setTranslateX(-20);
        wishlistButton9noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNoon9.getChildren().addAll(rectProductNoon9, SmallrectProductNoon9,
                 noonImg9, noon9Lb , wishlistButton9noon , listButton9noon);
/////////////////////////////////////////////////////////
        StackPane rectitemsNoon10 = new StackPane();
        Rectangle rectProductNoon10 = new Rectangle(110, 155);
        rectProductNoon10.setFill(PinkRectL);
        rectProductNoon10.setArcWidth(10);
        rectProductNoon10.setArcHeight(10);

        Rectangle SmallrectProductNoon10 = new Rectangle(110, 30);
        SmallrectProductNoon10.setFill(PinkRectD);
        SmallrectProductNoon10.setArcWidth(10);
        SmallrectProductNoon10.setArcHeight(10);
        SmallrectProductNoon10.setTranslateY(62);

        Image noon10 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\pots10.PNG");
        ImageView NoonImg10 = new ImageView(noon10);//
        NoonImg10.setFitHeight(80);
        NoonImg10.setFitWidth(70);
        NoonImg10.setTranslateY(-35);

        Label Noon10Lb = new Label("Cookware Set\n269SR");
        Noon10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        Noon10Lb.setPadding(new Insets(0, 0, 25, 0));
        Noon10Lb.setTranslateY(38);
        
        ImageView listbtn1view10noon = new ImageView(listimg1);//
        listbtn1view10noon.setFitHeight(68);
        listbtn1view10noon.setFitWidth(68);
        
        ImageView wishlistView10Noon = new ImageView(wishlistimg1);
        wishlistView10Noon.setFitHeight(50);
        wishlistView10Noon.setFitWidth(50);
        
        Button listButton10Noon = new Button();
        listButton10Noon.setGraphic(new StackPane(listbtn1view10noon));
        listButton10Noon.setPrefSize(35, 35);
        listButton10Noon.setTranslateY(65);
        listButton10Noon.setTranslateX(20);
        listButton10Noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton10noon = new Button();
        wishlistButton10noon.setGraphic(new StackPane(wishlistView10Noon));
        wishlistButton10noon.setPrefSize(35, 35);
        wishlistButton10noon.setTranslateY(61);
        wishlistButton10noon.setTranslateX(-20);
        wishlistButton10noon.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsNoon10.getChildren().addAll(rectProductNoon10, SmallrectProductNoon10
                , NoonImg10, Noon10Lb , wishlistButton10noon , listButton10Noon);

        itemsBox5noon.getChildren().addAll(rectitemsNoon9, rectitemsNoon10);

        centerBoxNOON.getChildren().addAll(centerSpendingNOON, itemsBoxNOON, itemsBox2noon,
                 itemsBox3noon, itemsBox4noon, itemsBox5noon);
        
        
        ScrollPane scrollPanenoon = new ScrollPane(centerBoxNOON);
        scrollPanenoon.setFitToWidth(true);
        scrollPanenoon.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        // bottom 
        StackPane bottomNoonroot = new StackPane();

        Rectangle rectangleBNoon = new Rectangle();
        rectangleBNoon.setWidth(360);
        rectangleBNoon.setHeight(60);
        rectangleBNoon.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBNoon, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottomNoonroot.getChildren().addAll(rectangleBNoon, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

           
        noonPane.setTop(topNOONroot);       
        noonPane.setCenter(scrollPanenoon);
        noonPane.setBottom(bottomNoonroot);

        Scene scene = new Scene(noonPane, 350, 600);
        stage.setScene(scene); // Place the scene in the stage
        stage.show(); //

        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        ProfileScene profileScene = new ProfileScene();

//-------------------------------- ACTION ----------------------------------------------//

        backImg.setOnMouseClicked(e -> {
            homePageScene.start(stage);
        });


        homeButton.setOnAction(e -> {
            homePageScene.start(stage);
        });

        wishlistButton.setOnAction(e -> {
            wishlistScene.start(stage);
        });

        listButton.setOnAction(e -> {
            listScene.start(stage);
        });

//        profileButton.setOnAction(e -> {
//            profileScene.start(new Stage());
//        });
    }

    
}


