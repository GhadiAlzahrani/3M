/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.persistence.*;

/*wishlistID INT(10) ,
  ListID INT(10) ,
  shopName VARCHAR(255),
  urlImage VARCHAR(255)*/
@Entity
@Table(name = "item")
public class Item implements java.io.Serializable {

    @Id
    @Column(name = "ItemID")
    private int ItemID;

    @Column(name = "name")
    private String name;

    @Column(name = "price")
    private double price;

    @Column(name = "category")
    private String category;

    @Column(name = "userID")
    private int userID;

    @Column(name = "ListID")
    private int ListID;

    @Column(name = "shopName")
    private String shopName;

    @Column(name = "urlImage")
    private String urlImage;

    public Item() {
    }

   

    public Item(int userID, String name, double price, String category, String shopName, String urlImage) {
    this.userID = userID;
    this.name = name;
    this.price = price;
    this.category = category;
    this.shopName = shopName;
    this.urlImage = urlImage;
}


//        public int getItemID() {
//        return this.ItemID;
//        }
//        public void setItemID(int ItemID) {
//        this.ItemID = ItemID;
//        }
    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getListID() {
        return ListID;
    }

    public void setListID(int ListID) {
        this.ListID = ListID;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String urlImage) {
        this.urlImage = urlImage;
    }

}
