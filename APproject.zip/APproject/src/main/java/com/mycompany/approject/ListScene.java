/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import java.io.File;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


public class ListScene extends Application {

    @Override
    public void start(Stage stage) {

        ////-----------------------------------------    LIST SCENE ------------------------------------------------- ////

        // ------------------------------------------------- color -------------------------------------------------
        Color colorBG = Color.web("#c4d5de",1);//light blue for background
        Color blueRect = Color.web("#657da1",1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2",1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD",1);//Light pink

        BorderPane ListPane = new BorderPane();
        ListPane.setStyle("-fx-background-color: #c4d5de;");


        // -------------------------------------- top --------------------------------------
        StackPane topwishListtroot = new StackPane();

        Rectangle recttUpwishListt = new Rectangle();
        recttUpwishListt.setX(500);
        recttUpwishListt.setY(80);
        recttUpwishListt.setWidth(356);
        recttUpwishListt.setHeight(90);
        recttUpwishListt.setFill(blueRect);

        ////back//
        Image backwishListt = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\backarrow2.png");
        ImageView backwishListtImg = new ImageView(backwishListt);//
        backwishListtImg.setFitHeight(25);
        backwishListtImg.setFitWidth(25);
        StackPane.setMargin(backwishListtImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backwishListtImg, Pos.CENTER_LEFT);


        Text wishListtText = new Text("List");
        wishListtText.setStyle("-fx-font: normal bold 14px 'serif'");
        wishListtText.setFill(Color.WHITE);

        StackPane.setAlignment(wishListtText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishListtText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(recttUpwishListt, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldwishListt = new TextField();
        searchFieldwishListt.setFocusTraversable(false);
        searchFieldwishListt.setPromptText("Search here ...");
        searchFieldwishListt.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldwishListt.setPrefWidth(200);
        searchFieldwishListt.setPrefHeight(25);

        Rectangle searchFieldShapewl = new Rectangle();
        searchFieldShapewl.setWidth(200);
        searchFieldShapewl.setHeight(25);
        searchFieldShapewl.setArcWidth(25);
        searchFieldShapewl.setArcHeight(30);
        searchFieldwishListt.setShape(searchFieldShapewl);

        Image searchimgeewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\search.png");
        ImageView searchViewWLimg = new ImageView(searchimgeewl);
        searchViewWLimg.setFitHeight(19);
        searchViewWLimg.setFitWidth(22);

        StackPane.setMargin(searchViewWLimg, new Insets(0, 0, 0, 170));
        StackPane searchwishListtContainer = new StackPane();
        searchwishListtContainer.getChildren().addAll(searchFieldwishListt, searchViewWLimg);

        HBox searchBoxwishListt = new HBox(searchwishListtContainer);

        StackPane.setMargin(searchBoxwishListt, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeeImagewl = new Image("file:C:\\Users\\pc\\Downloads\\notices.png");
        ImageView noticeViewwl = new ImageView(noticeeImagewl);
        noticeViewwl.setFitHeight(20);
        noticeViewwl.setFitWidth(15);

        Button noticeeButtonwl = new Button();
        noticeeButtonwl.setGraphic(new StackPane(noticeViewwl));
        noticeeButtonwl.setPrefSize(30, 30);
        noticeeButtonwl.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeeButtonwl, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeeButtonwl, Pos.CENTER_RIGHT);

        ////list //////
        Image listt1wl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\list1.png");
        ImageView listt1Imgwl = new ImageView(listt1wl);//
        listt1Imgwl.setFitHeight(18);
        listt1Imgwl.setFitWidth(23);

        StackPane.setMargin(listt1Imgwl, new Insets(35, 24, 0, 0));
        StackPane.setAlignment(listt1Imgwl, Pos.CENTER_RIGHT);


        ////Customized Button //////
        Image Add = new Image("file:C:\\Users\\pc\\Downloads\\AddPlus.png");
        ImageView addView = new ImageView(Add);
        addView.setFitHeight(30); //setting the fit height and width of the image view
        addView.setFitWidth(30);

        Button addButton = new Button();
        addButton.setGraphic(new StackPane(addView));
        addButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(addButton, Pos.CENTER);
        StackPane.setMargin(addButton, new Insets(30, 0, 0, 190));




        topwishListtroot.getChildren().addAll(recttUpwishListt, wishListtText, searchBoxwishListt,
                noticeeButtonwl, listt1Imgwl ,backwishListtImg,addButton);
        ListPane.setTop(topwishListtroot);


        // -------------------------------------- center --------------------------------------
        VBox centerBoxwishListt = new VBox();
        centerBoxwishListt.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendiingwl = new StackPane();

        Rectangle rectProduct1wl = new Rectangle(200, 70);
        rectProduct1wl.setFill(PinkRectD);
        rectProduct1wl.setArcWidth(10);
        rectProduct1wl.setArcHeight(10);


        Label spendiingwlLb = new Label("Total Spending");
        spendiingwlLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendiingwlLb.setPadding(new Insets(0, 0, 25, 0));


        centerSpendiingwl.setPadding(new Insets(20, 55, 0, 60));
        centerSpendiingwl.getChildren().addAll(rectProduct1wl, spendiingwlLb);




        ScrollPane wishListscrollPane = new ScrollPane(centerBoxwishListt);
        wishListscrollPane.setFitToWidth(true);
        wishListscrollPane.setFitToHeight(true);

        // -------------------------------------- bottom --------------------------------------
        StackPane bottomwishListtroot = new StackPane();

        Rectangle rectanglewlB = new Rectangle();
        rectanglewlB.setWidth(360);
        rectanglewlB.setHeight(60);
        rectanglewlB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectanglewlB, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\home.png");

        ImageView homeViewwl = new ImageView(imageHomewl);
        homeViewwl.setFitHeight(50);
        homeViewwl.setFitWidth(60);

        Button homeButtonwl = new Button();
        homeButtonwl.setGraphic(new StackPane(homeViewwl));
        homeButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonwl, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonwl, new Insets(10, 0, 0, 30));

        Text textHomewl = new Text("Home");
        textHomewl.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomewl.setFill(Color.WHITE);

        StackPane.setAlignment(textHomewl, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomewl, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\wishlist.png");
        ImageView wishlistViewwl = new ImageView(wishlistImagewl);
        wishlistViewwl.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewwl.setFitWidth(70);

        Button wishlistButtonwl = new Button();
        wishlistButtonwl.setGraphic(new StackPane(wishlistViewwl));
        wishlistButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonwl, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonwl, new Insets(10, 0, 0, 91));

        Text wishlistTextwl = new Text("Wishlist");
        wishlistTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextwl, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextwl, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\list.png");
        ImageView listViewwl = new ImageView(listImagewl);
        listViewwl.setFitHeight(70); //setting the fit height and width of the image view
        listViewwl.setFitWidth(80);

        Button listButtonwl = new Button();
        listButtonwl.setGraphic(new StackPane(listViewwl));
        listButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonwl, Pos.CENTER);
        StackPane.setMargin(listButtonwl, new Insets(15, 0, 0, 60));

        Text listTextwl = new Text("List");
        listTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(listTextwl, Pos.CENTER);
        StackPane.setMargin(listTextwl, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImagewl = new Image("file:C:\\Users\\pc\\Downloads\\APprojectPictures\\profile.png");
        ImageView profileViewwl = new ImageView(profileImagewl);
        profileViewwl.setFitHeight(70); //setting the fit height and width of the image view
        profileViewwl.setFitWidth(100);

        Button profileButtonwl = new Button();
        profileButtonwl.setGraphic(new StackPane(profileViewwl));
        profileButtonwl.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonwl, Pos.CENTER);
        StackPane.setMargin(profileButtonwl, new Insets(0, 0, 0, 210));

        Text profileTextwl = new Text("Profile");
        profileTextwl.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextwl.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextwl, Pos.CENTER);
        StackPane.setMargin(profileTextwl, new Insets(50, 0, 0, 200));


        bottomwishListtroot.getChildren().addAll(rectanglewlB, homeButtonwl, textHomewl
                , wishlistButtonwl , wishlistTextwl , listButtonwl ,listTextwl , profileButtonwl , profileTextwl );


        ListPane.setTop(topwishListtroot);
        ListPane.setCenter(wishListscrollPane);
        ListPane.setBottom(bottomwishListtroot);

        Scene ListScene = new Scene(ListPane, 350, 600);











        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////----------------------------------------- Customized Item SCENE -------------------------------------------------////


        BorderPane customizedItemPane = new BorderPane();

        customizedItemPane.setStyle("-fx-background-color: #c4d5de;");


        // -------------------------------------- top --------------------------------------

        StackPane topCustomizedtroot = new StackPane();

        Rectangle recttUpci = new Rectangle();
        recttUpci.setX(500);
        recttUpci.setY(80);
        recttUpci.setWidth(356);
        recttUpci.setHeight(90);
        recttUpci.setFill(blueRect);

        ////back//
        Image backci = new Image("file:C:\\Users\\pc\\Downloads\\backarrow2.png");
        ImageView backciImg = new ImageView(backci);//
        backciImg.setFitHeight(25);
        backciImg.setFitWidth(25);
        StackPane.setMargin(backciImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backciImg, Pos.CENTER_LEFT);


        Text ciText = new Text("Customized Item!");
        ciText.setStyle("-fx-font: normal bold 14px 'serif'");
        ciText.setFill(Color.WHITE);

        StackPane.setAlignment(ciText, Pos.CENTER_LEFT);
        StackPane.setMargin(ciText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(recttUpci, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldci = new TextField();
        searchFieldci.setFocusTraversable(false);
        searchFieldci.setPromptText("Search here ...");
        searchFieldci.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldci.setPrefWidth(200);
        searchFieldci.setPrefHeight(25);

        Rectangle searchFieldShapeci = new Rectangle();
        searchFieldShapeci.setWidth(200);
        searchFieldShapeci.setHeight(25);
        searchFieldShapeci.setArcWidth(25);
        searchFieldShapeci.setArcHeight(30);
        searchFieldci.setShape(searchFieldShapeci);

        Image searchimgeeci = new Image("file:C:\\Users\\pc\\Downloads\\search.png");
        ImageView searchViewciimg = new ImageView(searchimgeeci);
        searchViewciimg.setFitHeight(19);
        searchViewciimg.setFitWidth(22);

        StackPane.setMargin(searchViewciimg, new Insets(0, 0, 0, 170));
        StackPane searchciContainer = new StackPane();
        searchciContainer.getChildren().addAll(searchFieldci, searchViewciimg);

        HBox searchBoxci = new HBox(searchciContainer);

        StackPane.setMargin(searchBoxci, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeeImageci = new Image("file:C:\\Users\\pc\\Downloads\\notices.png");
        ImageView noticeViewci = new ImageView(noticeeImageci);
        noticeViewci.setFitHeight(20);
        noticeViewci.setFitWidth(15);

        Button noticeeButtonci = new Button();
        noticeeButtonci.setGraphic(new StackPane(noticeViewci));
        noticeeButtonci.setPrefSize(30, 30);
        noticeeButtonci.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeeButtonci, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeeButtonci, Pos.CENTER_RIGHT);

        ////list //////
        Image listt1ci = new Image("file:C:\\Users\\pc\\Downloads\\list1.png");
        ImageView listt1Imgci = new ImageView(listt1ci);//
        listt1Imgci.setFitHeight(18);
        listt1Imgci.setFitWidth(23);

        StackPane.setMargin(listt1Imgci, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(listt1Imgci, Pos.CENTER_RIGHT);

        topCustomizedtroot.getChildren().addAll(recttUpci, ciText, searchBoxci,
                noticeeButtonci, listt1Imgci ,backciImg);
        customizedItemPane.setTop(topCustomizedtroot);

        // -------------------------------------- center --------------------------------------
        VBox centerBoxci = new VBox(15);
        centerBoxci.setStyle("-fx-background-color: #c4d5de;");

        TextField urlTF = new TextField();
        urlTF.setPadding(new Insets(10, 0, 0, 100));
        urlTF.setFocusTraversable(false);
        urlTF.setStyle("-fx-font: normal 10px 'serif'");
        urlTF.setMaxWidth(200);

        Button chooseImageButton = new Button("Choose Image");
        chooseImageButton.setPrefHeight(10);
        chooseImageButton.setPrefWidth(80);
        chooseImageButton.setStyle("-fx-background-color:#DB8BBD; -fx-font-weight: bold;-fx-text-fill: white; -fx-font-size: 10px;");

        //  Button addPic = new Button("Add Pic");
        //  addPic.setAlignment(Pos.CENTER);
        //  addPic.setPadding(new Insets(10, 0, 0, 30));

        HBox addPicBox = new HBox(20);
        //addPicBox.setPadding(new Insets(10, 0, 0, 50));
        //addPicBox.getChildren().addAll(chooseImaeButton,urlTF);


        Label itemDetails = new Label("Fill Item Details:");
        itemDetails.setStyle("-fx-font: normal bold 16px 'serif';  ");

        Label itemName =  new Label("Item Name:");
//        TextField itemNameTF = new TextField();
//        itemNameTF.setFocusTraversable(false);
//
//        itemNameTF.setPadding(new Insets(10, 0, 0, 100));
//        itemNameTF.setStyle("-fx-font: normal 10px 'serif'");
//        itemNameTF.setPrefWidth(100);
//        itemNameTF.setPrefHeight(25);
        TextField itemNameTF = new TextField();
        itemNameTF.setPadding(new Insets(10, 0, 0, 100));
        itemNameTF.setFocusTraversable(false);
        itemNameTF.setStyle("-fx-font: normal 10px 'serif'");
        itemNameTF.setMaxWidth(200);

        Label itemPrice =  new Label("Item Price:");
        TextField itemPriceTF = new TextField();
        itemPriceTF.setPadding(new Insets(10, 0, 0, 100));
        itemPriceTF.setFocusTraversable(false);
        itemPriceTF.setStyle("-fx-font: normal 10px 'serif'");
        itemPriceTF.setMaxWidth(200);



        Label itemCategory = new Label("Choose item category:");
        itemCategory.setStyle("-fx-font: normal bold 16px 'serif';  ");

        ToggleGroup group = new ToggleGroup();
        RadioButton clothes = new RadioButton("Clothes");
        clothes.setToggleGroup(group);
        RadioButton beauty = new RadioButton("Beauty");
        beauty.setToggleGroup(group);
        RadioButton bills = new RadioButton("Bills");
        bills.setToggleGroup(group);
        RadioButton pharmacy = new RadioButton("Pharmacy");
        pharmacy.setToggleGroup(group);
        RadioButton jewelry = new RadioButton("Jewelry");
        jewelry.setToggleGroup(group);
        RadioButton stationary = new RadioButton("Stationary");
        stationary.setToggleGroup(group);
        RadioButton food = new RadioButton("Food");
        food.setToggleGroup(group);
        HBox firstRow = new HBox(10);
        firstRow.getChildren().addAll(clothes,beauty,bills,pharmacy);
        HBox secondRow = new HBox(10);
        secondRow.getChildren().addAll(jewelry,stationary,food);

        Button addItem = new Button("Add Item");
        addItem.setStyle("-fx-background-color:#DB8BBD; -fx-font-weight: bold;-fx-text-fill: white;");


        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
                new Stop(0, PinkRectD), new Stop(1, PinkRectL));

        Line line1 = new Line(50, 50, 300, 50);
        line1.setStroke(gradient);
        line1.setStrokeWidth(3);

        Line line2 = new Line(50, 50, 300, 50);
        line2.setStroke(gradient);
        line2.setStrokeWidth(3);


        HBox itemNameHbx = new HBox(10);
        itemNameHbx.getChildren().addAll(itemName,itemNameTF);

        HBox itemPriceHbx = new HBox(15);
        itemPriceHbx.getChildren().addAll(itemPrice,itemPriceTF);

        Label anotherItem = new Label("To add another item, click here.");
        anotherItem.setTextFill(gradient);

        VBox itemControls = new VBox(20);
        itemControls.getChildren().addAll(line1);

        itemControls.getChildren().addAll(itemDetails,itemNameHbx,itemPriceHbx );
        itemControls.getChildren().addAll(line2);
        itemControls.getChildren().addAll(itemCategory,firstRow,secondRow,addItem,anotherItem);

        itemControls.setPadding(new Insets(0, 0, 0, 25) );




        addPicBox.setPadding(new Insets(25, 0, 0, 25) );
        centerBoxci.getChildren().addAll(addPicBox,itemControls);

        // spending rectangle
        StackPane centerSpendiingci = new StackPane();


        Rectangle rectProduct1ci = new Rectangle(200, 70);
        rectProduct1ci.setFill(PinkRectD);
        rectProduct1ci.setArcWidth(10);
        rectProduct1ci.setArcHeight(10);


        Label spendiingciLb = new Label("Total Spending");
        spendiingciLb.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendiingciLb.setPadding(new Insets(0, 0, 25, 0));


        centerSpendiingci.setPadding(new Insets(20, 55, 0, 60));
        centerSpendiingci.getChildren().addAll(rectProduct1ci, spendiingciLb);





        ScrollPane ciscrollPane = new ScrollPane(centerBoxci);
        ciscrollPane.setFitToWidth(true);
        ciscrollPane.setFitToHeight(true);

        // -------------------------------------- bottom --------------------------------------
        StackPane bottomciroot = new StackPane();

        Rectangle rectangleciB = new Rectangle();
        rectangleciB.setWidth(360);
        rectangleciB.setHeight(60);
        rectangleciB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleciB, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomeci = new Image("file:C:\\Users\\pc\\Downloads\\home.png");

        ImageView homeViewci = new ImageView(imageHomeci);
        homeViewci.setFitHeight(50);
        homeViewci.setFitWidth(60);

        Button homeButtonci = new Button();
        homeButtonci.setGraphic(new StackPane(homeViewci));
        homeButtonci.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonci, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonci, new Insets(10, 0, 0, 30));

        Text textHomeci = new Text("Home");
        textHomeci.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomeci.setFill(Color.WHITE);

        StackPane.setAlignment(textHomeci, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomeci, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImageci = new Image("file:C:\\Users\\pc\\Downloads\\wishlist.png");
        ImageView wishlistViewci = new ImageView(wishlistImageci);
        wishlistViewci.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewci.setFitWidth(70);

        Button wishlistButtonci = new Button();
        wishlistButtonci.setGraphic(new StackPane(wishlistViewci));
        wishlistButtonci.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonci, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonci, new Insets(10, 0, 0, 91));

        Text wishlistTextci = new Text("Wishlist");
        wishlistTextci.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextci.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextci, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextci, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImagewci = new Image("file:C:\\Users\\pc\\Downloads\\list.png");
        ImageView listViewci = new ImageView(listImagewci);
        listViewci.setFitHeight(70); //setting the fit height and width of the image view
        listViewci.setFitWidth(80);

        Button listButtonci = new Button();
        listButtonci.setGraphic(new StackPane(listViewci));
        listButtonci.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonci, Pos.CENTER);
        StackPane.setMargin(listButtonci, new Insets(15, 0, 0, 60));

        Text listTextci = new Text("List");
        listTextci.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextci.setFill(Color.WHITE);

        StackPane.setAlignment(listTextci, Pos.CENTER);
        StackPane.setMargin(listTextci, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImageci = new Image("file:C:\\Users\\pc\\Downloads\\profile.png");
        ImageView profileViewci = new ImageView(profileImageci);
        profileViewci.setFitHeight(70); //setting the fit height and width of the image view
        profileViewci.setFitWidth(100);

        Button profileButtonci = new Button();
        profileButtonci.setGraphic(new StackPane(profileViewci));
        profileButtonci.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonci, Pos.CENTER);
        StackPane.setMargin(profileButtonci, new Insets(0, 0, 0, 210));

        Text profileTextci = new Text("Profile");
        profileTextci.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextci.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextci, Pos.CENTER);
        StackPane.setMargin(profileTextci, new Insets(50, 0, 0, 200));



        bottomciroot.getChildren().addAll(rectangleciB, homeButtonci, textHomeci
                , wishlistButtonci , wishlistTextci , listButtonci ,listTextci , profileButtonci , profileTextci );


        customizedItemPane.setTop(topCustomizedtroot);
        customizedItemPane.setCenter(centerBoxci);
        customizedItemPane.setBottom(bottomciroot);

        // scene


        //////// ------------action-----------------------------------------------------

        addButton.setOnAction(e -> {
            Scene CustomizedItemScene = new Scene(customizedItemPane, 350, 600);
            stage.setScene(CustomizedItemScene);
        });




        ImageView imageView = new ImageView();
        imageView.setFitWidth(300);
        imageView.setFitHeight(300);

        // Create a FileChooser
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif", "*.bmp", "*.jpeg")
        );

        // Create a Button to trigger the file selection

        chooseImageButton.setOnAction(e -> {
            // Show the file chooser dialog
            File selectedFile = fileChooser.showOpenDialog(stage);

            // Check if a file was selected
            if (selectedFile != null) {
                // Load selected image into the ImageView
                // Image selectedImage = new Image(selectedFile.toURI().toString());
                //imageView.setImage(selectedImage);

                // Set the URL of the selected image in the urlTF TextField
                String imageURL = selectedFile.toURI().toString();
                urlTF.setText(imageURL);
            }
        });

        // Create the root layout
        VBox rootCustomized = new VBox(10);
        rootCustomized.getChildren().addAll(chooseImageButton);

        addPicBox.getChildren().addAll(urlTF,rootCustomized);



        
      


HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
       // ProfileScene profileScene = new ProfileScene();
        
        //-------------------------------- ACTION ----------------------------------------------//
        textHomeci.setOnMouseClicked( e-> {
              homePageScene.start(stage);
         });
         
          wishlistTextci.setOnMouseClicked( e-> {
              wishlistScene.start(stage);
         });
          
          listTextci.setOnMouseClicked( e-> {
              listScene.start(stage);
         });
          
//          profileTextci.setOnMouseClicked( e-> {
//              profileScene.start(stage);
//         });
        
        
        backwishListtImg.setOnMouseClicked(e -> {
            homePageScene.start(stage);
        });
        
        
        homeButtonci.setOnAction(e -> {
            homePageScene.start(stage);
        });
        
        wishlistButtonci.setOnAction(e -> {
            wishlistScene.start(stage);
        });
        
        listButtonci.setOnAction(e -> {
            listScene.start(stage);
        });
//        
//        profileButtonci.setOnAction(e -> {
//            profileScene.start(new Stage());
//        });



        stage.setScene(ListScene);
        stage.show();
    }



}
