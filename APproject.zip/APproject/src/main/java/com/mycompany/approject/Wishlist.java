/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */
/*
 *
 *

/**
 *
 * @author raghadalsebayyil
 */

import javax.persistence.*;


@Entity
@Table(name="wishlist")
public class Wishlist implements java.io.Serializable {
    
    @Id
    @Column(name = "wishlistID")
    private int wishlistID;
    
    @Column(name = "UserID")
    private int UserID;
    


    public Wishlist() {
    }

    public Wishlist(int UserID) {
               this.UserID = UserID;
    }

    
    
    public int getWishlistID() {
        return wishlistID;
    }

    public void setWishlistID(int wishlistID) {
        this.wishlistID = wishlistID;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int UserID) {
        this.UserID = UserID;
    }
    
}


