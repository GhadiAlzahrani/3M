package com.mycompany.approject;


import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.text.DecimalFormat;

import static java.lang.Math.max;
import static java.lang.Math.min;
import static javafx.application.Application.launch;

public class BudgetScene extends Application {



    TextField pharmacyTextField33333 = new TextField();
    TextField foodTextField3434 = new TextField();
    TextField jewelryTextField362 = new TextField();
    TextField beautyTextField36 = new TextField();
    TextField clothesTextField54 = new TextField();
    TextField billsTextField54 = new TextField();
    TextField totalIncomeTextField7896 = new TextField();
    TextField stationaryTextField544444 = new TextField();


    @Override
    public void start(Stage stage)  {


        BorderPane budgetRoot = new BorderPane();
        budgetRoot.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect1111 = Color.web("#657da1", 1);//light blue for background

        // top
        StackPane topBudgetRoot = new StackPane();

        Rectangle rectangleT765 = new Rectangle();
        rectangleT765.setX(500);
        rectangleT765.setY(80);
        rectangleT765.setWidth(356);
        rectangleT765.setHeight(90);
        rectangleT765.setFill(blueRect1111);

        ////back//
        Image back = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\backarrow2.png");
        ImageView budgetBackImg = new ImageView(back);//
        budgetBackImg.setFitHeight(25);
        budgetBackImg.setFitWidth(25);
        StackPane.setMargin(budgetBackImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(budgetBackImg, Pos.CENTER_LEFT);


        Text budgetText = new Text("Budget");
        budgetText.setStyle("-fx-font: normal bold 14px 'serif'");
        budgetText.setFill(Color.WHITE);

        StackPane.setAlignment(budgetText, Pos.CENTER_LEFT);
        StackPane.setMargin(budgetText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleT765, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchField456 = new TextField();
        searchField456.setFocusTraversable(false);
        searchField456.setPromptText("Search here ...");
        searchField456.setStyle("-fx-font: normal 10px 'serif'");
        searchField456.setPrefWidth(200);
        searchField456.setPrefHeight(25);
        Rectangle searchFieldShape3456 = new Rectangle();
        searchFieldShape3456.setWidth(200);
        searchFieldShape3456.setHeight(25);
        searchFieldShape3456.setArcWidth(25);
        searchFieldShape3456.setArcHeight(30);
        searchField456.setShape(searchFieldShape3456);

        Image searchImage4567 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\search.png");
        ImageView searchView765 = new ImageView(searchImage4567);
        searchView765.setFitHeight(19);
        searchView765.setFitWidth(22);

        StackPane.setMargin(searchView765, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainert735 = new StackPane();
        searchFieldContainert735.getChildren().addAll(searchField456, searchView765);

        HBox searchBox786 = new HBox(searchFieldContainert735);

        StackPane.setMargin(searchBox786, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage212 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\notices.png");
        ImageView noticeView121 = new ImageView(noticeImage212);
        noticeView121.setFitHeight(20);
        noticeView121.setFitWidth(15);

        Button noticeButton78 = new Button();
        noticeButton78.setGraphic(new StackPane(noticeView121));
        noticeButton78.setPrefSize(30, 30);
        noticeButton78.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButton78, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButton78, Pos.CENTER_RIGHT);

        ////list //////
        Image list1896 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list1.png");
        ImageView list1Img976 = new ImageView(list1896);//
        list1Img976.setFitHeight(18);
        list1Img976.setFitWidth(23);

        StackPane.setMargin(list1Img976, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img976, Pos.CENTER_RIGHT);

        topBudgetRoot.getChildren().addAll(rectangleT765, budgetText, searchBox786,
                noticeButton78, list1Img976 ,budgetBackImg);
        budgetRoot.setTop(topBudgetRoot);



        ///////////////budget///////////
        BorderPane budgetBorderPane =new BorderPane();

        VBox budgetBox = new VBox(10);
        budgetBox.setPadding(new Insets(25,20,20,25));
        budgetBorderPane.setCenter(budgetBox);
        // Big bold "Budget" text


        // Labels and TextFields for different categories

        //
        Label totalIncomeLabel = new Label("Total Income:");
        totalIncomeTextField7896.setMaxWidth(100);
        totalIncomeTextField7896.setPromptText("Total Income amount");
        HBox totalIncomeBox = new HBox(5);
        totalIncomeBox.setPadding(new Insets(15,0,0,60));
        totalIncomeBox.getChildren().addAll(totalIncomeLabel, totalIncomeTextField7896);


        //


        budgetBox.getChildren().addAll(totalIncomeBox);

        //
        HBox first2Box34 = new HBox(35);
        first2Box34.setPadding(new Insets(35,0,0,0));
        VBox billsBox234 = new VBox(5);
        Label billsLabel2245 = new Label("Bills:");
        billsTextField54.setMaxWidth(100);
        billsTextField54.setPromptText("Bills amount");
        billsBox234.getChildren().addAll(billsLabel2245, billsTextField54);


        Label clothesLabel2542 = new Label("Clothes:");
        clothesTextField54.setMaxWidth(100);
        clothesTextField54.setPromptText("Clothes amount");
        VBox clothesBox45 = new VBox(5);
        clothesBox45.setPadding(new Insets(0,0,0,40));

        clothesBox45.getChildren().addAll(clothesLabel2542, clothesTextField54);
        first2Box34.getChildren().addAll(billsBox234,clothesBox45);

        //
        budgetBox.getChildren().add(first2Box34);

        //
        HBox sec2Box425 = new HBox(35);
        sec2Box425.setPadding(new Insets(15,0,0,0));

        Label beautyLabel235 = new Label("Beauty:");
        beautyTextField36.setMaxWidth(100);
        beautyTextField36.setPromptText("Beauty amount");
        VBox beautyBox635 = new VBox(5);
        beautyBox635.getChildren().addAll(beautyLabel235, beautyTextField36);


        Label jewelryLabel2635 = new Label("Jewelry:");
        jewelryTextField362.setMaxWidth(100);
        jewelryTextField362.setPromptText("Jewelry amount");
        VBox jewelryBox3621 = new VBox(5);
        jewelryBox3621.setPadding(new Insets(0,0,0,40));
        jewelryBox3621.getChildren().addAll(jewelryLabel2635, jewelryTextField362);

        sec2Box425.getChildren().addAll(beautyBox635,jewelryBox3621);

        budgetBox.getChildren().add(sec2Box425);

        //
        HBox thi2Box5426 = new HBox(35);
        thi2Box5426.setPadding(new Insets(15,0,0,0));

        Label foodLabel2466 = new Label("Food:");
        foodTextField3434.setMaxWidth(100);
        foodTextField3434.setPromptText("Food amount");
        VBox foodBox43444 = new VBox(5);
        foodBox43444.getChildren().addAll(foodLabel2466, foodTextField3434);


        Label pharmacyLabel24444 = new Label("Pharmacy:");
        pharmacyTextField33333.setMaxWidth(100);
        pharmacyTextField33333.setPromptText("Pharmacy amount");
        VBox pharmacyBox33333 = new VBox(5);
        pharmacyBox33333.setPadding(new Insets(0,0,0,40));
        pharmacyBox33333.getChildren().addAll(pharmacyLabel24444, pharmacyTextField33333);

        thi2Box5426.getChildren().addAll(foodBox43444,pharmacyBox33333);

        Label stationaryLabel25432 = new Label("Stationary:");
        stationaryTextField544444.setMaxWidth(100);
        stationaryTextField544444.setPromptText("Stationary amount");
        VBox stationaryBox98765432 = new VBox();
        stationaryBox98765432.setPadding(new Insets(15,0,0,90));
        stationaryBox98765432.getChildren().addAll(stationaryLabel25432, stationaryTextField544444);


        //
        VBox submitbutton76868=new VBox();
        Button doneeButton88888 =new Button("SUBMIT");
        doneeButton88888.setStyle("-fx-background-radius: 5; -fx-background-color: #DB8BBD; ");
        submitbutton76868.getChildren().add(doneeButton88888);
        submitbutton76868.setPadding(new Insets(40,0,0,210));

        budgetBox.getChildren().addAll(thi2Box5426,stationaryBox98765432,submitbutton76868);


        budgetRoot.setCenter(budgetBorderPane);









        Scene budgetScene = new Scene(budgetRoot,350,600);
        stage.setTitle("Budget");
        stage.setScene(budgetScene);
        stage.show();


    }

}
