/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author fatim
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author fatim
 */
@Entity
@Table(name = "budget")
public class Budget implements java.io.Serializable {
    
    
     @Id
    @Column(name = "ID")
    private int ID; 

    @Column(name = "UserID")
    private int userID;
    
     @Column(name = "totalIncome")
    private int totalIncome;
    

    @Column(name = "billsAmount")
    private int billsAmount;

    @Column(name = "clothesAmount")
    private int clothesAmount;
    
    
 @Column(name = "beautyAmount")
    private int beautyAmount;
 
  @Column(name = "jewelryAmount")
    private int jewelryAmount;
  
   @Column(name = "foodAmount")
    private int foodAmount;
   
    @Column(name = "pharmacyAmount")
    private int pharmacyAmount;
    
     @Column(name = "stationaryAmount")
    private int stationaryAmount;

    public Budget(int ID, int userID, int totalIncome, int billsAmount, int clothesAmount, int beautyAmount, int jewelryAmount, int foodAmount, int pharmacyAmount, int stationaryAmount) {
        this.ID = ID;
        this.userID = userID;
        this.totalIncome = totalIncome;
        this.billsAmount = billsAmount;
        this.clothesAmount = clothesAmount;
        this.beautyAmount = beautyAmount;
        this.jewelryAmount = jewelryAmount;
        this.foodAmount = foodAmount;
        this.pharmacyAmount = pharmacyAmount;
        this.stationaryAmount = stationaryAmount;
    }

    public Budget() {
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getTotalIncome() {
        return totalIncome;
    }

    public void setTotalIncome(int totalIncome) {
        this.totalIncome = totalIncome;
    }

    public int getBillsAmount() {
        return billsAmount;
    }

    public void setBillsAmount(int billsAmount) {
        this.billsAmount = billsAmount;
    }

    public int getClothesAmount() {
        return clothesAmount;
    }

    public void setClothesAmount(int clothesAmount) {
        this.clothesAmount = clothesAmount;
    }

    public int getBeautyAmount() {
        return beautyAmount;
    }

    public void setBeautyAmount(int beautyAmount) {
        this.beautyAmount = beautyAmount;
    }

    public int getJewelryAmount() {
        return jewelryAmount;
    }

    public void setJewelryAmount(int jewelryAmount) {
        this.jewelryAmount = jewelryAmount;
    }

    public int getFoodAmount() {
        return foodAmount;
    }

    public void setFoodAmount(int foodAmount) {
        this.foodAmount = foodAmount;
    }

    public int getPharmacyAmount() {
        return pharmacyAmount;
    }

    public void setPharmacyAmount(int pharmacyAmount) {
        this.pharmacyAmount = pharmacyAmount;
    }

    public int getStationaryAmount() {
        return stationaryAmount;
    }

    public void setStationaryAmount(int stationaryAmount) {
        this.stationaryAmount = stationaryAmount;
    }
     
     
     
     
}


