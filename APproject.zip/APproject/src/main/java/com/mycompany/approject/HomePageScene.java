/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class HomePageScene extends Application {

    

    BorderPane sidebarPane;

//    public HomePageScene() {
//        ounassScene = new Ounass();
//        sheinScene = new SheIn();
//        namshiScene = new Namshi();
//        niceOneScene = new NiceOne();
//        noonScene = new Noon();
//        nahdiScene = new Nahdi();
//        iHerbScene = new IHerb();
//        amazonScene = new Amazon();
//    }

    @Override
    public void start(Stage stage) {


        IHerb iHerbScene = new IHerb();
        Amazon amazonScene = new Amazon();
        Nahdi nahdiScene = new Nahdi();
        NiceOne niceOneScene = new NiceOne();
        Noon noonScene = new Noon();
        Namshi namshiScene = new Namshi();
        Ounass ounassScene = new Ounass();
        SheIn sheinScene = new SheIn();

        BorderPane pane = new BorderPane();
        pane.setStyle("-fx-background-color: #c4d5de;");

        ///////////////////////////////////////////////////////////

        StackPane top = new StackPane();


        Rectangle rectangleT = new Rectangle();
        rectangleT.setX(500);
        rectangleT.setY(80);
        rectangleT.setWidth(356);
        rectangleT.setHeight(70);
        rectangleT.setFill(Color.web("657da1"));



        Text textWel = new Text("Welcome!");
        textWel.setStyle("-fx-font: normal bold 12px 'serif'");
        textWel.setFill(Color.WHITE);

        StackPane.setAlignment(textWel, Pos.CENTER_LEFT);
        StackPane.setMargin(textWel, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleT,new Insets(0,0,0,-15));

        ///search///

        TextField searchField = new TextField();
        searchField.setFocusTraversable(false);
        searchField.setPromptText("Search here ...");
        searchField.setStyle("-fx-font: normal 10px 'serif'");
        searchField.setPrefWidth(200);
        searchField.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchField.setShape(searchFieldShape);

        Image searchImage = new Image("file:C:\\Users\\ghadi\\Downloads\\search.png");
        ImageView searchView = new ImageView(searchImage);
        searchView.setFitHeight(19);
        searchView.setFitWidth(22);

        Button searchButton = new Button();
        searchButton.setGraphic(new StackPane(searchView));
        searchButton.setPrefSize(20, 20);
        searchButton.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        StackPane.setMargin(searchButton, new Insets(0, 0, 0, 180));

        StackPane searchFieldContainer = new StackPane();
        searchFieldContainer.getChildren().addAll(searchField, searchButton);

        HBox searchBox = new HBox(searchFieldContainer);

        StackPane.setMargin(searchBox, new Insets(34, 0, 0, 30));


        ////NOTICE/////

        Image noticeImage = new Image("file:C:\\Users\\ghadi\\Downloads\\notices.png");
        ImageView noticeView = new ImageView(noticeImage);
        noticeView.setFitHeight(20);
        noticeView.setFitWidth(15);

        Button noticeButton = new Button();
        noticeButton.setGraphic(new StackPane(noticeView));
        noticeButton.setPrefSize(30,30);
        noticeButton.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButton, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButton, Pos.CENTER_RIGHT);
        Image list2 = new Image("file:C:\\Users\\ghadi\\Downloads\\list1.png");
        ImageView list2Img = new ImageView(list2);//
        list2Img.setFitHeight(18);
        list2Img.setFitWidth(23);

        StackPane.setMargin(list2Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list2Img, Pos.CENTER_RIGHT);

        top.getChildren().addAll(  rectangleT , textWel , searchBox , noticeButton,list2Img);
        pane.setTop(top );

        //////////////////////////////////////////////////////////////////

        StackPane center = new StackPane();


        Rectangle totalRectangle = new Rectangle();
        totalRectangle.setWidth(230);
        totalRectangle.setHeight(80);
        totalRectangle.setFill(Color.web("657da1"));
        totalRectangle.setArcWidth(100);
        totalRectangle.setArcHeight(100);

        StackPane.setMargin(totalRectangle, new Insets(-300, 0, 0, 0));

        ////line1////

        Line line1 = new Line();
        line1.setStartY(totalRectangle.getHeight());
        line1.setEndX(totalRectangle.getWidth());
        line1.setEndY(totalRectangle.getHeight());
        line1.setStroke(Color.web("657da1"));
        line1.setStrokeWidth(2);

        StackPane.setMargin(line1, new Insets(-180, 0, 0, 0));

        ////////category//////////////

        Label categoryLabel = new Label("Category");
        categoryLabel.setStyle("-fx-font: normal bold 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(categoryLabel, Pos.CENTER_LEFT);
        StackPane.setMargin(categoryLabel, new Insets(-145, 0, 0, 30));


        GridPane categoryGrid = new GridPane();
        categoryGrid.setHgap(20);
        categoryGrid.setVgap(20);
        categoryGrid.setPadding(new Insets(165, 40, 30 ,45));

        ////BEAUTY////
        Image beautyImage = new Image("file:C:\\Users\\ghadi\\Downloads\\beauty.png");
        ImageView beautyView = new ImageView(beautyImage);
        beautyView.setFitHeight(30);
        beautyView.setFitWidth(30);

        Button beautyButton = new Button();
        beautyButton.setGraphic(new StackPane(beautyView));
        beautyButton.setPrefSize(50, 50);
        beautyButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label beautyLabel = new Label("Beauty");
        beautyLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(beautyLabel, Pos.CENTER_LEFT);
        StackPane.setMargin(beautyLabel, new Insets(3, 0, 0, 53));

        ////Clothes/////
        Image clothesImage = new Image("file:C:\\Users\\ghadi\\Downloads\\clothes.png");
        ImageView clothesView = new ImageView(clothesImage);
        clothesView.setFitHeight(33);
        clothesView.setFitWidth(35);

        Button clothesButton = new Button();
        clothesButton.setGraphic(new StackPane(clothesView));
        clothesButton.setPrefSize(50, 50);
        clothesButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label clothesLabel = new Label("Clothes");
        clothesLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(clothesLabel, Pos.CENTER_LEFT);
        StackPane.setMargin(clothesLabel, new Insets(4, 0, 0, 120));


        /////Bills/////
        Image billsImage = new Image("file:C:\\Users\\ghadi\\Downloads\\bills.png");
        ImageView billsView = new ImageView(billsImage);
        billsView.setFitHeight(30);
        billsView.setFitWidth(30);

        Button billsButton = new Button();
        billsButton.setGraphic(new StackPane(billsView));
        billsButton.setPrefSize(50, 50);
        billsButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label billsLabel = new Label("Bills");
        billsLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(billsLabel, Pos.CENTER);
        StackPane.setMargin(billsLabel, new Insets(4, 0, 0, 70));

        ////Pharmacy////
        Image pharmacyImage = new Image("file:C:\\Users\\ghadi\\Downloads\\pharmacy.png");
        ImageView pharmacyView = new ImageView(pharmacyImage);
        pharmacyView.setFitHeight(30);
        pharmacyView.setFitWidth(30);

        Button pharmacyButton = new Button();
        pharmacyButton.setGraphic(new StackPane(pharmacyView));
        pharmacyButton.setPrefSize(50, 50);
        pharmacyButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label pharmacyLabel = new Label("Pharmacy");
        pharmacyLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(pharmacyLabel, Pos.CENTER);
        StackPane.setMargin(pharmacyLabel, new Insets(4, 0, 0, 220));


        //////Food//////
        Image foodImage = new Image("file:C:\\Users\\ghadi\\Downloads\\food.png");
        ImageView foodView = new ImageView(foodImage);
        foodView.setFitHeight(30);
        foodView.setFitWidth(30);

        Button foodButton = new Button();
        foodButton.setGraphic(new StackPane(foodView));
        foodButton.setPrefSize(50, 50);
        foodButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label foodLabel = new Label("Food");
        foodLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(foodLabel, Pos.CENTER_LEFT);
        StackPane.setMargin(foodLabel, new Insets(145, 0, 0, 57));

        /////////jewlery///////
        Image jewelryImage = new Image("file:C:\\Users\\ghadi\\Downloads\\jewelry.png");
        ImageView jewelryView = new ImageView(jewelryImage);
        jewelryView.setFitHeight(30);
        jewelryView.setFitWidth(30);

        Button jewelryButton = new Button();
        jewelryButton.setGraphic(new StackPane(jewelryView));
        jewelryButton.setPrefSize(50, 50);
        jewelryButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label jewelryLabel = new Label("Jewelry");
        jewelryLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(jewelryLabel, Pos.CENTER_LEFT);
        StackPane.setMargin(jewelryLabel, new Insets(145, 0, 0, 120));

        //////Stationary//////
        Image stationaryImage = new Image("file:C:\\Users\\ghadi\\Downloads\\stationary.png");
        ImageView stationaryView = new ImageView(stationaryImage);
        stationaryView.setFitHeight(30);
        stationaryView.setFitWidth(30);

        Button stationaryButton = new Button();
        stationaryButton.setGraphic(new StackPane(stationaryView));
        stationaryButton.setPrefSize(50, 50);
        stationaryButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label stationaryLabel = new Label("Stationary");
        stationaryLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(stationaryLabel, Pos.CENTER);
        StackPane.setMargin(stationaryLabel, new Insets(145, 0, 0, 70));


        ///////See All ///////
        Image seeAllImage = new Image("file:C:\\Users\\ghadi\\Downloads\\all.png");
        ImageView seeAllView = new ImageView(seeAllImage);
        seeAllView.setFitHeight(30);
        seeAllView.setFitWidth(30);

        Button seeAllButton = new Button();
        seeAllButton.setGraphic(new StackPane(seeAllView));
        seeAllButton.setPrefSize(50, 50);
        seeAllButton.setStyle("-fx-background-color: #cd5ea2; -fx-background-radius: 40;");

        Label seeAllLabel = new Label("See All");
        seeAllLabel.setStyle("-fx-font: normal 12px 'serif'; -fx-text-fill: black; ");
        StackPane.setAlignment(seeAllLabel, Pos.CENTER);
        StackPane.setMargin(seeAllLabel, new Insets(145, 0, 0, 220));



        categoryGrid.add(beautyButton, 0, 0);
        categoryGrid.add(clothesButton, 1, 0);
        categoryGrid.add(billsButton, 2, 0);
        categoryGrid.add(pharmacyButton, 3, 0);
        categoryGrid.add(foodButton, 0, 1);
        categoryGrid.add(jewelryButton, 1, 1);
        categoryGrid.add(stationaryButton, 2, 1);
        categoryGrid.add(seeAllButton, 3, 1);

        ////line2////

        Line line2 = new Line();
        line2.setStartY(totalRectangle.getHeight());
        line2.setEndX(totalRectangle.getWidth());
        line2.setEndY(totalRectangle.getHeight());
        line2.setStroke(Color.web("657da1"));
        line2.setStrokeWidth(2);

        StackPane.setMargin(line2, new Insets(210, 0, 0, 0));

        //// APP ICONS ////



        Image amazonImage = new Image("file:C:\\Users\\ghadi\\Downloads\\amazon.png");
        Image noonImage = new Image("file:C:\\Users\\ghadi\\Downloads\\noon.png");
        Image sheinImage = new Image("file:C:\\Users\\ghadi\\Downloads\\shein.png");
        Image ounassImage = new Image("file:C:\\Users\\ghadi\\Downloads\\ounass.png");
        Image niceoneImage = new Image("file:C:\\Users\\ghadi\\Downloads\\niceone.png");
        Image namshiImage = new Image("file:C:\\Users\\ghadi\\Downloads\\namshi.png");
        Image nahdiImage = new Image("file:C:\\Users\\ghadi\\Downloads\\nahdi.png");
        Image iherbImage = new Image("file:C:\\Users\\ghadi\\Downloads\\iherb.png");


        double imageSize = 90;

        ImageView amazonImageView = new ImageView(amazonImage);
        amazonImageView.setFitHeight(70 * 409 / 610);
        amazonImageView.setPreserveRatio(true);

        ImageView noonImageView = new ImageView(noonImage);
        noonImageView.setFitHeight(36 * 512 / 512);
        noonImageView.setPreserveRatio(true);

        ImageView sheinImageView = new ImageView(sheinImage);

        sheinImageView.setFitHeight(imageSize * 362 / 690);
        sheinImageView.setPreserveRatio(true);

        ImageView ounassImageView = new ImageView(ounassImage);

        ounassImageView.setFitHeight(imageSize * 353 / 707);
        ounassImageView.setPreserveRatio(true);

        ImageView niceoneImageView = new ImageView(niceoneImage);
        niceoneImageView.setFitHeight(imageSize * 362 / 690);
        niceoneImageView.setPreserveRatio(true);

        ImageView namshiImageView = new ImageView(namshiImage);
        namshiImageView.setFitHeight(imageSize * 353 / 707);
        namshiImageView.setPreserveRatio(true);

        ImageView nahdiImageView = new ImageView(nahdiImage);
        nahdiImageView.setFitHeight(imageSize * 362 / 690);
        nahdiImageView.setPreserveRatio(true);

        ImageView iherbImageView = new ImageView(iherbImage);
        iherbImageView.setFitHeight(imageSize * 362 / 690);
        iherbImageView.setPreserveRatio(true);

        GridPane appGrid = new GridPane();
        appGrid.setHgap(.2);
        appGrid.setVgap(.2);
        appGrid.setAlignment(Pos.CENTER);
        appGrid.add(amazonImageView, 0, 0);
        appGrid.add(noonImageView, 1, 0);
        appGrid.add(sheinImageView, 2, 0);
        appGrid.add(ounassImageView, 3, 0);
        appGrid.add(niceoneImageView, 0, 1);
        appGrid.add(namshiImageView, 1, 1);
        appGrid.add(nahdiImageView, 2, 1);
        appGrid.add(iherbImageView, 3, 1);
        StackPane.setAlignment(appGrid, Pos.CENTER);
        StackPane.setMargin(appGrid, new Insets(350, 0, 0, 0));
        //appGrid.setGridLinesVisible(true);

        // translating the images
        amazonImageView.setTranslateX(30);
        noonImageView.setTranslateX(25);
        niceoneImageView.setTranslateX(20);
        // namshiImageView.setTranslateX(-8);
        sheinImageView.setTranslateX(-25);
        nahdiImageView.setTranslateX(-25);
        ounassImageView.setTranslateX(-40);
        iherbImageView.setTranslateX(-40);




        Text shopsText = new Text("Shops");
        shopsText.setStyle("-fx-font: normal bold 16px 'serif'; -fx-fill: black;");
        StackPane.setAlignment(shopsText, Pos.CENTER_LEFT);
        StackPane.setMargin(shopsText, new Insets(245, 0, 0, 30)); //top right bottom left


        center.getChildren().addAll(totalRectangle , line1 , categoryLabel
                , categoryGrid , beautyLabel , clothesLabel , billsLabel
                , pharmacyLabel , foodLabel , jewelryLabel , stationaryLabel , seeAllLabel
                , line2,shopsText,appGrid);
        pane.setCenter(center);


        ////////////////////////////// Bottom //////////////////////////////////////

        StackPane bottom = new StackPane();

        Rectangle rectangleB = new Rectangle();
        rectangleB.setWidth(360);
        rectangleB.setHeight(60);
        rectangleB.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleB, new Insets(35, 0, 0, -20));

        ////home Botton////
        Image imageHome = new Image("file:C:\\Users\\pc\\Downloads\\home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:C:\\Users\\pc\\Downloads\\wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:C:\\Users\\pc\\Downloads\\list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:C:\\Users\\pc\\Downloads\\profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottom.getChildren().addAll(rectangleB, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

        pane.setBottom(bottom);

        Scene homeScene = new Scene(pane,350, 600);     // home page
        pane.setStyle("-fx-background-color: #c4d5de;");
            stage.setScene(homeScene);
            stage.setTitle("Home");
            stage.show();








        ///////wishlist scene/////////////////


        WishlistScene wishlistScene1 = new WishlistScene();

        wishlistButton.setOnAction(event -> {
           wishlistScene1.start(stage);
        });




        wishlistText.setOnMouseClicked(e->{
            wishlistScene1.start(stage);
        });

        /////////LIST SCENE //////////////////////

        VBox listBox = new VBox();
        Scene listScene = new Scene(listBox , 350, 600);
        listBox.setStyle("-fx-background-color: #c4d5de;");

        ListScene listScene1 = new ListScene();
        listButton.setOnAction(event -> {
            listScene1.start(stage);
        });


        listText.setOnMouseClicked(e->{
            listScene1.start(stage);
        });

        //////////PROFILE SCENE //////////////////

        VBox profileBox = new VBox();
        Scene profileScene = new Scene(profileBox , 350, 600);
        profileBox.setStyle("-fx-background-color: #c4d5de;");

        profileView.setOnMouseClicked(e->{

        });

        profileText.setOnMouseClicked(e->{
            stage.setScene(profileScene);
            stage.setTitle("Profile");
        });

        ///////////Beauty scene //////////////////



        beautyButton.setOnAction(event -> {

        });

        beautyView.setOnMouseClicked(e->{

        });

        ///////////clothes scene ///////////////////


        clothesButton.setOnAction(event -> {

        });

        clothesLabel.setOnMouseClicked(e->{

        });

        ////////Bills scene/////////////////////////////


        billsView.setOnMouseClicked(e->{

        });

        billsLabel.setOnMouseClicked(e->{

        });

        ////////Pharmacy scene//////////////////////////



        pharmacyButton.setOnAction(event -> {

        });

        pharmacyLabel.setOnMouseClicked(e->{

        });

        /////////Food scene/////////////////////////////////



        foodButton.setOnAction(event -> {

        });

        foodLabel.setOnMouseClicked(e->{

        });

        /////////jewelry scene////////////////////////////////



        jewelryView.setOnMouseClicked(e->{

        });

        jewelryLabel.setOnMouseClicked(e->{

        });

        ///////////Stationary scene//////////////////////////



        stationaryButton.setOnAction(event -> {

        });

        stationaryLabel.setOnMouseClicked(e->{

        });

        ////////////see all scene //////////////////////



        seeAllButton.setOnAction(event -> {

        });

        seeAllLabel.setOnMouseClicked(e->{

        });

        //// SHOPS SCENES


        amazonImageView.setOnMouseClicked(e-> {
            amazonScene.start(stage);
        });


        noonImageView.setOnMouseClicked(e -> {
            noonScene.start(stage);
        });


        sheinImageView.setOnMouseClicked(e -> {
            sheinScene.start(stage);
        });



        ounassImageView.setOnMouseClicked(e -> {
            ounassScene.start(stage);
        });


        niceoneImageView.setOnMouseClicked(e -> {
            niceOneScene.start(stage);
        });


        namshiImageView.setOnMouseClicked(e -> {
            namshiScene.start(stage);
        });


        nahdiImageView.setOnMouseClicked(e -> {
            nahdiScene.start(stage);
        });


        iherbImageView.setOnMouseClicked(e -> {
            iHerbScene.start(stage);
        });


        
        sidebarTest sidebartest = new sidebarTest();

        list2Img.setOnMouseClicked(e->{
            
            sidebartest.start(stage);


//            stackPaneSideBar.getChildren().addAll(sidebarPane);
            ////////////////

        });

        /////NOTICES/////

        VBox noticeBox = new VBox();
        noticeBox.setStyle("-fx-background-color: #c4d5de;");
        Scene noticeScene = new Scene(noticeBox, 350, 600);
        noticeButton.setOnAction(event -> {
            stage.setScene(noticeScene);
            stage.setTitle("NOTIFICATION");
        });

    }


}

