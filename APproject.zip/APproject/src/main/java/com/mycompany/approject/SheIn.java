/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class SheIn extends Application {



    @Override
    public void start(Stage stage) {
        BorderPane sheinPane = new BorderPane();
        sheinPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topSheinroot = new StackPane();

        Rectangle rectangleTshein = new Rectangle();
        rectangleTshein.setX(500);
        rectangleTshein.setY(80);
        rectangleTshein.setWidth(356);
        rectangleTshein.setHeight(90);
        rectangleTshein.setFill(blueRect);

        ////back//
        Image backshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/backarrow2.png");
        ImageView backImgshein = new ImageView(backshein);//
        backImgshein.setFitHeight(25);
        backImgshein.setFitWidth(25);
        StackPane.setMargin(backImgshein, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImgshein, Pos.CENTER_LEFT);


        Text sheinText = new Text("Shein");
        sheinText.setStyle("-fx-font: normal bold 14px 'serif'");
        sheinText.setFill(Color.WHITE);

        StackPane.setAlignment(sheinText, Pos.CENTER_LEFT);
        StackPane.setMargin(sheinText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTshein, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldshein = new TextField();
        searchFieldshein.setFocusTraversable(false);
        searchFieldshein.setPromptText("Search here ...");
        searchFieldshein.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldshein.setPrefWidth(200);
        searchFieldshein.setPrefHeight(25);
        Rectangle searchFieldShapeshein = new Rectangle();
        searchFieldShapeshein.setWidth(200);
        searchFieldShapeshein.setHeight(25);
        searchFieldShapeshein.setArcWidth(25);
        searchFieldShapeshein.setArcHeight(30);
        searchFieldshein.setShape(searchFieldShapeshein);

        Image searchImageshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/search.png");
        ImageView searchViewshein = new ImageView(searchImageshein);
        searchViewshein.setFitHeight(19);
        searchViewshein.setFitWidth(22);

        StackPane.setMargin(searchViewshein, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainershein = new StackPane();
        searchFieldContainershein.getChildren().addAll(searchFieldshein, searchViewshein);

        HBox searchBoxshein = new HBox(searchFieldContainershein);

        StackPane.setMargin(searchBoxshein, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image notfImageshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/notf.png");
        ImageView notfViewshein = new ImageView(notfImageshein);
        notfViewshein.setFitHeight(20);
        notfViewshein.setFitWidth(15);

        Button noticeButtonshein = new Button();
        noticeButtonshein.setGraphic(new StackPane(notfViewshein));
        noticeButtonshein.setPrefSize(30, 30);
        noticeButtonshein.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonshein, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonshein, Pos.CENTER_RIGHT);

        ////list //////
        Image list1shein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list1.png");
        ImageView list1Imgshein = new ImageView(list1shein);//
        list1Imgshein.setFitHeight(18);
        list1Imgshein.setFitWidth(23);

        StackPane.setMargin(list1Imgshein, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Imgshein, Pos.CENTER_RIGHT);

        topSheinroot.getChildren().addAll(rectangleTshein, sheinText, searchBoxshein,
                noticeButtonshein, list1Imgshein, backImgshein);
        sheinPane.setTop(topSheinroot);

        //---------- center -----------//
        VBox centerBoxshein = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxshein.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendingshein = new StackPane();

        Rectangle rectProduct1shein = new Rectangle(200, 70);
        rectProduct1shein.setFill(PinkRectD);
        rectProduct1shein.setArcWidth(10);
        rectProduct1shein.setArcHeight(10);


        Label spendingLbshein = new Label("Total Spending");
        spendingLbshein.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLbshein.setPadding(new Insets(0, 0, 25, 0));


        centerSpendingshein.setPadding(new Insets(20, 55, 0, 60));
        centerSpendingshein.getChildren().addAll(rectProduct1shein, spendingLbshein);

        //items recnagles
        //first 2
        HBox itemsBoxshein = new HBox(38);

        itemsBoxshein.setPadding(new Insets(30, 0, 0, 35));

        StackPane rectitemsShein1 = new StackPane();
        Rectangle rectProductShein1 = new Rectangle(110, 155);
        rectProductShein1.setFill(PinkRectL);
        rectProductShein1.setArcWidth(10);
        rectProductShein1.setArcHeight(10);

        Rectangle SmallrectProductShein1 = new Rectangle(110, 30);
        SmallrectProductShein1.setFill(PinkRectD);
        SmallrectProductShein1.setArcWidth(10);
        SmallrectProductShein1.setArcHeight(10);
        SmallrectProductShein1.setTranslateY(62);

        Image shein1 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein1.png");
        ImageView sheinImg1 = new ImageView(shein1);//
        sheinImg1.setFitHeight(90);
        sheinImg1.setFitWidth(80);
        sheinImg1.setTranslateY(-31);

        Label shein1Lb = new Label("   Steel Cutter \n    8.00SR");
        shein1Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein1Lb.setPadding(new Insets(90, 40, 30, 0));

        Image listimg1shein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list.png");
        ImageView listbtn1view1shein = new ImageView(listimg1shein);//
        listbtn1view1shein.setFitHeight(68);
        listbtn1view1shein.setFitWidth(68);

        Button listButton1shein = new Button();
        listButton1shein.setGraphic(new StackPane(listbtn1view1shein));
        listButton1shein.setPrefSize(35, 35);
        listButton1shein.setTranslateY(65);
        listButton1shein.setTranslateX(20);
        listButton1shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Image wishlistimg1shein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/wishlist.png");
        ImageView wishlistView1shein = new ImageView(wishlistimg1shein);
        wishlistView1shein.setFitHeight(50);
        wishlistView1shein.setFitWidth(50);

        Button wishlistButton1shein = new Button();
        wishlistButton1shein.setGraphic(new StackPane(wishlistView1shein));
        wishlistButton1shein.setPrefSize(35, 35);
        wishlistButton1shein.setTranslateY(61);
        wishlistButton1shein.setTranslateX(-20);
        wishlistButton1shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsShein1.getChildren().addAll(rectProductShein1, SmallrectProductShein1,
                sheinImg1, shein1Lb, listButton1shein, wishlistButton1shein);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsShein2 = new StackPane();
        Rectangle rectProductShein2 = new Rectangle(110, 155);
        rectProductShein2.setFill(PinkRectL);
        rectProductShein2.setArcWidth(10);
        rectProductShein2.setArcHeight(10);

        Rectangle SmallrectProductShein2 = new Rectangle(110, 30);
        SmallrectProductShein2.setFill(PinkRectD);
        SmallrectProductShein2.setArcWidth(10);
        SmallrectProductShein2.setArcHeight(10);
        SmallrectProductShein2.setTranslateY(62);

        Image shein2 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein2.png");
        ImageView sheinImg2 = new ImageView(shein2);//
        sheinImg2.setFitHeight(100);
        sheinImg2.setFitWidth(100);
        sheinImg2.setTranslateY(-28);

        Label shein2Lb = new Label("Keyboard Protector\n4.80SR");
        shein2Lb.setStyle("-fx-font: normal  11px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein2Lb.setPadding(new Insets(0, 5, 30, 0));
        shein2Lb.setTranslateY(45);

        ImageView listbtn1view2shein = new ImageView(listimg1shein);//
        listbtn1view2shein.setFitHeight(68);
        listbtn1view2shein.setFitWidth(68);

        ImageView wishlistView2shein = new ImageView(wishlistimg1shein);
        wishlistView2shein.setFitHeight(50);
        wishlistView2shein.setFitWidth(50);

        Button listButton2shein = new Button();
        listButton2shein.setGraphic(new StackPane(listbtn1view2shein));
        listButton2shein.setPrefSize(35, 35);
        listButton2shein.setTranslateY(65);
        listButton2shein.setTranslateX(20);
        listButton2shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton2shein = new Button();
        wishlistButton2shein.setGraphic(new StackPane(wishlistView2shein));
        wishlistButton2shein.setPrefSize(35, 35);
        wishlistButton2shein.setTranslateY(61);
        wishlistButton2shein.setTranslateX(-20);
        wishlistButton2shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsShein2.getChildren().addAll(rectProductShein2, SmallrectProductShein2,
                sheinImg2, shein2Lb , wishlistButton2shein, listButton2shein);

        itemsBoxshein.getChildren().addAll(rectitemsShein1, rectitemsShein2);

        // second 2
        HBox itemsBox2shein = new HBox(40);

        itemsBox2shein.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsShein3 = new StackPane();
        Rectangle rectProductShein3 = new Rectangle(110, 155);
        rectProductShein3.setFill(PinkRectL);
        rectProductShein3.setArcWidth(10);
        rectProductShein3.setArcHeight(10);

        Rectangle SmallrectProductShein3 = new Rectangle(110, 30);
        SmallrectProductShein3.setFill(PinkRectD);
        SmallrectProductShein3.setArcWidth(10);
        SmallrectProductShein3.setArcHeight(10);
        SmallrectProductShein3.setTranslateY(62);

        Image shein3 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein3.png");
        ImageView sheinImg3 = new ImageView(shein3);//
        sheinImg3.setFitHeight(90);
        sheinImg3.setFitWidth(75);
        sheinImg3.setTranslateY(-28);

        Label shein3Lb = new Label("24pcs Marker Pen  \n14.96SR");
        shein3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein3Lb.setPadding(new Insets(0, 10, 30, 0));
        shein3Lb.setTranslateY(45);

        ImageView listbtn1view3shein = new ImageView(listimg1shein);//
        listbtn1view3shein.setFitHeight(68);
        listbtn1view3shein.setFitWidth(68);

        ImageView wishlistView3shein = new ImageView(wishlistimg1shein);
        wishlistView3shein.setFitHeight(50);
        wishlistView3shein.setFitWidth(50);

        Button listButton3shein = new Button();
        listButton3shein.setGraphic(new StackPane(listbtn1view3shein));
        listButton3shein.setPrefSize(35, 35);
        listButton3shein.setTranslateY(65);
        listButton3shein.setTranslateX(20);
        listButton3shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton3shein = new Button();
        wishlistButton3shein.setGraphic(new StackPane(wishlistView3shein));
        wishlistButton3shein.setPrefSize(35, 35);
        wishlistButton3shein.setTranslateY(61);
        wishlistButton3shein.setTranslateX(-20);
        wishlistButton3shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsShein3.getChildren().addAll(rectProductShein3, SmallrectProductShein3,
                sheinImg3, shein3Lb , wishlistButton3shein, listButton3shein);

        //////////////////////////////////////////////////
        StackPane rectitemsShein4 = new StackPane();
        Rectangle rectProductShein4 = new Rectangle(110, 155);
        rectProductShein4.setFill(PinkRectL);
        rectProductShein4.setArcWidth(10);
        rectProductShein4.setArcHeight(10);

        Rectangle SmallrectProductShein4 = new Rectangle(110, 30);
        SmallrectProductShein4.setFill(PinkRectD);
        SmallrectProductShein4.setArcWidth(10);
        SmallrectProductShein4.setArcHeight(10);
        SmallrectProductShein4.setTranslateY(62);

        Image shein4 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein4.png");
        ImageView sheinImg4 = new ImageView(shein4);//
        sheinImg4.setFitHeight(85);
        sheinImg4.setFitWidth(70);
        sheinImg4.setTranslateY(-30);

        Label shein4Lb = new Label("iPhone Cover    \n5.60SR");
        shein4Lb.setStyle("-fx-font: normal  11px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein4Lb.setPadding(new Insets(66, 20, 9, 0));


        ImageView listbtn1view4shein = new ImageView(listimg1shein);//
        listbtn1view4shein.setFitHeight(68);
        listbtn1view4shein.setFitWidth(68);

        ImageView wishlistView4shein = new ImageView(wishlistimg1shein);
        wishlistView4shein.setFitHeight(50);
        wishlistView4shein.setFitWidth(50);

        Button listButton4shein = new Button();
        listButton4shein.setGraphic(new StackPane(listbtn1view4shein));
        listButton4shein.setPrefSize(35, 35);
        listButton4shein.setTranslateY(65);
        listButton4shein.setTranslateX(20);
        listButton4shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton4shein = new Button();
        wishlistButton4shein.setGraphic(new StackPane(wishlistView4shein));
        wishlistButton4shein.setPrefSize(35, 35);
        wishlistButton4shein.setTranslateY(61);
        wishlistButton4shein.setTranslateX(-20);
        wishlistButton4shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein4.getChildren().addAll(rectProductShein4, SmallrectProductShein4,
                sheinImg4, shein4Lb, wishlistButton4shein, listButton4shein);

        itemsBox2shein.getChildren().addAll(rectitemsShein3, rectitemsShein4);

        // third 2 /////////////////
        HBox itemsBox3shein = new HBox(40);

        itemsBox3shein.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsShein5 = new StackPane();
        Rectangle rectProductShein5 = new Rectangle(110, 155);
        rectProductShein5.setFill(PinkRectL);
        rectProductShein5.setArcWidth(10);
        rectProductShein5.setArcHeight(10);

        Rectangle SmallrectProductShein5 = new Rectangle(110, 30);
        SmallrectProductShein5.setFill(PinkRectD);
        SmallrectProductShein5.setArcWidth(10);
        SmallrectProductShein5.setArcHeight(10);
        SmallrectProductShein5.setTranslateY(62);

        Image shein5 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein5.png");
        ImageView shein5Img5 = new ImageView(shein5);//
        shein5Img5.setFitHeight(70);
        shein5Img5.setFitWidth(60);
        shein5Img5.setTranslateY(-36);

        Label shein5Lb = new Label("Disposable Mini \nPlastic Cups 20.16SR");
        shein5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein5Lb.setPadding(new Insets(0, 5, 13, 0));
        shein5Lb.setTranslateY(34);


        ImageView listbtn1view5shein = new ImageView(listimg1shein);//
        listbtn1view5shein.setFitHeight(68);
        listbtn1view5shein.setFitWidth(68);

        ImageView wishlistView5shein = new ImageView(wishlistimg1shein);
        wishlistView5shein.setFitHeight(50);
        wishlistView5shein.setFitWidth(50);

        Button listButton5shein = new Button();
        listButton5shein.setGraphic(new StackPane(listbtn1view5shein));
        listButton5shein.setPrefSize(35, 35);
        listButton5shein.setTranslateY(65);
        listButton5shein.setTranslateX(20);
        listButton5shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton5shein = new Button();
        wishlistButton5shein.setGraphic(new StackPane(wishlistView5shein));
        wishlistButton5shein.setPrefSize(35, 35);
        wishlistButton5shein.setTranslateY(61);
        wishlistButton5shein.setTranslateX(-20);
        wishlistButton5shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein5.getChildren().addAll(rectProductShein5, SmallrectProductShein5,
                shein5Img5, shein5Lb, wishlistButton5shein, listButton5shein);
        //////////////////////////////////////////////
        StackPane rectitemsShein6 = new StackPane();
        Rectangle rectProductShein6 = new Rectangle(110, 155);
        rectProductShein6.setFill(PinkRectL);
        rectProductShein6.setArcWidth(10);
        rectProductShein6.setArcHeight(10);

        Rectangle SmallrectProductShein6 = new Rectangle(110, 30);
        SmallrectProductShein6.setFill(PinkRectD);
        SmallrectProductShein6.setArcWidth(10);
        SmallrectProductShein6.setArcHeight(10);
        SmallrectProductShein6.setTranslateY(62);

        Image shein6 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein6.png");
        ImageView sheinImg6 = new ImageView(shein6);//
        sheinImg6.setFitHeight(90);
        sheinImg6.setFitWidth(55);
        sheinImg6.setTranslateY(-35);

        Label shein6Lb = new Label("Silicone Hair Scalp \nBrush 6.00SR");
        shein6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein6Lb.setPadding(new Insets(0, 12, 16, 0));
        shein6Lb.setTranslateY(35);

        ImageView listbtn1view6shein = new ImageView(listimg1shein);//
        listbtn1view6shein.setFitHeight(68);
        listbtn1view6shein.setFitWidth(68);

        ImageView wishlistView6shein = new ImageView(wishlistimg1shein);
        wishlistView6shein.setFitHeight(50);
        wishlistView6shein.setFitWidth(50);

        Button listButton6shein = new Button();
        listButton6shein.setGraphic(new StackPane(listbtn1view6shein));
        listButton6shein.setPrefSize(35, 35);
        listButton6shein.setTranslateY(65);
        listButton6shein.setTranslateX(20);
        listButton6shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton6shein = new Button();
        wishlistButton6shein.setGraphic(new StackPane(wishlistView6shein));
        wishlistButton6shein.setPrefSize(35, 35);
        wishlistButton6shein.setTranslateY(61);
        wishlistButton6shein.setTranslateX(-20);
        wishlistButton6shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein6.getChildren().addAll(rectProductShein6, SmallrectProductShein6,
                sheinImg6, shein6Lb , wishlistButton6shein, listButton6shein);

        itemsBox3shein.getChildren().addAll(rectitemsShein5, rectitemsShein6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4shein = new HBox(40);

        itemsBox4shein.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsShein7 = new StackPane();
        Rectangle rectProductShein7 = new Rectangle(110, 155);
        rectProductShein7.setFill(PinkRectL);
        rectProductShein7.setArcWidth(10);
        rectProductShein7.setArcHeight(10);

        Rectangle SmallrectProductShein7 = new Rectangle(110, 30);
        SmallrectProductShein7.setFill(PinkRectD);
        SmallrectProductShein7.setArcWidth(10);
        SmallrectProductShein7.setArcHeight(10);
        SmallrectProductShein7.setTranslateY(62);

        Image shein7 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein7.png");
        ImageView sheinImg7 = new ImageView(shein7);//
        sheinImg7.setFitHeight(100);
        sheinImg7.setFitWidth(95);
        sheinImg7.setTranslateY(-25);

        Label shein7Lb = new Label("Makeup Organizer \nWith Drawers 24.96SR");
        shein7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein7Lb.setPadding(new Insets(0, 0, 25, 0));
        shein7Lb.setTranslateY(40);

        ImageView listbtn1view7shein = new ImageView(listimg1shein);//
        listbtn1view7shein.setFitHeight(68);
        listbtn1view7shein.setFitWidth(68);

        ImageView wishlistView7shein = new ImageView(wishlistimg1shein);
        wishlistView7shein.setFitHeight(50);
        wishlistView7shein.setFitWidth(50);

        Button listButton7shein = new Button();
        listButton7shein.setGraphic(new StackPane(listbtn1view7shein));
        listButton7shein.setPrefSize(35, 35);
        listButton7shein.setTranslateY(65);
        listButton7shein.setTranslateX(20);
        listButton7shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton7shein = new Button();
        wishlistButton7shein.setGraphic(new StackPane(wishlistView7shein));
        wishlistButton7shein.setPrefSize(35, 35);
        wishlistButton7shein.setTranslateY(61);
        wishlistButton7shein.setTranslateX(-20);
        wishlistButton7shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein7.getChildren().addAll(rectProductShein7, SmallrectProductShein7,
                sheinImg7, shein7Lb, wishlistButton7shein, listButton7shein);
        ///////////////////////////////////////////////
        StackPane rectitemsShein8 = new StackPane();
        Rectangle rectProductShein8 = new Rectangle(110, 155);
        rectProductShein8.setFill(PinkRectL);
        rectProductShein8.setArcWidth(10);
        rectProductShein8.setArcHeight(10);

        Rectangle SmallrectProductShein8 = new Rectangle(110, 30);
        SmallrectProductShein8.setFill(PinkRectD);
        SmallrectProductShein8.setArcWidth(10);
        SmallrectProductShein8.setArcHeight(10);
        SmallrectProductShein8.setTranslateY(62);

        Image shein8 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein8.png");
        ImageView sheinImg8 = new ImageView(shein8);//
        sheinImg8.setFitHeight(115);
        sheinImg8.setFitWidth(95);
        sheinImg8.setTranslateY(-34);

        Label shein8Lb = new Label("30pcs Shoe Charms   \n25.60SR");
        shein8Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein8Lb.setPadding(new Insets(0, 0, 20, 0));
        shein8Lb.setTranslateY(38);

        ImageView listbtn1view8shein = new ImageView(listimg1shein);//
        listbtn1view8shein.setFitHeight(68);
        listbtn1view8shein.setFitWidth(68);

        ImageView wishlistView8shein = new ImageView(wishlistimg1shein);
        wishlistView8shein.setFitHeight(50);
        wishlistView8shein.setFitWidth(50);

        Button listButton8shein = new Button();
        listButton8shein.setGraphic(new StackPane(listbtn1view8shein));
        listButton8shein.setPrefSize(35, 35);
        listButton8shein.setTranslateY(65);
        listButton8shein.setTranslateX(20);
        listButton8shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton8shein = new Button();
        wishlistButton8shein.setGraphic(new StackPane(wishlistView8shein));
        wishlistButton8shein.setPrefSize(35, 35);
        wishlistButton8shein.setTranslateY(61);
        wishlistButton8shein.setTranslateX(-20);
        wishlistButton8shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein8.getChildren().addAll(rectProductShein8 , SmallrectProductShein8
                , sheinImg8, shein8Lb , wishlistButton8shein, listButton8shein);

        itemsBox4shein.getChildren().addAll(rectitemsShein7, rectitemsShein8 );

        // fifth 2/////////////////////////////
        HBox itemsBox5shein = new HBox(40);

        itemsBox5shein.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsShein9 = new StackPane();
        Rectangle rectProductShein9 = new Rectangle(110, 155);
        rectProductShein9.setFill(PinkRectL);
        rectProductShein9.setArcWidth(10);
        rectProductShein9.setArcHeight(10);

        Rectangle SmallrectProductShein9 = new Rectangle(110, 30);
        SmallrectProductShein9.setFill(PinkRectD);
        SmallrectProductShein9.setArcWidth(10);
        SmallrectProductShein9.setArcHeight(10);
        SmallrectProductShein9.setTranslateY(62);

        Image shein9 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein9.png");
        ImageView sheinImg9 = new ImageView(shein9);//
        sheinImg9.setFitHeight(80);
        sheinImg9.setFitWidth(70);
        sheinImg9.setTranslateY(-30);

        Label shein9Lb = new Label("Unhappy Cat Mug \n31.68SR");
        shein9Lb.setStyle("-fx-font: normal 11px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein9Lb.setPadding(new Insets(0, 5, 25, 0));
        shein9Lb.setTranslateY(40);

        ImageView listbtn1view9shein = new ImageView(listimg1shein);//
        listbtn1view9shein.setFitHeight(68);
        listbtn1view9shein.setFitWidth(68);

        ImageView wishlistView9shein = new ImageView(wishlistimg1shein);
        wishlistView9shein.setFitHeight(50);
        wishlistView9shein.setFitWidth(50);

        Button listButton9shein = new Button();
        listButton9shein.setGraphic(new StackPane(listbtn1view9shein));
        listButton9shein.setPrefSize(35, 35);
        listButton9shein.setTranslateY(65);
        listButton9shein.setTranslateX(20);
        listButton9shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton9shein = new Button();
        wishlistButton9shein.setGraphic(new StackPane(wishlistView9shein));
        wishlistButton9shein.setPrefSize(35, 35);
        wishlistButton9shein.setTranslateY(61);
        wishlistButton9shein.setTranslateX(-20);
        wishlistButton9shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein9.getChildren().addAll(rectProductShein9, SmallrectProductShein9,
                sheinImg9, shein9Lb , wishlistButton9shein, listButton9shein);
/////////////////////////////////////////////////////////
        StackPane rectitemsShein10 = new StackPane();
        Rectangle rectProductShein10 = new Rectangle(110, 155);
        rectProductShein10.setFill(PinkRectL);
        rectProductShein10.setArcWidth(10);
        rectProductShein10.setArcHeight(10);

        Rectangle SmallrectProductShein10 = new Rectangle(110, 30);
        SmallrectProductShein10.setFill(PinkRectD);
        SmallrectProductShein10.setArcWidth(10);
        SmallrectProductShein10.setArcHeight(10);
        SmallrectProductShein10.setTranslateY(62);

        Image shein10 = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/shein10.png");
        ImageView sheinImg10 = new ImageView(shein10);
        sheinImg10.setFitHeight(85);
        sheinImg10.setFitWidth(75);
        sheinImg10.setTranslateY(-30);

        Label shein10Lb = new Label("Perfume Refillable \nMini Bottles 4.80SR");
        shein10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        shein10Lb.setPadding(new Insets(0, 5, 21, 0));
        shein10Lb.setTranslateY(38);

        ImageView listbtn1view10shein = new ImageView(listimg1shein);//
        listbtn1view10shein.setFitHeight(68);
        listbtn1view10shein.setFitWidth(68);

        ImageView wishlistView10shein = new ImageView(wishlistimg1shein);
        wishlistView10shein.setFitHeight(50);
        wishlistView10shein.setFitWidth(50);

        Button listButton10shein = new Button();
        listButton10shein.setGraphic(new StackPane(listbtn1view10shein));
        listButton10shein.setPrefSize(35, 35);
        listButton10shein.setTranslateY(65);
        listButton10shein.setTranslateX(20);
        listButton10shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        Button wishlistButton10shein = new Button();
        wishlistButton10shein.setGraphic(new StackPane(wishlistView10shein));
        wishlistButton10shein.setPrefSize(35, 35);
        wishlistButton10shein.setTranslateY(61);
        wishlistButton10shein.setTranslateX(-20);
        wishlistButton10shein.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsShein10.getChildren().addAll(rectProductShein10, SmallrectProductShein10
                , sheinImg10, shein10Lb , wishlistButton10shein, listButton10shein);

        itemsBox5shein.getChildren().addAll(rectitemsShein9, rectitemsShein10);

        centerBoxshein.getChildren().addAll(centerSpendingshein, itemsBoxshein, itemsBox2shein,
                itemsBox3shein, itemsBox4shein, itemsBox5shein);


        ScrollPane scrollPaneshein = new ScrollPane(centerBoxshein);
        scrollPaneshein.setFitToWidth(true);
        scrollPaneshein.setFitToHeight(true);

        // bottom
        StackPane bottomSheinroot = new StackPane();

        Rectangle rectangleBshein = new Rectangle();
        rectangleBshein.setWidth(360);
        rectangleBshein.setHeight(60);
        rectangleBshein.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBshein, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHomeshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/home.png");

        ImageView homeViewshein = new ImageView(imageHomeshein);
        homeViewshein.setFitHeight(50);
        homeViewshein.setFitWidth(60);

        Button homeButtonshein = new Button();
        homeButtonshein.setGraphic(new StackPane(homeViewshein));
        homeButtonshein.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButtonshein, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButtonshein, new Insets(10, 0, 0, 30));

        Text textHomeshein = new Text("Home");
        textHomeshein.setStyle("-fx-font: normal bold 10px 'serif'");
        textHomeshein.setFill(Color.WHITE);

        StackPane.setAlignment(textHomeshein, Pos.CENTER_LEFT);
        StackPane.setMargin(textHomeshein, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImageshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/wishlist.png");
        ImageView wishlistViewshein = new ImageView(wishlistImageshein);
        wishlistViewshein.setFitHeight(50); //setting the fit height and width of the image view
        wishlistViewshein.setFitWidth(70);

        Button wishlistButtonshein = new Button();
        wishlistButtonshein.setGraphic(new StackPane(wishlistViewshein));
        wishlistButtonshein.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButtonshein, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButtonshein, new Insets(10, 0, 0, 91));

        Text wishlistTextshein = new Text("Wishlist");
        wishlistTextshein.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistTextshein.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistTextshein, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistTextshein, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImageshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/list.png");
        ImageView listViewshein = new ImageView(listImageshein);
        listViewshein.setFitHeight(70); //setting the fit height and width of the image view
        listViewshein.setFitWidth(80);

        Button listButtonshein = new Button();
        listButtonshein.setGraphic(new StackPane(listViewshein));
        listButtonshein.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButtonshein, Pos.CENTER);
        StackPane.setMargin(listButtonshein, new Insets(15, 0, 0, 60));

        Text listTextshein = new Text("List");
        listTextshein.setStyle("-fx-font: normal bold 10px 'serif'");
        listTextshein.setFill(Color.WHITE);

        StackPane.setAlignment(listTextshein, Pos.CENTER);
        StackPane.setMargin(listTextshein, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImageshein = new Image("file:/Users/raghadalsebayyil/Desktop/AP_Project/AP_Project_Img/profile.png");
        ImageView profileViewshein = new ImageView(profileImageshein);
        profileViewshein.setFitHeight(70); //setting the fit height and width of the image view
        profileViewshein.setFitWidth(100);

        Button profileButtonshein = new Button();
        profileButtonshein.setGraphic(new StackPane(profileViewshein));
        profileButtonshein.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButtonshein, Pos.CENTER);
        StackPane.setMargin(profileButtonshein, new Insets(0, 0, 0, 210));

        Text profileTextshein = new Text("Profile");
        profileTextshein.setStyle("-fx-font: normal bold 10px 'serif'");
        profileTextshein.setFill(Color.WHITE);

        StackPane.setAlignment(profileTextshein, Pos.CENTER);
        StackPane.setMargin(profileTextshein, new Insets(50, 0, 0, 200));



        bottomSheinroot.getChildren().addAll(rectangleBshein, homeButtonshein, textHomeshein
                , wishlistButtonshein, wishlistTextshein, listButtonshein, listTextshein, profileButtonshein, profileTextshein);


        sheinPane.setTop(topSheinroot);
        sheinPane.setCenter(scrollPaneshein);
        sheinPane.setBottom(bottomSheinroot);

        Scene sceneshein = new Scene(sheinPane, 350, 600);
        stage.setScene(sceneshein); // Place the scene in the stage
        stage.show(); //

        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
        //ProfileScene profileScene = new ProfileScene();

//-------------------------------- ACTION ----------------------------------------------//

        backImgshein.setOnMouseClicked(e -> {
            homePageScene.start(stage);
        });


        homeButtonshein.setOnAction(e -> {
            homePageScene.start(stage);
        });

        wishlistButtonshein.setOnAction(e -> {
            wishlistScene.start(stage);
        });

        listButtonshein.setOnAction(e -> {
            listScene.start(stage);
        });

//        profileButtonshein.setOnAction(e -> {
//            profileScene.start(new Stage());
//        });

    }


 

}
