/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class Ounass extends Application {



    @Override
    public void start(Stage primaryStage) {
        BorderPane ounassPane = new BorderPane();
        ounassPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topOunassroot = new StackPane();

        Rectangle rectangleTounass = new Rectangle();
        rectangleTounass.setX(500);
        rectangleTounass.setY(80);
        rectangleTounass.setWidth(356);
        rectangleTounass.setHeight(90);
        rectangleTounass.setFill(blueRect);
        
        ////back//
        Image back = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);
       

        Text ounassText = new Text("Ounass");
        ounassText.setStyle("-fx-font: normal bold 14px 'serif'");
        ounassText.setFill(Color.WHITE);

        StackPane.setAlignment(ounassText, Pos.CENTER_LEFT);
        StackPane.setMargin(ounassText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTounass, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldounass = new TextField();
        searchFieldounass.setFocusTraversable(false);
        searchFieldounass.setPromptText("Search here ...");
        searchFieldounass.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldounass.setPrefWidth(200);
        searchFieldounass.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchFieldounass.setShape(searchFieldShape);

        Image searchImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\search.jpg");
        ImageView searchViewounass = new ImageView(searchImage);
        searchViewounass.setFitHeight(19);
        searchViewounass.setFitWidth(22);

        StackPane.setMargin(searchViewounass, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainerounass = new StackPane();
        searchFieldContainerounass.getChildren().addAll(searchFieldounass, searchViewounass);

        HBox searchBoxounass = new HBox(searchFieldContainerounass);

        StackPane.setMargin(searchBoxounass, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\notices.png");
        ImageView noticeView = new ImageView(noticeImage);
        noticeView.setFitHeight(20);
        noticeView.setFitWidth(15);

        Button noticeButtonounass = new Button();
        noticeButtonounass.setGraphic(new StackPane(noticeView));
        noticeButtonounass.setPrefSize(30, 30);
        noticeButtonounass.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonounass, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonounass, Pos.CENTER_RIGHT);

        ////list //////
        Image list1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list1.png");
        ImageView list1Img = new ImageView(list1);//
        list1Img.setFitHeight(18);
        list1Img.setFitWidth(23);

        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topOunassroot.getChildren().addAll(rectangleTounass, ounassText, searchBoxounass,
                 noticeButtonounass, list1Img ,backImg);
        ounassPane.setTop(topOunassroot);

        //---------- center -----------//
        VBox centerBoxounass = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxounass.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendingounass = new StackPane();

        Rectangle rectProduct1ounass = new Rectangle(200, 70);
        rectProduct1ounass.setFill(PinkRectD);
        rectProduct1ounass.setArcWidth(10);
        rectProduct1ounass.setArcHeight(10);
 

        Label spendingLbounass = new Label("Total Spending\n\t138,265");
        spendingLbounass.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLbounass.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpendingounass.setPadding(new Insets(20, 55, 0, 60));
        centerSpendingounass.getChildren().addAll(rectProduct1ounass, spendingLbounass);

        //items recnagles 
        //first 2
        HBox itemsBoxounass = new HBox(40);

        itemsBoxounass.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsOunass1 = new StackPane();
        Rectangle rectProductOunass1 = new Rectangle(110, 155);
        rectProductOunass1.setFill(PinkRectL);
        rectProductOunass1.setArcWidth(10);
        rectProductOunass1.setArcHeight(10);

        Rectangle SmallrectProductOunass1 = new Rectangle(110, 30);
        SmallrectProductOunass1.setFill(PinkRectD);
        SmallrectProductOunass1.setArcWidth(10);
        SmallrectProductOunass1.setArcHeight(10);
        SmallrectProductOunass1.setTranslateY(62);

        Image ounass1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Prada_bag.PNG");
        ImageView ounassImg1 = new ImageView(ounass1);//
        ounassImg1.setFitHeight(120);
        ounassImg1.setFitWidth(120);
        ounassImg1.setTranslateY(-31);

        Label ounass1Lb = new Label("Prada bag \n11,100SR");
        ounass1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass1Lb.setPadding(new Insets(0, 50, 30, 0));
        ounass1Lb.setTranslateY(45);

        Image listimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listbtn1view1 = new ImageView(listimg1);//
        listbtn1view1.setFitHeight(68);
        listbtn1view1.setFitWidth(68);

        Button listButton1ounass = new Button();
        listButton1ounass.setGraphic(new StackPane(listbtn1view1));
        listButton1ounass.setPrefSize(35, 35);
        listButton1ounass.setTranslateY(65);
        listButton1ounass.setTranslateX(20);
        listButton1ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlistimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView1 = new ImageView(wishlistimg1);
        wishlistView1.setFitHeight(50);
        wishlistView1.setFitWidth(50);
        
        Button wishlistButton1 = new Button();
        wishlistButton1.setGraphic(new StackPane(wishlistView1));
        wishlistButton1.setPrefSize(35, 35);
        wishlistButton1.setTranslateY(61);
        wishlistButton1.setTranslateX(-20);
        wishlistButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsOunass1.getChildren().addAll(rectProductOunass1, SmallrectProductOunass1,
                 ounassImg1, ounass1Lb, listButton1ounass , wishlistButton1);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsOunass2 = new StackPane();
        Rectangle rectProductOunass2 = new Rectangle(110, 155);
        rectProductOunass2.setFill(PinkRectL);
        rectProductOunass2.setArcWidth(10);
        rectProductOunass2.setArcHeight(10);

        Rectangle SmallrectProductOunass2 = new Rectangle(110, 30);
        SmallrectProductOunass2.setFill(PinkRectD);
        SmallrectProductOunass2.setArcWidth(10);
        SmallrectProductOunass2.setArcHeight(10);
        SmallrectProductOunass2.setTranslateY(62);

        Image ounass2 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (30).PNG");
        ImageView ounassImg2 = new ImageView(ounass2);//
        ounassImg2.setFitHeight(90);
        ounassImg2.setFitWidth(100);
        ounassImg2.setTranslateY(-28);

        Label ounass2Lb = new Label("White heels\n5,650SR");
        ounass2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass2Lb.setPadding(new Insets(0, 0, 30, 0));
        ounass2Lb.setTranslateY(45);
        
        ImageView listbtn1view2 = new ImageView(listimg1);//
        listbtn1view2.setFitHeight(68);
        listbtn1view2.setFitWidth(68);
        
        ImageView wishlistView2 = new ImageView(wishlistimg1);
        wishlistView2.setFitHeight(50);
        wishlistView2.setFitWidth(50);
        
        Button listButton2ounass = new Button();
        listButton2ounass.setGraphic(new StackPane(listbtn1view2));
        listButton2ounass.setPrefSize(35, 35);
        listButton2ounass.setTranslateY(65);
        listButton2ounass.setTranslateX(20);
        listButton2ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton2ounass = new Button();
        wishlistButton2ounass.setGraphic(new StackPane(wishlistView2));
        wishlistButton2ounass.setPrefSize(35, 35);
        wishlistButton2ounass.setTranslateY(61);
        wishlistButton2ounass.setTranslateX(-20);
        wishlistButton2ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsOunass2.getChildren().addAll(rectProductOunass2, SmallrectProductOunass2,
                 ounassImg2, ounass2Lb ,  wishlistButton2ounass ,listButton2ounass);

        itemsBoxounass.getChildren().addAll(rectitemsOunass1, rectitemsOunass2);

        // second 2
        HBox itemsBox2ounass = new HBox(40);

        itemsBox2ounass.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsOunass3 = new StackPane();
        Rectangle rectProductOunass3 = new Rectangle(110, 155);
        rectProductOunass3.setFill(PinkRectL);
        rectProductOunass3.setArcWidth(10);
        rectProductOunass3.setArcHeight(10);

        Rectangle SmallrectProductOunass3 = new Rectangle(110, 30);
        SmallrectProductOunass3.setFill(PinkRectD);
        SmallrectProductOunass3.setArcWidth(10);
        SmallrectProductOunass3.setArcHeight(10);
        SmallrectProductOunass3.setTranslateY(62);

        Image ounass3 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (24).PNG");
        ImageView ounassImg3 = new ImageView(ounass3);//
        ounassImg3.setFitHeight(90);
        ounassImg3.setFitWidth(75);
        ounassImg3.setTranslateY(-38);

        Label ounass3Lb = new Label(" Boucheron\n52,000SR");
        ounass3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass3Lb.setPadding(new Insets(0, 0, 30, 0));
        ounass3Lb.setTranslateY(34);
        
        ImageView listbtn1view3ounass = new ImageView(listimg1);//
        listbtn1view3ounass.setFitHeight(68);
        listbtn1view3ounass.setFitWidth(68);
        
        ImageView wishlistView3ounass = new ImageView(wishlistimg1);
        wishlistView3ounass.setFitHeight(50);
        wishlistView3ounass.setFitWidth(50);
        
        Button listButton3ounass = new Button();
        listButton3ounass.setGraphic(new StackPane(listbtn1view3ounass));
        listButton3ounass.setPrefSize(35, 35);
        listButton3ounass.setTranslateY(65);
        listButton3ounass.setTranslateX(20);
        listButton3ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton3ounass = new Button();
        wishlistButton3ounass.setGraphic(new StackPane(wishlistView3ounass));
        wishlistButton3ounass.setPrefSize(35, 35);
        wishlistButton3ounass.setTranslateY(61);
        wishlistButton3ounass.setTranslateX(-20);
        wishlistButton3ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsOunass3.getChildren().addAll(rectProductOunass3, SmallrectProductOunass3,
                 ounassImg3, ounass3Lb , wishlistButton3ounass , listButton3ounass);
        
        //////////////////////////////////////////////////
        StackPane rectitemsOunass4 = new StackPane();
        Rectangle rectProductOunass4 = new Rectangle(110, 155);
        rectProductOunass4.setFill(PinkRectL);
        rectProductOunass4.setArcWidth(10);
        rectProductOunass4.setArcHeight(10);

        Rectangle SmallrectProductOunass4 = new Rectangle(110, 30);
        SmallrectProductOunass4.setFill(PinkRectD);
        SmallrectProductOunass4.setArcWidth(10);
        SmallrectProductOunass4.setArcHeight(10);
        SmallrectProductOunass4.setTranslateY(62);

        Image ounass4 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (23).PNG");
        ImageView ounassImg4 = new ImageView(ounass4);//
        ounassImg4.setFitHeight(70);
        ounassImg4.setFitWidth(60);
        ounassImg4.setTranslateY(-35);

        Label ounass4Lb = new Label("White Long\nDress\n8,750SR");
        ounass4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass4Lb.setTranslateY(20);
        
        ImageView listbtn1view4ounass = new ImageView(listimg1);//
        listbtn1view4ounass.setFitHeight(68);
        listbtn1view4ounass.setFitWidth(68);
        
        ImageView wishlistView4Ounass = new ImageView(wishlistimg1);
        wishlistView4Ounass.setFitHeight(50);
        wishlistView4Ounass.setFitWidth(50);
        
        Button listButton4ounass = new Button();
        listButton4ounass.setGraphic(new StackPane(listbtn1view4ounass));
        listButton4ounass.setPrefSize(35, 35);
        listButton4ounass.setTranslateY(65);
        listButton4ounass.setTranslateX(20);
        listButton4ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton4ounass = new Button();
        wishlistButton4ounass.setGraphic(new StackPane(wishlistView4Ounass));
        wishlistButton4ounass.setPrefSize(35, 35);
        wishlistButton4ounass.setTranslateY(61);
        wishlistButton4ounass.setTranslateX(-20);
        wishlistButton4ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass4.getChildren().addAll(rectProductOunass4, SmallrectProductOunass4,
                 ounassImg4, ounass4Lb, wishlistButton4ounass, listButton4ounass);

        itemsBox2ounass.getChildren().addAll(rectitemsOunass3, rectitemsOunass4);

        // third 2 /////////////////
        HBox itemsBox3ounass = new HBox(40);

        itemsBox3ounass.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsOunass5 = new StackPane();
        Rectangle rectProductOunass5 = new Rectangle(110, 155);
        rectProductOunass5.setFill(PinkRectL);
        rectProductOunass5.setArcWidth(10);
        rectProductOunass5.setArcHeight(10);

        Rectangle SmallrectProductOunass5 = new Rectangle(110, 30);
        SmallrectProductOunass5.setFill(PinkRectD);
        SmallrectProductOunass5.setArcWidth(10);
        SmallrectProductOunass5.setArcHeight(10);
        SmallrectProductOunass5.setTranslateY(62);

        Image ounass5 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (26).PNG");
        ImageView ounassImg5 = new ImageView(ounass5);//
        ounassImg5.setFitHeight(80);
        ounassImg5.setFitWidth(80);
        ounassImg5.setTranslateY(-36);

        Label ounass5Lb = new Label("Prada sunglasess\n1,700SR");
        ounass5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass5Lb.setPadding(new Insets(0, 25, 25, 0));
        ounass5Lb.setTranslateY(34);
        
        
        ImageView listbtn1view5ounass = new ImageView(listimg1);//
        listbtn1view5ounass.setFitHeight(68);
        listbtn1view5ounass.setFitWidth(68);
        
        ImageView wishlistView5ounass = new ImageView(wishlistimg1);
        wishlistView5ounass.setFitHeight(50);
        wishlistView5ounass.setFitWidth(50);
        
        Button listButton5ounass = new Button();
        listButton5ounass.setGraphic(new StackPane(listbtn1view5ounass));
        listButton5ounass.setPrefSize(35, 35);
        listButton5ounass.setTranslateY(65);
        listButton5ounass.setTranslateX(20);
        listButton5ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton5ounass = new Button();
        wishlistButton5ounass.setGraphic(new StackPane(wishlistView5ounass));
        wishlistButton5ounass.setPrefSize(35, 35);
        wishlistButton5ounass.setTranslateY(61);
        wishlistButton5ounass.setTranslateX(-20);
        wishlistButton5ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass5.getChildren().addAll(rectProductOunass5, SmallrectProductOunass5,
                 ounassImg5, ounass5Lb, wishlistButton5ounass, listButton5ounass);
        //////////////////////////////////////////////
        StackPane rectitemsOunass6 = new StackPane();
        Rectangle rectProductOunass6 = new Rectangle(110, 155);
        rectProductOunass6.setFill(PinkRectL);
        rectProductOunass6.setArcWidth(10);
        rectProductOunass6.setArcHeight(10);

        Rectangle SmallrectProductOunass6 = new Rectangle(110, 30);
        SmallrectProductOunass6.setFill(PinkRectD);
        SmallrectProductOunass6.setArcWidth(10);
        SmallrectProductOunass6.setArcHeight(10);
        SmallrectProductOunass6.setTranslateY(62);

        Image ounass6 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (27).PNG");
        ImageView ounassImg6 = new ImageView(ounass6);//
        ounassImg6.setFitHeight(100);
        ounassImg6.setFitWidth(100);
        ounassImg6.setTranslateY(-35);

        Label ounass6Lb = new Label("Bottega Veneta\nbag \n13,400SR");
        ounass6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass6Lb.setPadding(new Insets(0, 20, 25, 0));
        ounass6Lb.setTranslateY(35);
        
        ImageView listbtn1view6ounass = new ImageView(listimg1);//
        listbtn1view6ounass.setFitHeight(68);
        listbtn1view6ounass.setFitWidth(68);
        
        ImageView wishlistView6ounass = new ImageView(wishlistimg1);
        wishlistView6ounass.setFitHeight(50);
        wishlistView6ounass.setFitWidth(50);
        
        Button listButton6ounass = new Button();
        listButton6ounass.setGraphic(new StackPane(listbtn1view6ounass));
        listButton6ounass.setPrefSize(35, 35);
        listButton6ounass.setTranslateY(65);
        listButton6ounass.setTranslateX(20);
        listButton6ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton6ounass = new Button();
        wishlistButton6ounass.setGraphic(new StackPane(wishlistView6ounass));
        wishlistButton6ounass.setPrefSize(35, 35);
        wishlistButton6ounass.setTranslateY(61);
        wishlistButton6ounass.setTranslateX(-20);
        wishlistButton6ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass6.getChildren().addAll(rectProductOunass6, SmallrectProductOunass6,
                 ounassImg6, ounass6Lb , wishlistButton6ounass , listButton6ounass );

        itemsBox3ounass.getChildren().addAll(rectitemsOunass5, rectitemsOunass6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4ounass = new HBox(40);

        itemsBox4ounass.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsOunass7 = new StackPane();
        Rectangle rectProductOunass7 = new Rectangle(110, 155);
        rectProductOunass7.setFill(PinkRectL);
        rectProductOunass7.setArcWidth(10);
        rectProductOunass7.setArcHeight(10);

        Rectangle SmallrectProductOunass7 = new Rectangle(110, 30);
        SmallrectProductOunass7.setFill(PinkRectD);
        SmallrectProductOunass7.setArcWidth(10);
        SmallrectProductOunass7.setArcHeight(10);
        SmallrectProductOunass7.setTranslateY(62);

        Image ounass7 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (29).PNG");
        ImageView ounassImg7 = new ImageView(ounass7);//
        ounassImg7.setFitHeight(90);
        ounassImg7.setFitWidth(85);
        ounassImg7.setTranslateY(-30);

        Label ounass7Lb = new Label("Jimmiy Choo heels \n8,665SR");
        ounass7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass7Lb.setPadding(new Insets(0, 0, 25, 0));
        ounass7Lb.setTranslateY(40);
        
        ImageView listbtn1view7ounass = new ImageView(listimg1);//
        listbtn1view7ounass.setFitHeight(68);
        listbtn1view7ounass.setFitWidth(68);
        
        ImageView wishlistView7ounass = new ImageView(wishlistimg1);
        wishlistView7ounass.setFitHeight(50);
        wishlistView7ounass.setFitWidth(50);
        
        Button listButton7ounass = new Button();
        listButton7ounass.setGraphic(new StackPane(listbtn1view7ounass));
        listButton7ounass.setPrefSize(35, 35);
        listButton7ounass.setTranslateY(65);
        listButton7ounass.setTranslateX(20);
        listButton7ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton7ounass = new Button();
        wishlistButton7ounass.setGraphic(new StackPane(wishlistView7ounass));
        wishlistButton7ounass.setPrefSize(35, 35);
        wishlistButton7ounass.setTranslateY(61);
        wishlistButton7ounass.setTranslateX(-20);
        wishlistButton7ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass7.getChildren().addAll(rectProductOunass7, SmallrectProductOunass7,
                 ounassImg7, ounass7Lb, wishlistButton7ounass , listButton7ounass);
        ///////////////////////////////////////////////
        StackPane rectitemsOunass8 = new StackPane();
        Rectangle rectProductOunass8 = new Rectangle(110, 155);
        rectProductOunass8.setFill(PinkRectL);
        rectProductOunass8.setArcWidth(10);
        rectProductOunass8.setArcHeight(10);

        Rectangle SmallrectProductOunass8 = new Rectangle(110, 30);
        SmallrectProductOunass8.setFill(PinkRectD);
        SmallrectProductOunass8.setArcWidth(10);
        SmallrectProductOunass8.setArcHeight(10);
        SmallrectProductOunass8.setTranslateY(62);

        Image ounass8 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (21).PNG");
        ImageView ounassImg8 = new ImageView(ounass8);//
        ounassImg8.setFitHeight(90);
        ounassImg8.setFitWidth(95);
        ounassImg8.setTranslateY(-34);

        Label ounass8Lb = new Label("Red Dress\n11,500SR");
        ounass8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass8Lb.setPadding(new Insets(0, 0, 25, 0));
        ounass8Lb.setTranslateY(38);
        
        ImageView listbtn1view8ounass = new ImageView(listimg1);//
        listbtn1view8ounass.setFitHeight(68);
        listbtn1view8ounass.setFitWidth(68);
        
        ImageView wishlistView8ounass = new ImageView(wishlistimg1);
        wishlistView8ounass.setFitHeight(50);
        wishlistView8ounass.setFitWidth(50);
        
        Button listButton8ounass = new Button();
        listButton8ounass.setGraphic(new StackPane(listbtn1view8ounass));
        listButton8ounass.setPrefSize(35, 35);
        listButton8ounass.setTranslateY(65);
        listButton8ounass.setTranslateX(20);
        listButton8ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton8ounass = new Button();
        wishlistButton8ounass.setGraphic(new StackPane(wishlistView8ounass));
        wishlistButton8ounass.setPrefSize(35, 35);
        wishlistButton8ounass.setTranslateY(61);
        wishlistButton8ounass.setTranslateX(-20);
        wishlistButton8ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass8.getChildren().addAll(rectProductOunass8 , SmallrectProductOunass8
                , ounassImg8, ounass8Lb , wishlistButton8ounass , listButton8ounass);

        itemsBox4ounass.getChildren().addAll(rectitemsOunass7, rectitemsOunass8 );

        // fifth 2/////////////////////////////
        HBox itemsBox5ounass = new HBox(40);

        itemsBox5ounass.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsOunass9 = new StackPane();
        Rectangle rectProductOunass9 = new Rectangle(110, 155);
        rectProductOunass9.setFill(PinkRectL);
        rectProductOunass9.setArcWidth(10);
        rectProductOunass9.setArcHeight(10);

        Rectangle SmallrectProductOunass9 = new Rectangle(110, 30);
        SmallrectProductOunass9.setFill(PinkRectD);
        SmallrectProductOunass9.setArcWidth(10);
        SmallrectProductOunass9.setArcHeight(10);
        SmallrectProductOunass9.setTranslateY(62);

        Image ounass9 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (28).PNG");
        ImageView ounassImg9 = new ImageView(ounass9);//
        ounassImg9.setFitHeight(88);
        ounassImg9.setFitWidth(70);
        ounassImg9.setTranslateY(-37);

        Label ounass9Lb = new Label("Buochron Watch\n24,300SR");
        ounass9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        ounass9Lb.setPadding(new Insets(0, 5, 25, 0));
        ounass9Lb.setTranslateY(40);
        
        ImageView listbtn1view9ounass = new ImageView(listimg1);//
        listbtn1view9ounass.setFitHeight(68);
        listbtn1view9ounass.setFitWidth(68);
        
        ImageView wishlistView9ounass = new ImageView(wishlistimg1);
        wishlistView9ounass.setFitHeight(50);
        wishlistView9ounass.setFitWidth(50);
        
        Button listButton9ounass = new Button();
        listButton9ounass.setGraphic(new StackPane(listbtn1view9ounass));
        listButton9ounass.setPrefSize(35, 35);
        listButton9ounass.setTranslateY(65);
        listButton9ounass.setTranslateX(20);
        listButton9ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton9ounass = new Button();
        wishlistButton9ounass.setGraphic(new StackPane(wishlistView9ounass));
        wishlistButton9ounass.setPrefSize(35, 35);
        wishlistButton9ounass.setTranslateY(61);
        wishlistButton9ounass.setTranslateX(-20);
        wishlistButton9ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass9.getChildren().addAll(rectProductOunass9, SmallrectProductOunass9,
                 ounassImg9, ounass9Lb , wishlistButton9ounass , listButton9ounass);
/////////////////////////////////////////////////////////
        StackPane rectitemsOunass10 = new StackPane();
        Rectangle rectProductOunass10 = new Rectangle(110, 155);
        rectProductOunass10.setFill(PinkRectL);
        rectProductOunass10.setArcWidth(10);
        rectProductOunass10.setArcHeight(10);

        Rectangle SmallrectProductOunass10 = new Rectangle(110, 30);
        SmallrectProductOunass10.setFill(PinkRectD);
        SmallrectProductOunass10.setArcWidth(10);
        SmallrectProductOunass10.setArcHeight(10);
        SmallrectProductOunass10.setTranslateY(62);

        Image ounass10 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Result (22).PNG");
        ImageView OunassImg10 = new ImageView(ounass10);//
        OunassImg10.setFitHeight(80);
        OunassImg10.setFitWidth(70);
        OunassImg10.setTranslateY(-35);

        Label Ounass10Lb = new Label("Elegant ?Abaya \n1,200SR");
        Ounass10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        Ounass10Lb.setPadding(new Insets(0, 0, 25, 0));
        Ounass10Lb.setTranslateY(38);
        
        ImageView listbtn1view10ounass = new ImageView(listimg1);//
        listbtn1view10ounass.setFitHeight(68);
        listbtn1view10ounass.setFitWidth(68);
        
        ImageView wishlistView10Ounass = new ImageView(wishlistimg1);
        wishlistView10Ounass.setFitHeight(50);
        wishlistView10Ounass.setFitWidth(50);
        
        Button listButton10Ounass = new Button();
        listButton10Ounass.setGraphic(new StackPane(listbtn1view10ounass));
        listButton10Ounass.setPrefSize(35, 35);
        listButton10Ounass.setTranslateY(65);
        listButton10Ounass.setTranslateX(20);
        listButton10Ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton10ounass = new Button();
        wishlistButton10ounass.setGraphic(new StackPane(wishlistView10Ounass));
        wishlistButton10ounass.setPrefSize(35, 35);
        wishlistButton10ounass.setTranslateY(61);
        wishlistButton10ounass.setTranslateX(-20);
        wishlistButton10ounass.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsOunass10.getChildren().addAll(rectProductOunass10, SmallrectProductOunass10
                , OunassImg10, Ounass10Lb , wishlistButton10ounass , listButton10Ounass);

        itemsBox5ounass.getChildren().addAll(rectitemsOunass9, rectitemsOunass10);

        centerBoxounass.getChildren().addAll(centerSpendingounass, itemsBoxounass, itemsBox2ounass,
                 itemsBox3ounass, itemsBox4ounass, itemsBox5ounass);
        
        
        ScrollPane scrollPaneounass = new ScrollPane(centerBoxounass);
        scrollPaneounass.setFitToWidth(true);
        scrollPaneounass.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        // bottom 
        StackPane bottomOunassroot = new StackPane();

        Rectangle rectangleBounass = new Rectangle();
        rectangleBounass.setWidth(360);
        rectangleBounass.setHeight(60);
        rectangleBounass.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBounass, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottomOunassroot.getChildren().addAll(rectangleBounass, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

           
        ounassPane.setTop(topOunassroot);       
        ounassPane.setCenter(scrollPaneounass);
        ounassPane.setBottom(bottomOunassroot);

        Scene scene = new Scene(ounassPane, 350, 600);
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); //




//-------------------------------- ACTION ----------------------------------------------//

        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();
      //  ProfileScene profileScene = new ProfileScene();

        backImg.setOnMouseClicked(e -> {
            homePageScene.start(primaryStage);
        });


        homeButton.setOnAction(e -> {
            homePageScene.start(primaryStage);
        });

        wishlistButton.setOnAction(e -> {
            wishlistScene.start(primaryStage);
        });

        listButton.setOnAction(e -> {
            listScene.start(primaryStage);
        });

//        profileButton.setOnAction(e -> {
//            profileScene.start(new Stage());
//        });
    }

}
