/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */


import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.text.DecimalFormat;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class DashboardScene extends Application {

    private VBox sidebar;

    // Method to toggle the sidebar in
    private void toggleSidebar(TranslateTransition transition) {
        if (sidebar.getTranslateX() != 0) {
            transition.setRate(1);
            transition.play();
        } else {
            transition.setRate(-1);
            transition.play();
        }
    }

    public static double calculatePercentage(double value, double total) {
        double percentage = (value / total) * 100;
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        String formattedPercentage = decimalFormat.format(percentage);
        return Double.parseDouble(formattedPercentage);
    }

    TextField pharmacyTextField = new TextField();
    TextField foodTextField = new TextField();
    TextField jewelryTextField = new TextField();
    TextField beautyTextField = new TextField();
    TextField clothesTextField = new TextField();
    TextField billsTextField = new TextField();
    TextField totalIncomeTextField = new TextField();

    TextField[] textFields = {totalIncomeTextField,
            clothesTextField,
            beautyTextField,
            jewelryTextField,
            foodTextField,
            pharmacyTextField,
            billsTextField};
    @Override
    public void start(Stage stage) {


        //------------------------------ dashboard ---------------///////

        Font font5 = Font.font("serif", 11);


        StackPane top3 = new StackPane();
        Rectangle rtop = new Rectangle(350,90);
        rtop.setFill(Color.web("#657da1"));

        Text dashboard = new Text("Dashboard");
        dashboard.setStyle("-fx-font: normal bold 14px 'serif'");
        dashboard.setFill(Color.WHITE);

        StackPane.setAlignment(dashboard, Pos.CENTER_LEFT);
        StackPane.setMargin(dashboard, new Insets(-25, 0, 0, 30));

        TextField searchField3 = new TextField();
        searchField3.setPromptText("Search here ...");
        searchField3.setStyle("-fx-font: normal 10px 'serif'");
        searchField3.setPrefWidth(150);
        searchField3.setPrefHeight(25);
        Rectangle searchFieldShape3 = new Rectangle();
        searchFieldShape3.setWidth(150);
        searchFieldShape3.setHeight(25);
        searchFieldShape3.setArcWidth(25);
        searchFieldShape3.setArcHeight(30);
        searchField3.setShape(searchFieldShape3);

        Image searchImage3 = new Image("file:C:\\Users\\ghadi\\Downloads\\search.png");
        ImageView searchView3 = new ImageView(searchImage3);
        searchView3.setFitHeight(19);
        searchView3.setFitWidth(22);

        Button searchButton3 = new Button();
        searchButton3.setGraphic(new StackPane(searchView3));
        searchButton3.setPrefSize(20, 20);
        searchButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        StackPane.setMargin(searchButton3, new Insets(0, 0, 0, 180));
        StackPane searchFieldContainer3 = new StackPane();
        searchFieldContainer3.getChildren().addAll(searchField3, searchButton3);

        HBox searchBox3 = new HBox(searchFieldContainer3);

        StackPane.setMargin(searchBox3, new Insets(34, 0, 0, 30));

        top3.getChildren().addAll(rtop, dashboard, searchBox3);


            /*


            ----------- Statistics Area ----------------


             */

        Rectangle oval1 = new Rectangle(170,80); //left oval
        oval1.setArcWidth(50);
        oval1.setArcHeight(50);
        oval1.setFill(Color.web("#657da1"));
        //put the labels on vbox then put the vbox on the oval using
        //stackpane then add stackpane to the ovalc hbox
        Label spendlbl = new Label("Spending Statistics");
        spendlbl.setFont(font5);
        spendlbl.setStyle("-fx-font-weight: bold;");
        progressBar = new ProgressBar();
        progressBar.setMaxWidth(200);
        // set the progress value to be between 0 and 1


        //to add label and progress bar vertically
        VBox statistic = new VBox(5);
        statistic.setPadding(new Insets(13));
        statistic.getChildren().addAll(spendlbl,progressBar);
        //stack pane to add progress bar on the oval
        StackPane ss = new StackPane();
        ss.setPadding(new Insets(13));
        ss.setAlignment(Pos.CENTER);
        ss.getChildren().addAll(oval1,statistic);

        //right oval
        Rectangle oval2 = new Rectangle(100,80);
        oval2.setArcWidth(50);
        oval2.setArcHeight(50);
        oval2.setFill(Color.web("#657da1"));
        oval2.setFill(Color.web("#657da1"));
        incomelbl = new Label("Total Income:\n"+ "$");
        incomelbl.setStyle("-fx-font-weight: bold;");
        incomelbl.setFont(font5);
        incomelbl.setAlignment(Pos.TOP_LEFT);
        StackPane s = new StackPane();
        s.setPadding(new Insets(10,5,10,5));
        //s.setAlignment(Pos.CENTER_LEFT);
        s.getChildren().addAll(oval2,incomelbl);

        //hbox contains left and right ovals, ss = stack pane that contains the left oval
        HBox ovals = new HBox(18);
        ovals.setPadding(new Insets(20));
        ovals.getChildren().addAll(s,ss);

        // Create a PieChart and populate it with data
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Clothes", 600),
                new PieChart.Data("Beauty", 800),
                new PieChart.Data("Jewelry", 400),
                new PieChart.Data("Food", 2000),
                new PieChart.Data("Pharmacy", 150),
                new PieChart.Data("Bills", 3000)
        );
        PieChart pieChart = new PieChart(pieChartData);
        pieChart.setTitle("Categories and Expenses");
        pieChart.setLegendVisible(false);
        pieChart.setStyle("-fx-border-color: trasparent; -fx-border-width: 0.01px;");


        //  labelling the slices


            /*

              ------------------------- Bottom Area -------------------------


             */

        StackPane bottom2 = new StackPane();

        Rectangle rectangleB2 = new Rectangle();
        rectangleB2.setWidth(350);
        rectangleB2.setHeight(60);
        rectangleB2.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleB2, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome2 = new Image("file:C:\\Users\\ghadi\\Downloads\\home.png");

        ImageView homeView2 = new ImageView(imageHome2);
        homeView2.setFitHeight(50);
        homeView2.setFitWidth(60);

        Button homeButton4 = new Button();
        homeButton4.setGraphic(new StackPane(homeView2));
        homeButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton4, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton4, new Insets(10, 0, 0, 30));

        Text textHome3 = new Text("Home");
        textHome3.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome3.setFill(Color.WHITE);

        StackPane.setAlignment(textHome3, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome3, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage3 = new Image("file:C:\\Users\\ghadi\\Downloads\\wishlist.png");
        ImageView wishlistView3 = new ImageView(wishlistImage3);
        wishlistView3.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView3.setFitWidth(70);

        Button wishlistButton3 = new Button();
        wishlistButton3.setGraphic(new StackPane(wishlistView3));
        wishlistButton3.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton3, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton3, new Insets(10, 0, 0, 91));

        Text wishlistText3 = new Text("Wishlist");
        wishlistText3.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText3.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText3, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText3, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage4 = new Image("file:C:\\Users\\ghadi\\Downloads\\list.png");
        ImageView listView4 = new ImageView(listImage4);
        listView4.setFitHeight(70); //setting the fit height and width of the image view
        listView4.setFitWidth(80);

        Button listButton4 = new Button();
        listButton4.setGraphic(new StackPane(listView4));
        listButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton4, Pos.CENTER);
        StackPane.setMargin(listButton4, new Insets(15, 0, 0, 60));

        Text listText3 = new Text("List");
        listText3.setStyle("-fx-font: normal bold 10px 'serif'");
        listText3.setFill(Color.WHITE);

        StackPane.setAlignment(listText3, Pos.CENTER);
        StackPane.setMargin(listText3, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage4 = new Image("file:C:\\Users\\ghadi\\Downloads\\profile.png");
        ImageView profileView4 = new ImageView(profileImage4);
        profileView4.setFitHeight(70); //setting the fit height and width of the image view
        profileView4.setFitWidth(100);

        Button profileButton4 = new Button();
        profileButton4.setGraphic(new StackPane(profileView4));
        profileButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton4, Pos.CENTER);
        StackPane.setMargin(profileButton4, new Insets(0, 0, 0, 210));

        Text profileText3 = new Text("Profile");
        profileText3.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText3.setFill(Color.WHITE);

        StackPane.setAlignment(profileText3, Pos.CENTER);
        StackPane.setMargin(profileText3, new Insets(50, 0, 0, 200));



        bottom2.getChildren().addAll(rectangleB2, homeButton4, textHome3
                , wishlistButton3 , wishlistText3 , listButton4 ,listText3 , profileButton4 , profileText3 );

        VBox dashboardBox = new VBox();
        dashboardBox.getChildren().addAll(top3, ovals, pieChart, bottom2);
        dashboardBox.setStyle("-fx-background-color: #c4d5de;");

        Scene dashboardScene = new Scene(dashboardBox,350,600);
//        dashboardButton.setOnAction(e -> {
//            updateDashboard(pieChart, totalIncomeTextField,clothesTextField, jewelryTextField, beautyTextField,
//                    foodTextField, pharmacyTextField,billsTextField);
//            stage.setScene(dashboardScene);
//            stage.setTitle("Dashboard");
//        });



        stage.setScene(dashboardScene);
        stage.show();
        HomePageScene homePageScene = new HomePageScene();
        homeButton4.setOnAction(e->{
            homePageScene.start(new Stage());
        });

        WishlistScene wishlistScene = new WishlistScene();
        wishlistButton3.setOnAction(e->{
            wishlistScene.start(new Stage());
        });

        ListScene listScene = new ListScene();
        listButton4.setOnAction(e->{
            listScene.start(new Stage());
        });




    }

    Label incomelbl;
    ProgressBar progressBar;


    private void updatePieChartData(PieChart pieChart, TextField[] textFields) {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Clothes", Double.parseDouble(textFields[1].getText())),
                new PieChart.Data("Beauty", Double.parseDouble(textFields[2].getText())),
                new PieChart.Data("Jewelry", Double.parseDouble(textFields[3].getText())),
                new PieChart.Data("Food", Double.parseDouble(textFields[4].getText())),
                new PieChart.Data("Pharmacy", Double.parseDouble(textFields[5].getText())),
                new PieChart.Data("Bills", Double.parseDouble(textFields[6].getText()))
        );


        //cloth,beauty,jew,food,ph,bill

        // Update PieChart data
        pieChart.setData(pieChartData);

        // Update slice labels with percentages
        pieChart.getData().forEach(data -> {
            data.setName(data.getName() + "\n" + calculatePercentage(data.getPieValue(), Double.parseDouble(textFields[0].getText())) + "%");
        });

        // Customize colors
        String[] colors = {"#fbf3f8", "#c4d5de", "#bca9c6", "#cd5ea2","#657da1", "#c4d5de"};
        for (int i = 0; i < pieChartData.size(); i++) {
            PieChart.Data data = pieChartData.get(i);
            data.getNode().setStyle("-fx-pie-color: " + colors[i] + ";");
        }

    }

    private void updateDashboard(PieChart pieChart, TextField... textFields) {
        try {
            double income = Double.parseDouble(textFields[0].getText());
            double total = Double.parseDouble(textFields[1].getText()) +
                    Double.parseDouble(textFields[2].getText()) +
                    Double.parseDouble(textFields[3].getText()) +
                    Double.parseDouble(textFields[4].getText()) +
                    Double.parseDouble(textFields[5].getText());

            // Update PieChart and other relevant components
            updatePieChartData(pieChart, textFields);
            updateProgressBar(progressBar, income, total);
            updateTotalIncomeLabel(incomelbl, income);
        } catch (NumberFormatException ex) {
            // Handle the exception (e.g., show an error message)
            System.out.println("Invalid input. Please enter valid numerical values in the text fields.");
        }
    }

// Add the following helper methods to update components accordingly

    private void updateProgressBar(ProgressBar progressBar, double income, double total) {
        double progress = total / income;
        progress = max(0, min(progress, 1));
        progressBar.setProgress(progress);
    }

    private void updateTotalIncomeLabel(Label incomelbl, double income) {
        incomelbl.setText("Total Income:\n" + "$" + income);
    }
}

