package com.mycompany.approject;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import static java.lang.Math.max;
import static java.lang.Math.min;
import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static javafx.application.Application.launch;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * JavaFX App
 */
public class App extends Application {

//    IHerb iHerbScene = new IHerb();
//    Amazon amazonScene = new Amazon();
//    Nahdi nahdiScene = new Nahdi();
//    NiceOne niceOneScene = new NiceOne();
//    Noon noonScene = new Noon();
//    Namshi namshiScene = new Namshi();
//    Ounass ounassScene = new Ounass();
//    SheIn sheinScene = new SheIn();
    HomePageScene homePageScene = new HomePageScene();
    User user;
    Wishlist wishlist;
    Session session;
    static int UserID;
    static int wishlistid ;
    static TextField emailTextField;
    static TextField emailTextField2;

    @Override
    public void start(Stage stage) {

        VBox root = new VBox();

        root.setStyle("-fx-background-color: #c4d5de;");
        Scene scene = new Scene(root, 350, 600);
        stage.setTitle("Welcome!");
        stage.setScene(scene);
        stage.show();

        VBox logo = new VBox();   //logo image
        //logo.setStyle("-fx-border-color: red;");
        logo.setPadding(new Insets(60, 20, 20, 20)); //top right bottom left .     box place
        logo.setAlignment(Pos.CENTER);

        Image image = new Image("file:c:/Users/ghadi/Downloads/logo.png");
        ImageView imageView = new ImageView(image);//Setting the image view
        imageView.setFitHeight(200); //setting the fit height and width of the image view
        imageView.setFitWidth(200);

        logo.getChildren().addAll(imageView);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        HBox LogInBox = new HBox();   // login button
        //LogInBox.setStyle("-fx-border-color: red;");
        LogInBox.setPadding(new Insets(30, 20, 10, 20)); //top right bottom left .         box place
        LogInBox.setAlignment(Pos.CENTER);

        Button LogInB = new Button("Login");
        LogInB.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");

        LogInB.setPrefWidth(150); // to enlarge the button
        LogInB.setPrefHeight(30); // to enlarge the button
        LogInB.setFocusTraversable(false);
        LogInBox.getChildren().add(LogInB);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        HBox SignUpBox = new HBox();   // sign up button
        //SignUpBox.setStyle("-fx-border-color: red;");
        SignUpBox.setPadding(new Insets(10, 20, 20, 20)); //top right bottom left .       box place
        SignUpBox.setAlignment(Pos.CENTER);

        Button SignUpB = new Button("Sign Up");
        SignUpB.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        SignUpB.setPrefWidth(150); // to enlarge the button
        SignUpB.setPrefHeight(30); // to enlarge the button
        SignUpB.setFocusTraversable(false);

        SignUpBox.getChildren().add(SignUpB);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////----------------------------------------- LOGIN SCENE ------------------------------------------------- ////
        // login text
        Text login = new Text("Login");
        Font font = Font.font("Poppins Medium", 36);
        login.setFont(font);
        login.setStyle("-fx-font-weight: bold;");
        login.setFill(Color.web("#cd5ea2"));

        HBox loginTextBox = new HBox(login);
        loginTextBox.setPadding(new Insets(120, 20, 10, 20)); //top right bottom left
        loginTextBox.setAlignment(Pos.CENTER);

        // email & password fields
        Label emailLabel = new Label("Email:");
         emailTextField = new TextField();
        emailTextField.setMaxWidth(200);
        emailTextField.setStyle("-fx-background-color: #CBC9C7;");

        String allowedDomain = "gmail.com";
        emailTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!isValidEmailDomain(emailTextField.getText(), allowedDomain)) {
                emailTextField.setStyle("-fx-border-color: red; -fx-background-color: #CBC9C7;");
            } else {
                emailTextField.setStyle("-fx-border-color: green; -fx-background-color: #CBC9C7;"); //is valid
            }
        });

        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(200);
        passwordField.setStyle("-fx-background-color: #CBC9C7;");

        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (passwordField.getText().length() < 8 || !containsCapitalLetter(passwordField.getText())) {
                passwordField.setStyle("-fx-border-color: red; -fx-background-color: #CBC9C7;");
            } else {
                passwordField.setStyle("-fx-border-color: green; -fx-background-color: #CBC9C7;"); //is valid
            }
        });

        CheckBox showPassCB = new CheckBox("Show Password");
        showPassCB.setOnAction(event -> {
            if (showPassCB.isSelected()) {

            } else {
            }
        });

        VBox emailpassBox = new VBox(10);
        emailpassBox.setPadding(new Insets(10, 20, 10, 20)); //top right bottom left
        emailpassBox.setAlignment(Pos.CENTER);

        emailpassBox.getChildren().addAll(emailLabel, emailTextField, passwordLabel, passwordField, showPassCB);

        //texts
        Text text1 = new Text("Forgot Password?");
        text1.setFont(Font.font("serif", 12));
        text1.setFill(Color.web("#8F8E8E"));

        // Create the second text
        Text text2 = new Text("  New User? Sign Up!");
        text2.setFont(Font.font("serif", 12));
        text2.setFill(Color.web("#8F8E8E"));
        VBox texts = new VBox(5, text1, text2);
        texts.setAlignment(Pos.CENTER);

        // login button
        HBox loginBox2 = new HBox();
        loginBox2.setPadding(new Insets(20, 20, 10, 20)); //top right bottom left
        loginBox2.setAlignment(Pos.CENTER);

        Button loginB2 = new Button("Login");
        loginB2.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        loginB2.setPrefWidth(150); // to enlarge the button
        ;
        loginB2.setPrefHeight(30); // to enlarge the button
        loginB2.setFocusTraversable(false);
        loginBox2.getChildren().addAll(loginB2);

        Image arrow = new Image("file:c:/Users/ghadi/Downloads/backArrow.png");
        ImageView arrowView = new ImageView(arrow);//Setting the image view
        arrowView.setFitHeight(20); //setting the fit height and width of the image view
        arrowView.setFitWidth(20);

        HBox arrowBox = new HBox(arrowView);
        arrowBox.setAlignment(Pos.BOTTOM_RIGHT);
        arrowBox.setPadding(new Insets(10, 40, 5, 10)); //top right bottom left

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////----------------------------------------- SIGN UP SCENE ------------------------------------------------- ////
        VBox root2 = new VBox();

        Text Create = new Text(" Create new Account");
        Font font2 = Font.font("Poppins Medium", 32);
        Create.setFont(font2);
        Create.setStyle("-fx-font-weight: bold;");
        Create.setFill(Color.web("#cd5ea2"));

        HBox signUpTextBox = new HBox(Create);
        signUpTextBox.setPadding(new Insets(120, 20, 10, 20)); //top right bottom left
        signUpTextBox.setAlignment(Pos.CENTER);

        Text Already = new Text("Already Registered? Login");
        Already.setFont(Font.font("serif", 12));
        Already.setFill(Color.web("#8F8E8E"));
        VBox texts2 = new VBox(5, Already);
        texts2.setAlignment(Pos.CENTER);

        /////////////////////////////////
        Label nameLabel1 = new Label("Name:");
        TextField nameTextField2 = new TextField();
        nameTextField2.setMaxWidth(200);
        nameTextField2.setStyle("-fx-background-color: #CBC9C7;");

        
        // email & password fields
        Label emailLabel2 = new Label("Email:");
        emailTextField2 = new TextField();
        emailTextField2.setMaxWidth(200);
        emailTextField2.setStyle("-fx-background-color: #CBC9C7;");
        emailTextField2.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!isValidEmailDomain(newValue, allowedDomain)) {
                emailTextField2.setStyle("-fx-border-color: red; -fx-background-color: #CBC9C7;");
            } else {
                emailTextField2.setStyle("-fx-border-color: green; -fx-background-color: #CBC9C7;"); //is valid
            }
        });

        Label passwordLabel2 = new Label("Password:");
        PasswordField passwordField2 = new PasswordField();
        passwordField2.setMaxWidth(200);
        passwordField2.setStyle("-fx-background-color: #CBC9C7;");

        passwordField2.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.length() < 8 || !containsCapitalLetter(newValue)) {
                passwordField2.setStyle("-fx-border-color: red; -fx-background-color: #CBC9C7;");
            } else {
                passwordField2.setStyle("-fx-border-color: green; -fx-background-color: #CBC9C7;"); //is valid
            }
        });

        Label dobLable = new Label("Date Of Birth:");
        DatePicker datePiker = new DatePicker();
        datePiker.setMaxWidth(200);
        datePiker.setStyle("-fx-background-color: #CBC9C7;");

        //////////////////////
        VBox AllInfo = new VBox(10);
        AllInfo.setPadding(new Insets(10, 20, 10, 20)); //top right bottom left
        AllInfo.setAlignment(Pos.CENTER);
        AllInfo.getChildren().addAll(nameLabel1, nameTextField2, emailLabel2, emailTextField2, passwordLabel2, passwordField2, dobLable, datePiker);

        VBox signUpBOX = new VBox();   // login button
        //LogInBox.setStyle("-fx-border-color: red;");
        signUpBOX.setPadding(new Insets(30, 20, 10, 20)); //top right bottom left .         box place
        signUpBOX.setAlignment(Pos.CENTER);

        Button SingUpB2 = new Button("Sign Up");
        SingUpB2.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");

        SingUpB2.setPrefWidth(150); // to enlarge the button
        SingUpB2.setPrefHeight(30); // to enlarge the button
        SingUpB2.setFocusTraversable(false);
        signUpBOX.getChildren().add(SingUpB2);

        root2.getChildren().addAll(signUpTextBox, texts2, AllInfo, signUpBOX);
        root2.setStyle("-fx-background-color: #c4d5de;");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////----------------------------------------- HOME PAGE SCENE ------------------------------------------------- ////
        ///////HOME page ACTION////////
        //////////////////////////////////////////////////////////////////////////
        ////----------------------------------------- WISHLIST SCENE ------------------------------------------------- ////
        // ------------------------------------------------- color -------------------------------------------------
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////----------------------------------------- SIDEBAR SCENE -------------------------------------------------////
        // Create buttons for navigation
        Button homeButton2 = new Button("Home");
        homeButton2.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        Button dashboardButton = new Button("Dashboard");
        dashboardButton.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        Button settingsButton = new Button("Settings");
        settingsButton.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        Button logoutButton = new Button("Log Out");
        logoutButton.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        homeButton2.setFocusTraversable(false);
        dashboardButton.setFocusTraversable(false);
        settingsButton.setFocusTraversable(false);
        logoutButton.setFocusTraversable(false);

        // Create a VBox to hold the buttons
        sidebar = new VBox(30);
        sidebar.getChildren().addAll(homeButton2, dashboardButton, settingsButton, logoutButton);
        sidebar.setPadding(new Insets(20));

        // Set actions for the buttons
        // Create a BorderPane with the sidebar on the left
        BorderPane borderPane = new BorderPane();
        borderPane.setRight(sidebar);
        sidebar.setStyle("-fx-background-color: #c4d5de;");
        //center2.setStyle("-fx-background-color: rgba(255, 192, 203, 0.5);");
        borderPane.getRight().setStyle("-fx-background-color: #c4d5de;");
        borderPane.setStyle("-fx-background-color: #c4d5de;");

        // Set up transition for the sidebar
        TranslateTransition sidebarTransition = new TranslateTransition(Duration.millis(300), sidebar);
        sidebarTransition.setFromX(-sidebar.getWidth() + 100);
        sidebarTransition.setToX(0);

        // Trigger the sidebar transition on button click
        Button toggleButton = new Button("Sidebar");
        VBox toggleBox = new VBox(toggleButton);
        toggleBox.setAlignment(Pos.CENTER_RIGHT);
        toggleBox.setPadding(new Insets(5));
        toggleButton.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");
        toggleButton.setFocusTraversable(false);
        toggleButton.setOnAction(e -> toggleSidebar(sidebarTransition));
        borderPane.setTop(toggleBox);

        ///////////////budget///////////
        VBox budgetBox = new VBox(10);
        budgetBox.setPadding(new Insets(20, 20, 20, 60));
        borderPane.setCenter(budgetBox);
        // Big bold "Budget" text
        Label budgetLabel = new Label("Budget");
        budgetLabel.setStyle("-fx-font-size: 24; -fx-font-weight: bold;");
        budgetBox.getChildren().add(budgetLabel);

        // Labels and TextFields for different categories
        Label totalIncomeLabel = new Label("Total Income:");
        TextField totalIncomeTextField = new TextField();
        totalIncomeTextField.setMaxWidth(100);
        totalIncomeTextField.setPromptText("Total Income amount");
        VBox totalIncomeBox = new VBox(5);
        totalIncomeBox.getChildren().addAll(totalIncomeLabel, totalIncomeTextField);
        budgetBox.getChildren().add(totalIncomeBox);

        Label billsLabel2 = new Label("Bills:");
        TextField billsTextField = new TextField();
        billsTextField.setMaxWidth(100);
        billsTextField.setPromptText("Bills amount");
        VBox billsBox = new VBox(5);
        billsBox.getChildren().addAll(billsLabel2, billsTextField);
        budgetBox.getChildren().add(billsBox);

        Label clothesLabel2 = new Label("Clothes:");
        TextField clothesTextField = new TextField();
        clothesTextField.setMaxWidth(100);
        clothesTextField.setPromptText("Clothes amount");
        VBox clothesBox = new VBox(5);
        clothesBox.getChildren().addAll(clothesLabel2, clothesTextField);
        budgetBox.getChildren().add(clothesBox);

        Label beautyLabel2 = new Label("Beauty:");
        TextField beautyTextField = new TextField();
        beautyTextField.setMaxWidth(100);
        beautyTextField.setPromptText("Beauty amount");
        VBox beautyBox = new VBox(5);
        beautyBox.getChildren().addAll(beautyLabel2, beautyTextField);
        budgetBox.getChildren().add(beautyBox);

        Label foodLabel2 = new Label("Food:");
        TextField foodTextField = new TextField();
        foodTextField.setMaxWidth(100);
        foodTextField.setPromptText("Food amount");
        VBox foodBox = new VBox(5);
        foodBox.getChildren().addAll(foodLabel2, foodTextField);
        budgetBox.getChildren().add(foodBox);

        Label pharmacyLabel2 = new Label("Pharmacy:");
        TextField pharmacyTextField = new TextField();
        pharmacyTextField.setMaxWidth(100);
        pharmacyTextField.setPromptText("Pharmacy amount");
        VBox pharmacyBox = new VBox(5);
        pharmacyBox.getChildren().addAll(pharmacyLabel2, pharmacyTextField);
        budgetBox.getChildren().add(pharmacyBox);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////----------------------------------------- DASHBOARD SCENE -------------------------------------------------////
        Font font5 = Font.font("serif", 11);

        StackPane top3 = new StackPane();
        Rectangle rtop = new Rectangle(350, 90);
        rtop.setFill(Color.web("#657da1"));

        Text dashboard = new Text("Dashboard");
        dashboard.setStyle("-fx-font: normal bold 14px 'serif'");
        dashboard.setFill(Color.WHITE);

        StackPane.setAlignment(dashboard, Pos.CENTER_LEFT);
        StackPane.setMargin(dashboard, new Insets(-25, 0, 0, 30));

        TextField searchField3 = new TextField();
        searchField3.setPromptText("Search here ...");
        searchField3.setStyle("-fx-font: normal 10px 'serif'");
        searchField3.setPrefWidth(150);
        searchField3.setPrefHeight(25);
        Rectangle searchFieldShape3 = new Rectangle();
        searchFieldShape3.setWidth(150);
        searchFieldShape3.setHeight(25);
        searchFieldShape3.setArcWidth(25);
        searchFieldShape3.setArcHeight(30);
        searchField3.setShape(searchFieldShape3);

        Image searchImage3 = new Image("file:C:\\Users\\ghadi\\Downloads\\search.png");
        ImageView searchView3 = new ImageView(searchImage3);
        searchView3.setFitHeight(19);
        searchView3.setFitWidth(22);

        Button searchButton3 = new Button();
        searchButton3.setGraphic(new StackPane(searchView3));
        searchButton3.setPrefSize(20, 20);
        searchButton3.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        StackPane.setMargin(searchButton3, new Insets(0, 0, 0, 180));
        StackPane searchFieldContainer3 = new StackPane();
        searchFieldContainer3.getChildren().addAll(searchField3, searchButton3);

        HBox searchBox3 = new HBox(searchFieldContainer3);

        StackPane.setMargin(searchBox3, new Insets(34, 0, 0, 30));

        top3.getChildren().addAll(rtop, dashboard, searchBox3);


        /*


            ----------- Statistics Area ----------------


         */
        Rectangle oval1 = new Rectangle(170, 80); //left oval
        oval1.setArcWidth(50);
        oval1.setArcHeight(50);
        oval1.setFill(Color.web("#657da1"));
        //put the labels on vbox then put the vbox on the oval using
        //stackpane then add stackpane to the ovalc hbox
        Label spendlbl = new Label("Spending Statistics");
        spendlbl.setFont(font5);
        spendlbl.setStyle("-fx-font-weight: bold;");
        progressBar = new ProgressBar();
        progressBar.setMaxWidth(200);
        // set the progress value to be between 0 and 1

        //to add label and progress bar vertically
        VBox statistic = new VBox(5);
        statistic.setPadding(new Insets(13));
        statistic.getChildren().addAll(spendlbl, progressBar);
        //stack pane to add progress bar on the oval
        StackPane ss = new StackPane();
        ss.setPadding(new Insets(13));
        ss.setAlignment(Pos.CENTER);
        ss.getChildren().addAll(oval1, statistic);

        //right oval
        Rectangle oval2 = new Rectangle(100, 80);
        oval2.setArcWidth(50);
        oval2.setArcHeight(50);
        oval2.setFill(Color.web("#657da1"));
        oval2.setFill(Color.web("#657da1"));
        incomelbl = new Label("Total Income:\n" + "$");
        incomelbl.setStyle("-fx-font-weight: bold;");
        incomelbl.setFont(font5);
        incomelbl.setAlignment(Pos.TOP_LEFT);
        StackPane s = new StackPane();
        s.setPadding(new Insets(10, 5, 10, 5));
        //s.setAlignment(Pos.CENTER_LEFT);
        s.getChildren().addAll(oval2, incomelbl);

        //hbox contains left and right ovals, ss = stack pane that contains the left oval
        HBox ovals = new HBox(18);
        ovals.setPadding(new Insets(20));
        ovals.getChildren().addAll(s, ss);

        // Create a PieChart and populate it with data
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Clothes", 600),
                new PieChart.Data("Beauty", 800),
                new PieChart.Data("Jewelry", 400),
                new PieChart.Data("Food", 2000),
                new PieChart.Data("Pharmacy", 150),
                new PieChart.Data("Bills", 3000)
        );
        PieChart pieChart = new PieChart(pieChartData);
        pieChart.setTitle("Categories and Expenses");
        pieChart.setLegendVisible(false);
        pieChart.setStyle("-fx-border-color: trasparent; -fx-border-width: 0.01px;");

        //  labelling the slices
        /*

              ------------------------- Bottom Area -------------------------


         */
        StackPane bottom2 = new StackPane();

        Rectangle rectangleB2 = new Rectangle();
        rectangleB2.setWidth(350);
        rectangleB2.setHeight(60);
        rectangleB2.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleB2, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome2 = new Image("file:C:\\Users\\ghadi\\Downloads\\home.png");

        ImageView homeView2 = new ImageView(imageHome2);
        homeView2.setFitHeight(50);
        homeView2.setFitWidth(60);

        Button homeButton4 = new Button();
        homeButton4.setGraphic(new StackPane(homeView2));
        homeButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton4, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton4, new Insets(10, 0, 0, 30));

        Text textHome3 = new Text("Home");
        textHome3.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome3.setFill(Color.WHITE);

        StackPane.setAlignment(textHome3, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome3, new Insets(50, 0, 0, 55));

        /////wishlist botton/////
        Image wishlistImage3 = new Image("file:C:\\Users\\ghadi\\Downloads\\wishlist.png");
        ImageView wishlistView3 = new ImageView(wishlistImage3);
        wishlistView3.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView3.setFitWidth(70);

        Button wishlistButton3 = new Button();
        wishlistButton3.setGraphic(new StackPane(wishlistView3));
        wishlistButton3.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton3, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton3, new Insets(10, 0, 0, 91));

        Text wishlistText3 = new Text("Wishlist");
        wishlistText3.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText3.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText3, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText3, new Insets(50, 0, 0, 120));

        //// List botton ////
        Image listImage4 = new Image("file:C:\\Users\\ghadi\\Downloads\\list.png");
        ImageView listView4 = new ImageView(listImage4);
        listView4.setFitHeight(70); //setting the fit height and width of the image view
        listView4.setFitWidth(80);

        Button listButton4 = new Button();
        listButton4.setGraphic(new StackPane(listView4));
        listButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton4, Pos.CENTER);
        StackPane.setMargin(listButton4, new Insets(15, 0, 0, 60));

        Text listText3 = new Text("List");
        listText3.setStyle("-fx-font: normal bold 10px 'serif'");
        listText3.setFill(Color.WHITE);

        StackPane.setAlignment(listText3, Pos.CENTER);
        StackPane.setMargin(listText3, new Insets(50, 0, 0, 60));

        ////// profile botton ////////
        Image profileImage4 = new Image("file:C:\\Users\\ghadi\\Downloads\\profile.png");
        ImageView profileView4 = new ImageView(profileImage4);
        profileView4.setFitHeight(70); //setting the fit height and width of the image view
        profileView4.setFitWidth(100);

        Button profileButton4 = new Button();
        profileButton4.setGraphic(new StackPane(profileView4));
        profileButton4.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton4, Pos.CENTER);
        StackPane.setMargin(profileButton4, new Insets(0, 0, 0, 210));

        Text profileText3 = new Text("Profile");
        profileText3.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText3.setFill(Color.WHITE);

        StackPane.setAlignment(profileText3, Pos.CENTER);
        StackPane.setMargin(profileText3, new Insets(50, 0, 0, 200));

        bottom2.getChildren().addAll(rectangleB2, homeButton4, textHome3,
                 wishlistButton3, wishlistText3, listButton4, listText3, profileButton4, profileText3);

        VBox dashboardBox = new VBox();
        dashboardBox.getChildren().addAll(top3, ovals, pieChart, bottom2);
        dashboardBox.setStyle("-fx-background-color: #c4d5de;");

        Scene dashboardScene = new Scene(dashboardBox, 350, 600);
        dashboardButton.setOnAction(e -> {
            updateDashboard(pieChart, totalIncomeTextField, clothesTextField, jewelryTextField, beautyTextField,
                    foodTextField, pharmacyTextField, billsTextField);
            stage.setScene(dashboardScene);
            stage.setTitle("Dashboard");
        });

/////------------------------------BUDGET SCENE----------------------------------//////
        BorderPane budgetSceneRoot = new BorderPane();
        budgetSceneRoot.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect1111 = Color.web("#657da1", 1);//light blue for background

        // top
        StackPane topBudgetRoot = new StackPane();

        Rectangle rectangleT765 = new Rectangle();
        rectangleT765.setX(500);
        rectangleT765.setY(80);
        rectangleT765.setWidth(356);
        rectangleT765.setHeight(90);
        rectangleT765.setFill(blueRect1111);

        ////back//
        Image back = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\backarrow2.png");
        ImageView budgetBackImg = new ImageView(back);//
        budgetBackImg.setFitHeight(25);
        budgetBackImg.setFitWidth(25);
        StackPane.setMargin(budgetBackImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(budgetBackImg, Pos.CENTER_LEFT);

        Text budgetttText = new Text("Budget");
        budgetttText.setStyle("-fx-font: normal bold 14px 'serif'");
        budgetttText.setFill(Color.WHITE);

        StackPane.setAlignment(budgetttText, Pos.CENTER_LEFT);
        StackPane.setMargin(budgetttText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleT765, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchField456 = new TextField();
        searchField456.setFocusTraversable(false);
        searchField456.setPromptText("Search here ...");
        searchField456.setStyle("-fx-font: normal 10px 'serif'");
        searchField456.setPrefWidth(200);
        searchField456.setPrefHeight(25);
        Rectangle searchFieldShape3456 = new Rectangle();
        searchFieldShape3456.setWidth(200);
        searchFieldShape3456.setHeight(25);
        searchFieldShape3456.setArcWidth(25);
        searchFieldShape3456.setArcHeight(30);
        searchField456.setShape(searchFieldShape3456);

        Image searchImage4567 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\search.png");
        ImageView searchView765 = new ImageView(searchImage4567);
        searchView765.setFitHeight(19);
        searchView765.setFitWidth(22);

        StackPane.setMargin(searchView765, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainert735 = new StackPane();
        searchFieldContainert735.getChildren().addAll(searchField456, searchView765);

        HBox searchBox786 = new HBox(searchFieldContainert735);

        StackPane.setMargin(searchBox786, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage212 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\notices.png");
        ImageView noticeView121 = new ImageView(noticeImage212);
        noticeView121.setFitHeight(20);
        noticeView121.setFitWidth(15);

        Button noticeButton78 = new Button();
        noticeButton78.setGraphic(new StackPane(noticeView121));
        noticeButton78.setPrefSize(30, 30);
        noticeButton78.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButton78, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButton78, Pos.CENTER_RIGHT);

        ////list //////
        Image list1896 = new Image("file:C:\\Users\\yousr\\OneDrive\\UQU\\7th_semester\\AP\\list1.png");
        ImageView list1Img976 = new ImageView(list1896);//
        list1Img976.setFitHeight(18);
        list1Img976.setFitWidth(23);

        StackPane.setMargin(list1Img976, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img976, Pos.CENTER_RIGHT);

        topBudgetRoot.getChildren().addAll(rectangleT765, budgetttText, searchBox786,
                noticeButton78, list1Img976, budgetBackImg);
        budgetSceneRoot.setTop(topBudgetRoot);

        ///////////////budget///////////
        BorderPane budgetBorderPane = new BorderPane();

        VBox budgetBoxScene = new VBox(10);
        budgetBoxScene.setPadding(new Insets(25, 20, 20, 25));
        budgetBorderPane.setCenter(budgetBoxScene);
        // Big bold "Budget" text

        // Labels and TextFields for different categories
        //
        Label totalIncomeLabelBudget = new Label("Total Income:");
        totalIncomeTextField7896.setMaxWidth(100);
        totalIncomeTextField7896.setPromptText("Total Income amount");
        HBox totalIncomeBoxBudget = new HBox(5);
        totalIncomeBoxBudget.setPadding(new Insets(15, 0, 0, 60));
        totalIncomeBoxBudget.getChildren().addAll(totalIncomeLabelBudget, totalIncomeTextField7896);

        //
        budgetBoxScene.getChildren().addAll(totalIncomeBoxBudget);

        //
        HBox first2Box34 = new HBox(35);
        first2Box34.setPadding(new Insets(35, 0, 0, 0));
        VBox billsBox234 = new VBox(5);
        Label billsLabel2245 = new Label("Bills:");
        billsTextField54.setMaxWidth(100);
        billsTextField54.setPromptText("Bills amount");
        billsBox234.getChildren().addAll(billsLabel2245, billsTextField54);

        Label clothesLabel2542 = new Label("Clothes:");
        clothesTextField54.setMaxWidth(100);
        clothesTextField54.setPromptText("Clothes amount");
        VBox clothesBox45 = new VBox(5);
        clothesBox45.setPadding(new Insets(0, 0, 0, 40));

        clothesBox45.getChildren().addAll(clothesLabel2542, clothesTextField54);
        first2Box34.getChildren().addAll(billsBox234, clothesBox45);

        //
        budgetBoxScene.getChildren().add(first2Box34);

        //
        HBox sec2Box425 = new HBox(35);
        sec2Box425.setPadding(new Insets(15, 0, 0, 0));

        Label beautyLabel235 = new Label("Beauty:");
        beautyTextField36.setMaxWidth(100);
        beautyTextField36.setPromptText("Beauty amount");
        VBox beautyBox635 = new VBox(5);
        beautyBox635.getChildren().addAll(beautyLabel235, beautyTextField36);

        Label jewelryLabel2635 = new Label("Jewelry:");
        jewelryTextField362.setMaxWidth(100);
        jewelryTextField362.setPromptText("Jewelry amount");
        VBox jewelryBox3621 = new VBox(5);
        jewelryBox3621.setPadding(new Insets(0, 0, 0, 40));
        jewelryBox3621.getChildren().addAll(jewelryLabel2635, jewelryTextField362);

        sec2Box425.getChildren().addAll(beautyBox635, jewelryBox3621);

        budgetBoxScene.getChildren().add(sec2Box425);

        //
        HBox thi2Box5426 = new HBox(35);
        thi2Box5426.setPadding(new Insets(15, 0, 0, 0));

        Label foodLabel2466 = new Label("Food:");
        foodTextField3434.setMaxWidth(100);
        foodTextField3434.setPromptText("Food amount");
        VBox foodBox43444 = new VBox(5);
        foodBox43444.getChildren().addAll(foodLabel2466, foodTextField3434);

        Label pharmacyLabel24444 = new Label("Pharmacy:");
        pharmacyTextField33333.setMaxWidth(100);
        pharmacyTextField33333.setPromptText("Pharmacy amount");
        VBox pharmacyBox33333 = new VBox(5);
        pharmacyBox33333.setPadding(new Insets(0, 0, 0, 40));
        pharmacyBox33333.getChildren().addAll(pharmacyLabel24444, pharmacyTextField33333);

        thi2Box5426.getChildren().addAll(foodBox43444, pharmacyBox33333);

        Label stationaryLabel25432 = new Label("Stationary:");
        stationaryTextField544444.setMaxWidth(100);
        stationaryTextField544444.setPromptText("Stationary amount");
        VBox stationaryBox98765432 = new VBox();
        stationaryBox98765432.setPadding(new Insets(15, 0, 0, 90));
        stationaryBox98765432.getChildren().addAll(stationaryLabel25432, stationaryTextField544444);

        //
        VBox submitbutton76868 = new VBox();
        Button doneeButton88888 = new Button("SUBMIT");
        doneeButton88888.setStyle("-fx-background-radius: 5; -fx-background-color: #DB8BBD; ");
        submitbutton76868.getChildren().add(doneeButton88888);
        submitbutton76868.setPadding(new Insets(40, 0, 0, 210));

        budgetBoxScene.getChildren().addAll(thi2Box5426, stationaryBox98765432, submitbutton76868);

        budgetSceneRoot.setCenter(budgetBorderPane);
        Scene budgetScene = new Scene(budgetSceneRoot, 350, 600);
        stage.setTitle("Budget");

////------------------------------Customized Item Scene--------------------------------------------////
        //////// ------------action-----------------------------------------------------
        ImageView imageViewItemChoice = new ImageView();
        imageViewItemChoice.setFitWidth(300);
        imageViewItemChoice.setFitHeight(300);

        // Create a FileChooser
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif", "*.bmp", "*.jpeg")
        );

        // Create a Button to trigger the file selection
        ///// ------------------------------- ALL SCENES ACTIONS: --------------------------------------------///////
        //////////// Login ///////////
        root.getChildren().addAll(logo, LogInBox, SignUpBox);

        VBox rootLogIn = new VBox(20, loginTextBox, emailpassBox, texts, loginBox2, arrowBox);

        rootLogIn.setStyle("-fx-background-color: #c4d5de;");

        LogInB.setOnAction(event -> {
            Scene sceneLogIn = new Scene(rootLogIn, 350, 600);     // log in scene

            stage.setScene(sceneLogIn);
            stage.setTitle("Login");
        });

        arrowView.setOnMouseClicked(e -> {
            stage.setScene(scene);
            stage.setTitle("Welcome!");
        });

        /////////////////// Sign up ///////////////////////
        Scene sceneSignUp = new Scene(root2, 350, 600);    // sign up scene
        SignUpB.setOnAction(event -> {
            stage.setScene(sceneSignUp);
            stage.setTitle("Sign Up");
        });

        text2.setOnMouseClicked(e -> {
            stage.setScene(sceneSignUp);
            stage.setTitle("Sign Up");
        });

        ////////////////// HOME PAGE (main display) ////////////////////////
        SingUpB2.setOnAction(e -> {

            if (passwordField2.getText().length() > 8 && containsCapitalLetter(passwordField2.getText()) && isValidEmailDomain(emailTextField2.getText(), allowedDomain)) {

                // nameTextField2   emailTextField2 passwordField2 datePiker 
                // User(String name, String email, String password, String dob)
                user = new User(nameTextField2.getText(), emailTextField2.getText(), passwordField2.getText(), datePiker.getValue().toString());
                session = HibernateUtil.getSessionFactory().openSession();
                Transaction tx = session.beginTransaction();
                //insert
                int user1 = (Integer) session.save(user);
                System.out.println("inserted User ");
                tx.commit();
                session.close();

                session = HibernateUtil.getSessionFactory().openSession();
                List<User> uList5 = null;
                Query q5 = session.createQuery("from User");
                uList5 = q5.list();
                session.close();

                for (User u : uList5) {
                    if (emailTextField2.getText().equalsIgnoreCase(u.getEmail())) {
                        UserID = u.getUserID();
                    }
                }
                System.out.println("IDDD: "+ UserID);

                
                wishlist = new Wishlist(UserID);
                session = HibernateUtil.getSessionFactory().openSession();
                Transaction tx5 = session.beginTransaction();
                int idf = (Integer) session.save(wishlist);
                tx5.commit();
                session.close();
                session = HibernateUtil.getSessionFactory().openSession();
                List<Wishlist> wList = null;
                Query q9 = session.createQuery("from Wishlist");
                wList = q9.list();
                session.close();
                if (!wList.isEmpty()) {
                    for (Wishlist w : wList) {
                        if (UserID == w.getUserID()) {
                            wishlistid = w.getWishlistID();
                        }
                    }
                }

/// setListID(ListScene.list.getID());
                homePageScene.start(stage);
            }
        });
        
//         // retrieving all the table 
//              int id = 0;
//               session = HibernateUtil.getSessionFactory().openSession();
//               List<Cake> cList = null;
//               String str = "from Cake";
//               Query q = session.createQuery(str);
//               cList = q.list();
//               session.close();
//               
//                for (Cake c: cList) {
//                    if ( lvCustomersName.getItems().get(i).equals(c.getCustomerName()) 
//                            && lvCustomersNumber.getItems().get(i).equals(c.getCustomerNumber()) 
//                            && lvDate.getItems().get(i).equals(c.getDatee()) 
//                            &&  lvCakeDiscrption.getItems().get(i).equals(c.getCakeDescription()) 
//                            &&  lvType.getItems().get(i).equals(c.getDeliveryORpickup())) {
//                       // the correct id
//                        id = c.getOrderID();
//                    } }


 

        loginB2.setOnAction(e -> {
            if (passwordField.getText().length() > 8 && containsCapitalLetter(passwordField.getText()) && isValidEmailDomain(emailTextField.getText(), allowedDomain)) {
                 // retrieving all the table 
                session = HibernateUtil.getSessionFactory().openSession();
                List<User> uList = null;
                String str = "from User";
                Query q = session.createQuery(str);
                uList = q.list();
                session.close();
                if (!uList.isEmpty()) {

                    for (User u : uList) {
                        if (passwordField.getText().equalsIgnoreCase(u.getPassword()) && emailTextField.getText().equalsIgnoreCase(u.getEmail())) {
                            user = new User();
                            user.setUserID(u.getUserID());
                            user.setEmail(u.getEmail());
                            user.setPassword(u.getPassword());
                            user.setName(u.getName());
                            user.setDob(u.getDob());
                            wishlist = new Wishlist(UserID);
                
                            session = HibernateUtil.getSessionFactory().openSession();
                            List<Wishlist> wList = null;
                            Query q9 = session.createQuery("from Wishlist");
                            wList = q9.list();
                            session.close();
                            if (!wList.isEmpty()) {
                                for (Wishlist w : wList) {
                                    if (UserID == w.getUserID()) {
                                        wishlistid = w.getWishlistID();
                                        wishlist.setWishlistID(wishlistid);
                                        
                        }
                    }
                }
                            
                            homePageScene.start(stage);
                        } else{
                            showAlert("Invalid !", "Username or password is incorrect.");
                        }

                    }
                } else {
                      showAlert("Invalid !", "Username or password is incorrect.");
                }

                
                
            }
        });

        /////////////////////////dashboard////////////////
        dashboardButton.setOnAction(e -> {
            stage.setScene(dashboardScene);
            stage.setTitle("Dashboard");
        });

        homeView2.setOnMouseClicked(e -> {
            homePageScene.start(new Stage());
        });

        //----------------------------SHOPS SCENES ------------////
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        //// SIDEBAR ACTIONS
        Scene sidebarScene = new Scene(borderPane, 350, 600);

        // Set actions for the buttons
        homeButton2.setOnAction(e -> {
            homePageScene.start(new Stage());
        });

        dashboardButton.setOnAction(e -> {
            stage.setScene(dashboardScene);

        });

        settingsButton.setOnAction(e -> {
            // Set scene for the Settings
        });

        logoutButton.setOnAction(e -> {
            stage.setScene(scene);
        });

    }

    public static void main(String[] args) {
        launch();
    }

    private VBox sidebar;

    // Method to toggle the sidebar in
    private void toggleSidebar(TranslateTransition transition) {
        if (sidebar.getTranslateX() != 0) {
            transition.setRate(1);
            transition.play();
        } else {
            transition.setRate(-1);
            transition.play();
        }
    }

    // Method to toggle the sidebar out (close it)
    private boolean containsCapitalLetter(String text) {
        // Check if the text contains at least one capital letter
        for (char c : text.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    private boolean isValidEmailDomain(String email, String allowedDomain) {
        // Check if the email domain is equal to the allowed domain
        Pattern pattern = Pattern.compile("@(.+)$");
        Matcher matcher = pattern.matcher(email);
        if (matcher.find()) {
            return matcher.group(1).equalsIgnoreCase(allowedDomain);
        }
        return false;
    }

    public static double calculatePercentage(double value, double total) {
        double percentage = (value / total) * 100;
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        String formattedPercentage = decimalFormat.format(percentage);

        return Double.parseDouble(formattedPercentage);
    }

    TextField pharmacyTextField33333 = new TextField();
    TextField foodTextField3434 = new TextField();
    TextField jewelryTextField362 = new TextField();
    TextField beautyTextField36 = new TextField();
    TextField clothesTextField54 = new TextField();
    TextField billsTextField54 = new TextField();
    TextField totalIncomeTextField7896 = new TextField();
    TextField stationaryTextField544444 = new TextField();

    Label incomelbl;
    ProgressBar progressBar;

    private void updatePieChartData(PieChart pieChart, TextField[] textFields) {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Clothes", Double.parseDouble(textFields[1].getText())),
                new PieChart.Data("Beauty", Double.parseDouble(textFields[2].getText())),
                new PieChart.Data("Jewelry", Double.parseDouble(textFields[3].getText())),
                new PieChart.Data("Food", Double.parseDouble(textFields[4].getText())),
                new PieChart.Data("Pharmacy", Double.parseDouble(textFields[5].getText())),
                new PieChart.Data("Bills", Double.parseDouble(textFields[6].getText()))
        );

        //cloth,beauty,jew,food,ph,bill
        // Update PieChart data
        pieChart.setData(pieChartData);

        // Update slice labels with percentages
        pieChart.getData().forEach(data -> {
            data.setName(data.getName() + "\n" + calculatePercentage(data.getPieValue(), Double.parseDouble(textFields[0].getText())) + "%");
        });

        // Customize colors
        String[] colors = {"#fbf3f8", "#c4d5de", "#bca9c6", "#cd5ea2", "#657da1", "#c4d5de"};
        for (int i = 0; i < pieChartData.size(); i++) {
            PieChart.Data data = pieChartData.get(i);
            data.getNode().setStyle("-fx-pie-color: " + colors[i] + ";");
        }

    }

    private void updateDashboard(PieChart pieChart, TextField... textFields) {
        try {
            double income = Double.parseDouble(textFields[0].getText());
            double total = Double.parseDouble(textFields[1].getText())
                    + Double.parseDouble(textFields[2].getText())
                    + Double.parseDouble(textFields[3].getText())
                    + Double.parseDouble(textFields[4].getText())
                    + Double.parseDouble(textFields[5].getText());

            // Update PieChart and other relevant components
            updatePieChartData(pieChart, textFields);
            updateProgressBar(progressBar, income, total);
            updateTotalIncomeLabel(incomelbl, income);
        } catch (NumberFormatException ex) {
            // Handle the exception (e.g., show an error message)
            System.out.println("Invalid input. Please enter valid numerical values in the text fields.");
        }
    }

    private void updateProgressBar(ProgressBar progressBar, double income, double total) {
        double progress = total / income;
        progress = max(0, min(progress, 1));
        progressBar.setProgress(progress);
    }

    private void updateTotalIncomeLabel(Label incomelbl, double income) {
        incomelbl.setText("Total Income:\n" + "$" + income);
    }

    TextField pharmacyTextField = new TextField();
    TextField foodTextField = new TextField();
    TextField jewelryTextField = new TextField();
    TextField beautyTextField = new TextField();
    TextField clothesTextField = new TextField();
    TextField billsTextField = new TextField();
    TextField totalIncomeTextField = new TextField();

    TextField[] textFields = {totalIncomeTextField,
        clothesTextField,
        beautyTextField,
        jewelryTextField,
        foodTextField,
        pharmacyTextField,
        billsTextField};
    
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);

        alert.showAndWait();
    }

}
