/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */


import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.ColorPicker;

/**
 * JavaFX App
 */
public class ColorSettingsScene extends Application {

    Color blueRectD = Color.web("#657da1", 1);//Dark blue
    Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
    Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink
    Color blueRectL = Color.web("#c4d5de", 1); //Light blue
    Rectangle rectangleTColor = new Rectangle();

    @Override
    public void start(Stage stage) {

        FlowPane ColorPane = new FlowPane();

        ///////////////////////////////////////header
        StackPane ColorSetting = new StackPane();

        rectangleTColor.setX(500);
        rectangleTColor.setY(80);
        rectangleTColor.setWidth(356);
        rectangleTColor.setHeight(90);
        rectangleTColor.setFill(blueRectD);

        ////back//
        Image back = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);

        Text SettingText = new Text("Colors Setting");
        Font font = Font.font("Poppins Medium", 32);
        SettingText.setFont(font);
        SettingText.setStyle("-fx-font-weight: bold;");
        SettingText.setFill(Color.WHITE);

        StackPane.setAlignment(SettingText, Pos.CENTER);
        StackPane.setMargin(SettingText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTColor, new Insets(0, 0, 0, -4));

        ColorSetting.getChildren().addAll(rectangleTColor, SettingText, backImg);

        ///////////////////////////////////////////
        //background
        VBox changeColorsPane = new VBox();
        changeColorsPane.setStyle("-fx-background-color: #c4d5de;");

        Text setupColor = new Text("Setup Color");
        setupColor.setFill(PinkRectD);
        setupColor.setFont(new Font("Poppins Medium", 25));
        setupColor.setStyle("-fx-font-weight: bold;");

        HBox setupColorLabel = new HBox(50);
        setupColorLabel.setPadding(new Insets(20, 20, 20, 30));
        setupColorLabel.setAlignment(Pos.CENTER);
        setupColorLabel.getChildren().addAll(setupColor);

        HBox hBoxHeading = new HBox();

        Text HeadingText = new Text("Heading");
        HeadingText.setFill(PinkRectD);
        HeadingText.setFont(new Font("Poppins Medium", 10));
        HeadingText.setStyle("-fx-font-weight: bold;");

        HBox HeadingColor = new HBox(10);
        HeadingColor.setPadding(new Insets(20, 20, 20, 30));

        Rectangle HeadingRECold = new Rectangle();
        HeadingRECold.setHeight(20);
        HeadingRECold.setWidth(50);
        HeadingRECold.setFill(PinkRectD);
        HeadingRECold.setStroke(Color.BLACK);

        Image ArowwColorImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\png-transparent-arrow.png");
        ImageView ArowwColor = new ImageView(ArowwColorImage);
        ArowwColor.setFitHeight(19);
        ArowwColor.setFitWidth(22);

        Rectangle HeadingRECnew = new Rectangle();
        HeadingRECnew.setHeight(20);
        HeadingRECnew.setWidth(50);
        HeadingRECnew.setFill(Color.WHITE);
        HeadingRECnew.setStroke(Color.BLACK);

        ColorPicker HeadingColorChoose = new ColorPicker();

        HeadingColor.getChildren().addAll(HeadingRECold, ArowwColor, HeadingRECnew, HeadingColorChoose);

        hBoxHeading.setPadding(new Insets(20, 20, 20, 80));
        hBoxHeading.setAlignment(Pos.CENTER);
        hBoxHeading.getChildren().addAll(HeadingText);

        //////////////
        HBox hBoxbacground = new HBox();

        Text BackGroundText = new Text("Background");
        BackGroundText.setFill(PinkRectD);
        BackGroundText.setFont(new Font("Poppins Medium", 10));
        BackGroundText.setStyle("-fx-font-weight: bold;");

        HBox BackGroundColor = new HBox(10);
        BackGroundColor.setPadding(new Insets(20, 20, 20, 30));

        Rectangle BacgroundRECold = new Rectangle();
        BacgroundRECold.setHeight(20);
        BacgroundRECold.setWidth(50);
        BacgroundRECold.setFill(blueRectL);
        BacgroundRECold.setStroke(Color.BLACK);
        //Image ArowwColorImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\png-transparent-arrow.png");
        ImageView ArowwColorBackground = new ImageView(ArowwColorImage);
        ArowwColorBackground.setFitHeight(19);
        ArowwColorBackground.setFitWidth(22);

        Rectangle backgroundRECnew = new Rectangle();
        backgroundRECnew.setHeight(20);
        backgroundRECnew.setWidth(50);
        backgroundRECnew.setFill(Color.WHITE);
        backgroundRECnew.setStroke(Color.BLACK);
        ColorPicker BackgroundColorChoose = new ColorPicker();

        BackGroundColor.getChildren().addAll(BacgroundRECold, ArowwColorBackground, backgroundRECnew, BackgroundColorChoose);

        hBoxbacground.setPadding(new Insets(20, 20, 20, 80));
        hBoxbacground.setAlignment(Pos.CENTER);
        hBoxbacground.getChildren().addAll(BackGroundText);
        ///////////
        //////////////
        HBox hBoxHeaderFooter = new HBox();

        Text HeaderFooterText = new Text("Header/Footer");
        HeaderFooterText.setFill(PinkRectD);
        HeaderFooterText.setFont(new Font("Poppins Medium", 10));
        HeaderFooterText.setStyle("-fx-font-weight: bold;");

        HBox HeaderFooterColor = new HBox(10);
        HeaderFooterColor.setPadding(new Insets(20, 20, 20, 30));

        Rectangle HeaderFooterRECold = new Rectangle();
        HeaderFooterRECold.setHeight(20);
        HeaderFooterRECold.setWidth(50);
        HeaderFooterRECold.setFill(blueRectD);
        HeaderFooterRECold.setStroke(Color.BLACK);
        //Image ArowwColorImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\png-transparent-arrow.png");
        ImageView ArowwColorHeaderFooter = new ImageView(ArowwColorImage);
        ArowwColorHeaderFooter.setFitHeight(19);
        ArowwColorHeaderFooter.setFitWidth(22);

        Rectangle HeaderFooterRECnew = new Rectangle();
        HeaderFooterRECnew.setHeight(20);
        HeaderFooterRECnew.setWidth(50);
        HeaderFooterRECnew.setFill(Color.WHITE);
        HeaderFooterRECnew.setStroke(Color.BLACK);

        ColorPicker HeaderFooterColorChoose = new ColorPicker();

        HeaderFooterColor.getChildren().addAll(HeaderFooterRECold, ArowwColorHeaderFooter, HeaderFooterRECnew, HeaderFooterColorChoose);

        hBoxHeaderFooter.setPadding(new Insets(20, 20, 20, 80));
        hBoxHeaderFooter.setAlignment(Pos.CENTER);
        hBoxHeaderFooter.getChildren().addAll(HeaderFooterText);
        ///////////
        //REset botton
        HBox Reset = new HBox(10);
        Reset.setAlignment(Pos.CENTER);
        Button ResetColor = new Button("Reset Colors");
        ResetColor.setStyle("-fx-background-color: #cd5ea2; -fx-text-fill: #ffffff;");

        ResetColor.setPrefWidth(150); // to enlarge the button
        ResetColor.setPrefHeight(30); // to enlarge the button
        ResetColor.setFocusTraversable(false);
        Reset.getChildren().addAll(ResetColor);

        changeColorsPane.getChildren().addAll(setupColorLabel, hBoxHeading, HeadingColor, hBoxbacground, BackGroundColor, hBoxHeaderFooter, HeaderFooterColor, Reset);

        ColorPane.getChildren().addAll(ColorSetting, changeColorsPane);
        ColorPane.setStyle("-fx-background-color: #c4d5de;");

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        //Action
        //Heading
        HeadingColorChoose.setOnAction(event -> {
            Color DarkPink = HeadingColorChoose.getValue();
            setupColor.setFill(DarkPink);
            HeadingText.setFill(DarkPink);
            HeadingRECnew.setFill(DarkPink);
            BackGroundText.setFill(DarkPink);
            HeaderFooterText.setFill(DarkPink);
            ResetColor.setStyle("-fx-background-color: #" + toHex(DarkPink));

        });
        //background
        BackgroundColorChoose.setOnAction(event -> {
            Color LightBlue = BackgroundColorChoose.getValue();
            backgroundRECnew.setFill(LightBlue);
            ColorPane.setStyle("-fx-background-color: #" + toHex(LightBlue));
            changeColorsPane.setStyle("-fx-background-color: #" + toHex(LightBlue));
            Reset.setStyle("-fx-background-color: #" + toHex(LightBlue));
            hBoxHeaderFooter.setStyle("-fx-background-color: #" + toHex(LightBlue));
            HeaderFooterColor.setStyle("-fx-background-color: #" + toHex(LightBlue));
            BackGroundColor.setStyle("-fx-background-color: #" + toHex(LightBlue));
            changeColorsPane.setStyle("-fx-background-color: #" + toHex(LightBlue));

        });
        //Header,Footer

        HeaderFooterColorChoose.setOnAction(event -> {
            Color DarkBlue = HeaderFooterColorChoose.getValue();
            rectangleTColor.setFill(DarkBlue);
            HeaderFooterRECnew.setFill(DarkBlue);

        });
        ////////////////////////////////////////////////////////////////////////
        //ResetButton Action

        ResetColor.setOnAction(e -> {

            //pink
            setupColor.setFill(PinkRectD);
            HeadingText.setFill(PinkRectD);
            HeadingRECnew.setFill(PinkRectD);
            BackGroundText.setFill(PinkRectD);
            HeaderFooterText.setFill(PinkRectD);
            ResetColor.setStyle("-fx-background-color: #" + toHex(PinkRectD));

            //DarkBlue
            rectangleTColor.setFill(blueRectD);
            HeaderFooterRECnew.setFill(blueRectD);

            //LightBlue
            backgroundRECnew.setFill(blueRectL);
            ColorPane.setStyle("-fx-background-color: #" + toHex(blueRectL));
            changeColorsPane.setStyle("-fx-background-color: #" + toHex(blueRectL));
            hBoxHeaderFooter.setStyle("-fx-background-color: #" + toHex(blueRectL));
            HeaderFooterColor.setStyle("-fx-background-color: #" + toHex(blueRectL));
            BackGroundColor.setStyle("-fx-background-color: #" + toHex(blueRectL));
            Reset.setStyle("-fx-background-color: #" + toHex(blueRectL));

        });
        ///////////////////////////////////////////////////////////////////////////////

        var scene = new Scene(ColorPane, 350, 600);
        stage.setScene(scene);
        stage.show();
    }

    private String toHex(Color color) {
        // Convert the RGB values to hexadecimal
        int r = (int) (color.getRed() * 255);
        int g = (int) (color.getGreen() * 255);
        int b = (int) (color.getBlue() * 255);

        // Format the hexadecimal string
        return String.format("%02X%02X%02X", r, g, b);
    }


}
