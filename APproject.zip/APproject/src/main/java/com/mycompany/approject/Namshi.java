/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.approject;

/**
 *
 * @author ghadi
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class Namshi extends Application {


    @Override
    public void start(Stage primaryStage) {
        BorderPane namshiPane = new BorderPane();
        namshiPane.setStyle("-fx-background-color: #c4d5de;");
        Color blueRect = Color.web("#657da1", 1);//light blue for background
        Color PinkRectD = Color.web("#cd5ea2", 1);//dark pink
        Color PinkRectL = Color.web("#DB8BBD", 1);//Light pink

        // top
        StackPane topnamshiroot = new StackPane();

        Rectangle rectangleTnamshi = new Rectangle();
        rectangleTnamshi.setX(500);
        rectangleTnamshi.setY(80);
        rectangleTnamshi.setWidth(356);
        rectangleTnamshi.setHeight(90);
        rectangleTnamshi.setFill(blueRect);
        
        ////back//
        Image back = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\backarrow2.png");
        ImageView backImg = new ImageView(back);//
        backImg.setFitHeight(25);
        backImg.setFitWidth(25);
        StackPane.setMargin(backImg, new Insets(-50, 0, 0, 14));
        StackPane.setAlignment(backImg, Pos.CENTER_LEFT);
       

        Text namshiText = new Text("Namshi");
        namshiText.setStyle("-fx-font: normal bold 14px 'serif'");
        namshiText.setFill(Color.WHITE);

        StackPane.setAlignment(namshiText, Pos.CENTER_LEFT);
        StackPane.setMargin(namshiText, new Insets(-15, 0, 0, 30));
        StackPane.setMargin(rectangleTnamshi, new Insets(0, 0, 0, -4));

        ///search///
        TextField searchFieldnamshi = new TextField();
        searchFieldnamshi.setFocusTraversable(false);
        searchFieldnamshi.setPromptText("Search here ...");
        searchFieldnamshi.setStyle("-fx-font: normal 10px 'serif'");
        searchFieldnamshi.setPrefWidth(200);
        searchFieldnamshi.setPrefHeight(25);
        Rectangle searchFieldShape = new Rectangle();
        searchFieldShape.setWidth(200);
        searchFieldShape.setHeight(25);
        searchFieldShape.setArcWidth(25);
        searchFieldShape.setArcHeight(30);
        searchFieldnamshi.setShape(searchFieldShape);

        Image searchImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\search.jpg");
        ImageView searchViewnamshi = new ImageView(searchImage);
        searchViewnamshi.setFitHeight(19);
        searchViewnamshi.setFitWidth(22);

        StackPane.setMargin(searchViewnamshi, new Insets(0, 0, 0, 170));
        StackPane searchFieldContainernamshi = new StackPane();
        searchFieldContainernamshi.getChildren().addAll(searchFieldnamshi, searchViewnamshi);

        HBox searchBoxnamshi = new HBox(searchFieldContainernamshi);

        StackPane.setMargin(searchBoxnamshi, new Insets(34, 0, 0, 30));

        ////NOTICE/////
        Image noticeImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\notices.png");
        ImageView noticeView = new ImageView(noticeImage);
        noticeView.setFitHeight(20);
        noticeView.setFitWidth(15);

        Button noticeButtonnamshi = new Button();
        noticeButtonnamshi.setGraphic(new StackPane(noticeView));
        noticeButtonnamshi.setPrefSize(30, 30);
        noticeButtonnamshi.setStyle("-fx-background-color: white; -fx-background-radius: 60;");

        StackPane.setMargin(noticeButtonnamshi, new Insets(-20, 20, 0, 0));
        StackPane.setAlignment(noticeButtonnamshi, Pos.CENTER_RIGHT);

        ////list //////
        Image list1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list1.png");
        ImageView list1Img = new ImageView(list1);//
        list1Img.setFitHeight(18);
        list1Img.setFitWidth(23);

        StackPane.setMargin(list1Img, new Insets(40, 25, 0, 0));
        StackPane.setAlignment(list1Img, Pos.CENTER_RIGHT);

        topnamshiroot.getChildren().addAll(rectangleTnamshi, namshiText, searchBoxnamshi,
                 noticeButtonnamshi, list1Img ,backImg);
        namshiPane.setTop(topnamshiroot);

        //---------- center -----------//
        VBox centerBoxnamshi = new VBox();
        //centerBox.setStyle("-fx-border-color: red;");
        centerBoxnamshi.setStyle("-fx-background-color: #c4d5de;");

        // spending rectangle
        StackPane centerSpendingnamshi = new StackPane();

        Rectangle rectProduct1namshi = new Rectangle(200, 70);
        rectProduct1namshi.setFill(PinkRectD);
        rectProduct1namshi.setArcWidth(10);
        rectProduct1namshi.setArcHeight(10);
 

        Label spendingLbnamshi = new Label("Total Spending\n\t138,265");
        spendingLbnamshi.setStyle("-fx-font: normal bold 16px 'serif'; -fx-text-fill: white; ");
        spendingLbnamshi.setPadding(new Insets(0, 0, 25, 0));
        

        centerSpendingnamshi.setPadding(new Insets(20, 55, 0, 60));
        centerSpendingnamshi.getChildren().addAll(rectProduct1namshi, spendingLbnamshi);

        //items recnagles 
        //first 2
        HBox itemsBoxnamshi = new HBox(40);

        itemsBoxnamshi.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnamshi1 = new StackPane();
        Rectangle rectProductnamshi1 = new Rectangle(110, 155);
        rectProductnamshi1.setFill(PinkRectL);
        rectProductnamshi1.setArcWidth(10);
        rectProductnamshi1.setArcHeight(10);

        Rectangle SmallrectProductnamshi1 = new Rectangle(110, 30);
        SmallrectProductnamshi1.setFill(PinkRectD);
        SmallrectProductnamshi1.setArcWidth(10);
        SmallrectProductnamshi1.setArcHeight(10);
        SmallrectProductnamshi1.setTranslateY(62);

        Image namshi1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\TeaPot1.PNG");
        ImageView namshiImg1 = new ImageView(namshi1);//
        namshiImg1.setFitHeight(120);
        namshiImg1.setFitWidth(120);
        namshiImg1.setTranslateY(-31);

        Label namshi1Lb = new Label("Floral Teapot \n87SR");
        namshi1Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi1Lb.setPadding(new Insets(0, 50, 30, 0));
        namshi1Lb.setTranslateY(45);

        Image listimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listbtn1view1 = new ImageView(listimg1);//
        listbtn1view1.setFitHeight(68);
        listbtn1view1.setFitWidth(68);

        Button listButton1namshi = new Button();
        listButton1namshi.setGraphic(new StackPane(listbtn1view1));
        listButton1namshi.setPrefSize(35, 35);
        listButton1namshi.setTranslateY(65);
        listButton1namshi.setTranslateX(20);
        listButton1namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Image wishlistimg1 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView1 = new ImageView(wishlistimg1);
        wishlistView1.setFitHeight(50);
        wishlistView1.setFitWidth(50);
        
        Button wishlistButton1 = new Button();
        wishlistButton1.setGraphic(new StackPane(wishlistView1));
        wishlistButton1.setPrefSize(35, 35);
        wishlistButton1.setTranslateY(61);
        wishlistButton1.setTranslateX(-20);
        wishlistButton1.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsnamshi1.getChildren().addAll(rectProductnamshi1, SmallrectProductnamshi1,
                 namshiImg1, namshi1Lb, listButton1namshi , wishlistButton1);

        ////////////////////////////////////////////////////////////
        StackPane rectitemsnamshi2 = new StackPane();
        Rectangle rectProductnamshi2 = new Rectangle(110, 155);
        rectProductnamshi2.setFill(PinkRectL);
        rectProductnamshi2.setArcWidth(10);
        rectProductnamshi2.setArcHeight(10);

        Rectangle SmallrectProductnamshi2 = new Rectangle(110, 30);
        SmallrectProductnamshi2.setFill(PinkRectD);
        SmallrectProductnamshi2.setArcWidth(10);
        SmallrectProductnamshi2.setArcHeight(10);
        SmallrectProductnamshi2.setTranslateY(62);

        Image namshi2 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\spoon2.PNG");
        ImageView namshiImg2 = new ImageView(namshi2);//
        namshiImg2.setFitHeight(90);
        namshiImg2.setFitWidth(100);
        namshiImg2.setTranslateY(-28);

        Label namshi2Lb = new Label("Measuring Spoon\n44SR");
        namshi2Lb.setStyle("-fx-font: normal  9px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi2Lb.setPadding(new Insets(0, 0, 30, 0));
        namshi2Lb.setTranslateY(45);
        
        ImageView listbtn1view2 = new ImageView(listimg1);//
        listbtn1view2.setFitHeight(68);
        listbtn1view2.setFitWidth(68);
        
        ImageView wishlistView2 = new ImageView(wishlistimg1);
        wishlistView2.setFitHeight(50);
        wishlistView2.setFitWidth(50);
        
        Button listButton2namshi = new Button();
        listButton2namshi.setGraphic(new StackPane(listbtn1view2));
        listButton2namshi.setPrefSize(35, 35);
        listButton2namshi.setTranslateY(65);
        listButton2namshi.setTranslateX(20);
        listButton2namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton2namshi = new Button();
        wishlistButton2namshi.setGraphic(new StackPane(wishlistView2));
        wishlistButton2namshi.setPrefSize(35, 35);
        wishlistButton2namshi.setTranslateY(61);
        wishlistButton2namshi.setTranslateX(-20);
        wishlistButton2namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsnamshi2.getChildren().addAll(rectProductnamshi2, SmallrectProductnamshi2,
                 namshiImg2, namshi2Lb ,  wishlistButton2namshi ,listButton2namshi);

        itemsBoxnamshi.getChildren().addAll(rectitemsnamshi1, rectitemsnamshi2);

        // second 2
        HBox itemsBox2namshi = new HBox(40);

        itemsBox2namshi.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnamshi3 = new StackPane();
        Rectangle rectProductnamshi3 = new Rectangle(110, 155);
        rectProductnamshi3.setFill(PinkRectL);
        rectProductnamshi3.setArcWidth(10);
        rectProductnamshi3.setArcHeight(10);

        Rectangle SmallrectProductnamshi3 = new Rectangle(110, 30);
        SmallrectProductnamshi3.setFill(PinkRectD);
        SmallrectProductnamshi3.setArcWidth(10);
        SmallrectProductnamshi3.setArcHeight(10);
        SmallrectProductnamshi3.setTranslateY(62);

        Image namshi3 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\mug3.PNG");
        ImageView namshiImg3 = new ImageView(namshi3);//
        namshiImg3.setFitHeight(90);
        namshiImg3.setFitWidth(75);
        namshiImg3.setTranslateY(-38);

        Label namshi3Lb = new Label("Floral Mug\n39SR");
        namshi3Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi3Lb.setPadding(new Insets(0, 0, 30, 0));
        namshi3Lb.setTranslateY(34);
        
        ImageView listbtn1view3namshi = new ImageView(listimg1);//
        listbtn1view3namshi.setFitHeight(68);
        listbtn1view3namshi.setFitWidth(68);
        
        ImageView wishlistView3namshi = new ImageView(wishlistimg1);
        wishlistView3namshi.setFitHeight(50);
        wishlistView3namshi.setFitWidth(50);
        
        Button listButton3namshi = new Button();
        listButton3namshi.setGraphic(new StackPane(listbtn1view3namshi));
        listButton3namshi.setPrefSize(35, 35);
        listButton3namshi.setTranslateY(65);
        listButton3namshi.setTranslateX(20);
        listButton3namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton3namshi = new Button();
        wishlistButton3namshi.setGraphic(new StackPane(wishlistView3namshi));
        wishlistButton3namshi.setPrefSize(35, 35);
        wishlistButton3namshi.setTranslateY(61);
        wishlistButton3namshi.setTranslateX(-20);
        wishlistButton3namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");

        rectitemsnamshi3.getChildren().addAll(rectProductnamshi3, SmallrectProductnamshi3,
                 namshiImg3, namshi3Lb , wishlistButton3namshi , listButton3namshi);
        
        //////////////////////////////////////////////////
        StackPane rectitemsnamshi4 = new StackPane();
        Rectangle rectProductnamshi4 = new Rectangle(110, 155);
        rectProductnamshi4.setFill(PinkRectL);
        rectProductnamshi4.setArcWidth(10);
        rectProductnamshi4.setArcHeight(10);

        Rectangle SmallrectProductnamshi4 = new Rectangle(110, 30);
        SmallrectProductnamshi4.setFill(PinkRectD);
        SmallrectProductnamshi4.setArcWidth(10);
        SmallrectProductnamshi4.setArcHeight(10);
        SmallrectProductnamshi4.setTranslateY(62);

        Image namshi4 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\tray4.PNG");
        ImageView namshiImg4 = new ImageView(namshi4);//
        namshiImg4.setFitHeight(70);
        namshiImg4.setFitWidth(60);
        namshiImg4.setTranslateY(-35);

        Label namshi4Lb = new Label("Ceramic Trinket\nTray\n54SR");
        namshi4Lb.setStyle("-fx-font: normal  10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi4Lb.setTranslateY(20);
        
        ImageView listbtn1view4namshi = new ImageView(listimg1);//
        listbtn1view4namshi.setFitHeight(68);
        listbtn1view4namshi.setFitWidth(68);
        
        ImageView wishlistView4namshi = new ImageView(wishlistimg1);
        wishlistView4namshi.setFitHeight(50);
        wishlistView4namshi.setFitWidth(50);
        
        Button listButton4namshi = new Button();
        listButton4namshi.setGraphic(new StackPane(listbtn1view4namshi));
        listButton4namshi.setPrefSize(35, 35);
        listButton4namshi.setTranslateY(65);
        listButton4namshi.setTranslateX(20);
        listButton4namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton4namshi = new Button();
        wishlistButton4namshi.setGraphic(new StackPane(wishlistView4namshi));
        wishlistButton4namshi.setPrefSize(35, 35);
        wishlistButton4namshi.setTranslateY(61);
        wishlistButton4namshi.setTranslateX(-20);
        wishlistButton4namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi4.getChildren().addAll(rectProductnamshi4, SmallrectProductnamshi4,
                 namshiImg4, namshi4Lb, wishlistButton4namshi, listButton4namshi);

        itemsBox2namshi.getChildren().addAll(rectitemsnamshi3, rectitemsnamshi4);

        // third 2 /////////////////
        HBox itemsBox3namshi = new HBox(40);

        itemsBox3namshi.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnamshi5 = new StackPane();
        Rectangle rectProductnamshi5 = new Rectangle(110, 155);
        rectProductnamshi5.setFill(PinkRectL);
        rectProductnamshi5.setArcWidth(10);
        rectProductnamshi5.setArcHeight(10);

        Rectangle SmallrectProductnamshi5 = new Rectangle(110, 30);
        SmallrectProductnamshi5.setFill(PinkRectD);
        SmallrectProductnamshi5.setArcWidth(10);
        SmallrectProductnamshi5.setArcHeight(10);
        SmallrectProductnamshi5.setTranslateY(62);

        Image namshi5 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\foundation5.PNG");
        ImageView namshiImg5 = new ImageView(namshi5);//
        namshiImg5.setFitHeight(80);
        namshiImg5.setFitWidth(80);
        namshiImg5.setTranslateY(-36);

        Label namshi5Lb = new Label("Hollywood Filter\n250SR");
        namshi5Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi5Lb.setPadding(new Insets(0, 25, 25, 0));
        namshi5Lb.setTranslateY(34);
        
        
        ImageView listbtn1view5namshi = new ImageView(listimg1);//
        listbtn1view5namshi.setFitHeight(68);
        listbtn1view5namshi.setFitWidth(68);
        
        ImageView wishlistView5namshi = new ImageView(wishlistimg1);
        wishlistView5namshi.setFitHeight(50);
        wishlistView5namshi.setFitWidth(50);
        
        Button listButton5namshi = new Button();
        listButton5namshi.setGraphic(new StackPane(listbtn1view5namshi));
        listButton5namshi.setPrefSize(35, 35);
        listButton5namshi.setTranslateY(65);
        listButton5namshi.setTranslateX(20);
        listButton5namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton5namshi = new Button();
        wishlistButton5namshi.setGraphic(new StackPane(wishlistView5namshi));
        wishlistButton5namshi.setPrefSize(35, 35);
        wishlistButton5namshi.setTranslateY(61);
        wishlistButton5namshi.setTranslateX(-20);
        wishlistButton5namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi5.getChildren().addAll(rectProductnamshi5, SmallrectProductnamshi5,
                 namshiImg5, namshi5Lb, wishlistButton5namshi, listButton5namshi);
        //////////////////////////////////////////////
        StackPane rectitemsnamshi6 = new StackPane();
        Rectangle rectProductnamshi6 = new Rectangle(110, 155);
        rectProductnamshi6.setFill(PinkRectL);
        rectProductnamshi6.setArcWidth(10);
        rectProductnamshi6.setArcHeight(10);

        Rectangle SmallrectProductnamshi6 = new Rectangle(110, 30);
        SmallrectProductnamshi6.setFill(PinkRectD);
        SmallrectProductnamshi6.setArcWidth(10);
        SmallrectProductnamshi6.setArcHeight(10);
        SmallrectProductnamshi6.setTranslateY(62);

        Image namshi6 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\blusher6.PNG");
        ImageView namshiImg6 = new ImageView(namshi6);//
        namshiImg6.setFitHeight(100);
        namshiImg6.setFitWidth(100);
        namshiImg6.setTranslateY(-35);

        Label namshi6Lb = new Label("Cheek To Chic\n210SR");
        namshi6Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi6Lb.setPadding(new Insets(0, 20, 25, 0));
        namshi6Lb.setTranslateY(35);
        
        ImageView listbtn1view6onamshi = new ImageView(listimg1);//
        listbtn1view6onamshi.setFitHeight(68);
        listbtn1view6onamshi.setFitWidth(68);
        
        ImageView wishlistView6namshi = new ImageView(wishlistimg1);
        wishlistView6namshi.setFitHeight(50);
        wishlistView6namshi.setFitWidth(50);
        
        Button listButton6namshi = new Button();
        listButton6namshi.setGraphic(new StackPane(listbtn1view6onamshi));
        listButton6namshi.setPrefSize(35, 35);
        listButton6namshi.setTranslateY(65);
        listButton6namshi.setTranslateX(20);
        listButton6namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton6namshi = new Button();
        wishlistButton6namshi.setGraphic(new StackPane(wishlistView6namshi));
        wishlistButton6namshi.setPrefSize(35, 35);
        wishlistButton6namshi.setTranslateY(61);
        wishlistButton6namshi.setTranslateX(-20);
        wishlistButton6namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi6.getChildren().addAll(rectProductnamshi6, SmallrectProductnamshi6,
                 namshiImg6, namshi6Lb , wishlistButton6namshi , listButton6namshi );

        itemsBox3namshi.getChildren().addAll(rectitemsnamshi5, rectitemsnamshi6);

        // fourth 2 ////////////////////////////////////
        HBox itemsBox4namshi = new HBox(40);

        itemsBox4namshi.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnamshi7 = new StackPane();
        Rectangle rectProductnamshi7 = new Rectangle(110, 155);
        rectProductnamshi7.setFill(PinkRectL);
        rectProductnamshi7.setArcWidth(10);
        rectProductnamshi7.setArcHeight(10);

        Rectangle SmallrectProductnamshi7 = new Rectangle(110, 30);
        SmallrectProductnamshi7.setFill(PinkRectD);
        SmallrectProductnamshi7.setArcWidth(10);
        SmallrectProductnamshi7.setArcHeight(10);
        SmallrectProductnamshi7.setTranslateY(62);

        Image namshi7 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\lip7.PNG");
        ImageView namshiImg7 = new ImageView(namshi7);//
        namshiImg7.setFitHeight(90);
        namshiImg7.setFitWidth(85);
        namshiImg7.setTranslateY(-30);

        Label namshi7Lb = new Label("Matte Revolution \n200SR");
        namshi7Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi7Lb.setPadding(new Insets(0, 0, 25, 0));
        namshi7Lb.setTranslateY(40);
        
        ImageView listbtn1view7namshi = new ImageView(listimg1);//
        listbtn1view7namshi.setFitHeight(68);
        listbtn1view7namshi.setFitWidth(68);
        
        ImageView wishlistView7namshi = new ImageView(wishlistimg1);
        wishlistView7namshi.setFitHeight(50);
        wishlistView7namshi.setFitWidth(50);
        
        Button listButton7namshi = new Button();
        listButton7namshi.setGraphic(new StackPane(listbtn1view7namshi));
        listButton7namshi.setPrefSize(35, 35);
        listButton7namshi.setTranslateY(65);
        listButton7namshi.setTranslateX(20);
        listButton7namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton7namshi = new Button();
        wishlistButton7namshi.setGraphic(new StackPane(wishlistView7namshi));
        wishlistButton7namshi.setPrefSize(35, 35);
        wishlistButton7namshi.setTranslateY(61);
        wishlistButton7namshi.setTranslateX(-20);
        wishlistButton7namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi7.getChildren().addAll(rectProductnamshi7, SmallrectProductnamshi7,
                 namshiImg7, namshi7Lb, wishlistButton7namshi , listButton7namshi);
        ///////////////////////////////////////////////
        StackPane rectitemsnamshi8 = new StackPane();
        Rectangle rectProductnamshi8 = new Rectangle(110, 155);
        rectProductnamshi8.setFill(PinkRectL);
        rectProductnamshi8.setArcWidth(10);
        rectProductnamshi8.setArcHeight(10);

        Rectangle SmallrectProductnamshi8 = new Rectangle(110, 30);
        SmallrectProductnamshi8.setFill(PinkRectD);
        SmallrectProductnamshi8.setArcWidth(10);
        SmallrectProductnamshi8.setArcHeight(10);
        SmallrectProductnamshi8.setTranslateY(62);

        Image namshi8 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\polish8.PNG");
        ImageView namshiImg8 = new ImageView(namshi8);//
        namshiImg8.setFitHeight(90);
        namshiImg8.setFitWidth(95);
        namshiImg8.setTranslateY(-34);

        Label namshi8Lb = new Label("Nail Polish\n31SR");
        namshi8Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi8Lb.setPadding(new Insets(0, 0, 25, 0));
        namshi8Lb.setTranslateY(38);
        
        ImageView listbtn1view8namshi = new ImageView(listimg1);//
        listbtn1view8namshi.setFitHeight(68);
        listbtn1view8namshi.setFitWidth(68);
        
        ImageView wishlistView8namshi = new ImageView(wishlistimg1);
        wishlistView8namshi.setFitHeight(50);
        wishlistView8namshi.setFitWidth(50);
        
        Button listButton8namshi = new Button();
        listButton8namshi.setGraphic(new StackPane(listbtn1view8namshi));
        listButton8namshi.setPrefSize(35, 35);
        listButton8namshi.setTranslateY(65);
        listButton8namshi.setTranslateX(20);
        listButton8namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton8namshi = new Button();
        wishlistButton8namshi.setGraphic(new StackPane(wishlistView8namshi));
        wishlistButton8namshi.setPrefSize(35, 35);
        wishlistButton8namshi.setTranslateY(61);
        wishlistButton8namshi.setTranslateX(-20);
        wishlistButton8namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi8.getChildren().addAll(rectProductnamshi8 , SmallrectProductnamshi8
                , namshiImg8, namshi8Lb , wishlistButton8namshi , listButton8namshi);

        itemsBox4namshi.getChildren().addAll(rectitemsnamshi7, rectitemsnamshi8 );

        // fifth 2/////////////////////////////
        HBox itemsBox5namshi = new HBox(40);

        itemsBox5namshi.setPadding(new Insets(30, 0, 0, 40));

        StackPane rectitemsnamshi9 = new StackPane();
        Rectangle rectProductnamshi9 = new Rectangle(110, 155);
        rectProductnamshi9.setFill(PinkRectL);
        rectProductnamshi9.setArcWidth(10);
        rectProductnamshi9.setArcHeight(10);

        Rectangle SmallrectProductnamshi9 = new Rectangle(110, 30);
        SmallrectProductnamshi9.setFill(PinkRectD);
        SmallrectProductnamshi9.setArcWidth(10);
        SmallrectProductnamshi9.setArcHeight(10);
        SmallrectProductnamshi9.setTranslateY(62);

        Image namshi9 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\nikeShose9.PNG");
        ImageView namshiImg9 = new ImageView(namshi9);//
        namshiImg9.setFitHeight(88);
        namshiImg9.setFitWidth(70);
        namshiImg9.setTranslateY(-37);

        Label namshi9Lb = new Label("Nick Shoes\n357SR");
        namshi9Lb.setStyle("-fx-font: normal 9px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi9Lb.setPadding(new Insets(0, 5, 25, 0));
        namshi9Lb.setTranslateY(40);
        
        ImageView listbtn1view9namshi = new ImageView(listimg1);//
        listbtn1view9namshi.setFitHeight(68);
        listbtn1view9namshi.setFitWidth(68);
        
        ImageView wishlistView9namshi = new ImageView(wishlistimg1);
        wishlistView9namshi.setFitHeight(50);
        wishlistView9namshi.setFitWidth(50);
        
        Button listButton9namshi = new Button();
        listButton9namshi.setGraphic(new StackPane(listbtn1view9namshi));
        listButton9namshi.setPrefSize(35, 35);
        listButton9namshi.setTranslateY(65);
        listButton9namshi.setTranslateX(20);
        listButton9namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton9namshi = new Button();
        wishlistButton9namshi.setGraphic(new StackPane(wishlistView9namshi));
        wishlistButton9namshi.setPrefSize(35, 35);
        wishlistButton9namshi.setTranslateY(61);
        wishlistButton9namshi.setTranslateX(-20);
        wishlistButton9namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi9.getChildren().addAll(rectProductnamshi9, SmallrectProductnamshi9,
                 namshiImg9, namshi9Lb , wishlistButton9namshi , listButton9namshi);
/////////////////////////////////////////////////////////
        StackPane rectitemsnamshi10 = new StackPane();
        Rectangle rectProductnamshi10 = new Rectangle(110, 155);
        rectProductnamshi10.setFill(PinkRectL);
        rectProductnamshi10.setArcWidth(10);
        rectProductnamshi10.setArcHeight(10);

        Rectangle SmallrectProductnamshi10 = new Rectangle(110, 30);
        SmallrectProductnamshi10.setFill(PinkRectD);
        SmallrectProductnamshi10.setArcWidth(10);
        SmallrectProductnamshi10.setArcHeight(10);
        SmallrectProductnamshi10.setTranslateY(62);

        Image namshi10 = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\Pradapirf10.PNG");
        ImageView namshiImg10 = new ImageView(namshi10);//
        namshiImg10.setFitHeight(80);
        namshiImg10.setFitWidth(70);
        namshiImg10.setTranslateY(-35);

        Label namshi10Lb = new Label("Paradoxe Parfum\n531SR");
        namshi10Lb.setStyle("-fx-font: normal 10px 'Comic Sans MS'; -fx-text-fill: white; ");
        namshi10Lb.setPadding(new Insets(0, 0, 25, 0));
        namshi10Lb.setTranslateY(38);
        
        ImageView listbtn1view10namshi = new ImageView(listimg1);//
        listbtn1view10namshi.setFitHeight(68);
        listbtn1view10namshi.setFitWidth(68);
        
        ImageView wishlistView10namshi = new ImageView(wishlistimg1);
        wishlistView10namshi.setFitHeight(50);
        wishlistView10namshi.setFitWidth(50);
        
        Button listButton10namshi = new Button();
        listButton10namshi.setGraphic(new StackPane(listbtn1view10namshi));
        listButton10namshi.setPrefSize(35, 35);
        listButton10namshi.setTranslateY(65);
        listButton10namshi.setTranslateX(20);
        listButton10namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
        
        Button wishlistButton10namshi = new Button();
        wishlistButton10namshi.setGraphic(new StackPane(wishlistView10namshi));
        wishlistButton10namshi.setPrefSize(35, 35);
        wishlistButton10namshi.setTranslateY(61);
        wishlistButton10namshi.setTranslateX(-20);
        wishlistButton10namshi.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");


        rectitemsnamshi10.getChildren().addAll(rectProductnamshi10, SmallrectProductnamshi10
                , namshiImg10, namshi10Lb , wishlistButton10namshi , listButton10namshi);

        itemsBox5namshi.getChildren().addAll(rectitemsnamshi9, rectitemsnamshi10);

        centerBoxnamshi.getChildren().addAll(centerSpendingnamshi, itemsBoxnamshi, itemsBox2namshi,
                 itemsBox3namshi, itemsBox4namshi, itemsBox5namshi);
        
        
        ScrollPane scrollPaneounass = new ScrollPane(centerBoxnamshi);
        scrollPaneounass.setFitToWidth(true);
        scrollPaneounass.setFitToHeight(true);
        //scrollPane.setPrefViewportHeight(100);

        // bottom 
        StackPane bottomOunassroot = new StackPane();

        Rectangle rectangleBnamshi = new Rectangle();
        rectangleBnamshi.setWidth(360);
        rectangleBnamshi.setHeight(60);
        rectangleBnamshi.setFill(Color.web("657da1"));

        StackPane.setMargin(rectangleBnamshi, new Insets(35, 0, 0, 0));

        ////home Botton////
        Image imageHome = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\home.png");

        ImageView homeView = new ImageView(imageHome);
        homeView.setFitHeight(50);
        homeView.setFitWidth(60);

        Button homeButton = new Button();
        homeButton.setGraphic(new StackPane(homeView));
        homeButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(homeButton, Pos.CENTER_LEFT);
        StackPane.setMargin(homeButton, new Insets(10, 0, 0, 30));

        Text textHome = new Text("Home");
        textHome.setStyle("-fx-font: normal bold 10px 'serif'");
        textHome.setFill(Color.WHITE);

        StackPane.setAlignment(textHome, Pos.CENTER_LEFT);
        StackPane.setMargin(textHome, new Insets(50, 0, 0, 55));

        /////wishlist botton/////

        Image wishlistImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\wishlist.png");
        ImageView wishlistView = new ImageView(wishlistImage);
        wishlistView.setFitHeight(50); //setting the fit height and width of the image view
        wishlistView.setFitWidth(70);

        Button wishlistButton = new Button();
        wishlistButton.setGraphic(new StackPane(wishlistView));
        wishlistButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(wishlistButton, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistButton, new Insets(10, 0, 0, 91));

        Text wishlistText = new Text("Wishlist");
        wishlistText.setStyle("-fx-font: normal bold 10px 'serif'");
        wishlistText.setFill(Color.WHITE);

        StackPane.setAlignment(wishlistText, Pos.CENTER_LEFT);
        StackPane.setMargin(wishlistText, new Insets(50, 0, 0, 120));



        //// List botton ////

        Image listImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\list.png");
        ImageView listView = new ImageView(listImage);
        listView.setFitHeight(70); //setting the fit height and width of the image view
        listView.setFitWidth(80);

        Button listButton = new Button();
        listButton.setGraphic(new StackPane(listView));
        listButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(listButton, Pos.CENTER);
        StackPane.setMargin(listButton, new Insets(15, 0, 0, 60));

        Text listText = new Text("List");
        listText.setStyle("-fx-font: normal bold 10px 'serif'");
        listText.setFill(Color.WHITE);

        StackPane.setAlignment(listText, Pos.CENTER);
        StackPane.setMargin(listText, new Insets(50, 0, 0, 60));

        ////// profile botton ////////

        Image profileImage = new Image("file:C:\\Users\\Judi Jan\\Documents\\projectPhoto\\profile.png");
        ImageView profileView = new ImageView(profileImage);
        profileView.setFitHeight(70); //setting the fit height and width of the image view
        profileView.setFitWidth(100);

        Button profileButton = new Button();
        profileButton.setGraphic(new StackPane(profileView));
        profileButton.setStyle("-fx-background-color: transparent; ");
        StackPane.setAlignment(profileButton, Pos.CENTER);
        StackPane.setMargin(profileButton, new Insets(0, 0, 0, 210));

        Text profileText = new Text("Profile");
        profileText.setStyle("-fx-font: normal bold 10px 'serif'");
        profileText.setFill(Color.WHITE);

        StackPane.setAlignment(profileText, Pos.CENTER);
        StackPane.setMargin(profileText, new Insets(50, 0, 0, 200));



        bottomOunassroot.getChildren().addAll(rectangleBnamshi, homeButton, textHome
                , wishlistButton , wishlistText , listButton ,listText , profileButton , profileText );

           
        namshiPane.setTop(topnamshiroot);       
        namshiPane.setCenter(scrollPaneounass);
        namshiPane.setBottom(bottomOunassroot);

        Scene scene = new Scene(namshiPane, 350, 600);
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); //

        HomePageScene homePageScene = new HomePageScene();
        WishlistScene wishlistScene = new WishlistScene();
        ListScene listScene = new ListScene();

        backImg.setOnMousePressed(e->{
            homePageScene.start(primaryStage );
        });

        homeButton.setOnMousePressed(e->{
            homePageScene.start(primaryStage );

        });

        wishlistButton.setOnMousePressed(e->{
            wishlistScene.start(primaryStage);

        });


        listButton.setOnMousePressed(e->{
            listScene.start(primaryStage );

        });

//        profileButton.setOnMousePressed(e->{    // profile button
//                    profileScene.start(new Stage() );

//              });
    }
}

